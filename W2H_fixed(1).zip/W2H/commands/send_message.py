from pydantic import BaseModel
from worker.base_command import BaseCommand
from worker.errors import CommandValidationError


class SendMessagePayload(BaseModel):
    chat_id: str
    message: str


class SendMessageCommand(BaseCommand):

    @classmethod
    async def validate(cls, payload: dict) -> None:
        try:
            SendMessagePayload(**payload)
        except Exception as exc:
            raise CommandValidationError(str(exc))

    @classmethod
    async def execute(cls, client, payload: dict) -> dict:
        data = SendMessagePayload(**payload)
        msg = await client.send_message(data.chat_id, data.message)
        return {"message_id": msg.id}
