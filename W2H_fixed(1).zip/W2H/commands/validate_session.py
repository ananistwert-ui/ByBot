from worker.base_command import BaseCommand


class ValidateSessionCommand(BaseCommand):

    @classmethod
    async def validate(cls, payload: dict) -> None:
        pass  # Для валидации сессии payload не нужен

    @classmethod
    async def execute(cls, client, payload: dict) -> dict:
        me = await client.get_me()
        if me is None:
            return {"authorized": False}
        return {
            "authorized": True,
            "user_id": me.id,
            "username": me.username,
            "phone": me.phone,
        }
