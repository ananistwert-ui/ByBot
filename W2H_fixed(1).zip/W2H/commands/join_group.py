from pydantic import BaseModel
from worker.base_command import BaseCommand
from worker.errors import CommandValidationError


class JoinGroupPayload(BaseModel):
    invite_link: str


class JoinGroupCommand(BaseCommand):

    @classmethod
    async def validate(cls, payload: dict) -> None:
        try:
            JoinGroupPayload(**payload)
        except Exception as exc:
            raise CommandValidationError(str(exc))

    @classmethod
    async def execute(cls, client, payload: dict) -> dict:
        data = JoinGroupPayload(**payload)
        await client.join_chat(data.invite_link)
        return {"joined": True, "invite_link": data.invite_link}
