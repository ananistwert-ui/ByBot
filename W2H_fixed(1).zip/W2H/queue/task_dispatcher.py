import json
import logging
from queue.consumer import consume
from queue.redis_client import redis
from worker.executor import WorkerExecutor

STREAM = "tasks"
GROUP = "workers"

logger = logging.getLogger(__name__)


class TaskDispatcher:
    """Читает задачи из Redis Stream и передаёт воркеру на выполнение."""

    def __init__(self):
        self.executor = WorkerExecutor()

    async def run(self, worker_name: str) -> None:
        logger.info("Dispatcher '%s' started", worker_name)

        async for message_id, data in consume(worker_name):
            try:
                payload = json.loads(data["payload"])
                logger.info("Executing task: %s / action=%s", message_id, payload.get("action"))

                result = await self.executor.execute(payload)
                logger.info("Task %s succeeded: %s", message_id, result)

            except Exception as exc:
                logger.error("Task %s failed: %s", message_id, exc, exc_info=True)

            finally:
                # Подтверждаем сообщение в любом случае
                # (повторы управляются через retry_count в TaskEnvelope)
                await redis.xack(STREAM, GROUP, message_id)
