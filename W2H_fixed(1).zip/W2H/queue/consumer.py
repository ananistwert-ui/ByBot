from queue.redis_client import redis
import logging

STREAM = "tasks"
GROUP = "workers"

logger = logging.getLogger(__name__)


async def ensure_group() -> None:
    """Создаёт группу потребителей, если не существует."""
    try:
        await redis.xgroup_create(STREAM, GROUP, id="0", mkstream=True)
        logger.info("Consumer group '%s' created", GROUP)
    except Exception:
        # Группа уже существует — это нормально
        pass


async def consume(worker_name: str):
    """
    Async generator. Читает по одному сообщению из Redis Stream.
    Группа создаётся один раз до цикла.
    """
    await ensure_group()

    while True:
        messages = await redis.xreadgroup(
            GROUP,
            worker_name,
            {STREAM: ">"},
            count=1,
            block=5000,
        )

        if not messages:
            continue

        for _stream, entries in messages:
            for message_id, data in entries:
                yield message_id, data
