from queue.redis_client import redis


async def acquire_session_lock(session_id: str, ttl: int = 300) -> bool:
    """Возвращает True если блокировка получена, False если уже занята."""
    key = f"lock:session:{session_id}"
    result = await redis.set(key, "1", nx=True, ex=ttl)
    return result is True


async def release_session_lock(session_id: str) -> None:
    key = f"lock:session:{session_id}"
    await redis.delete(key)
