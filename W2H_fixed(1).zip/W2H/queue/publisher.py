from queue.redis_client import redis
from schemas.task import TaskEnvelope

STREAM = "tasks"


class TaskPublisher:

    @classmethod
    async def publish(cls, task: TaskEnvelope) -> str:
        payload = task.model_dump_json()
        message_id = await redis.xadd(STREAM, {"payload": payload})
        return message_id
