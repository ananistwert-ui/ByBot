from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    APP_NAME: str = "FARM TG"
    SECRET_KEY: str
    JWT_ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 120

    POSTGRES_DSN: str
    REDIS_HOST: str = "redis"
    REDIS_PORT: int = 6379

    class Config:
        env_file = ".env"


settings = Settings()
