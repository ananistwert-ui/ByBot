from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from core.database import get_db
from db.task import Task
from db.enums import TaskStatus, TaskPriority
from schemas.task import TaskCreate, TaskEnvelope, TaskResponse
from queue.publisher import TaskPublisher

router = APIRouter(prefix="/tasks", tags=["tasks"])


@router.post("/", response_model=TaskResponse, status_code=202)
async def create_task(payload: TaskCreate, db: AsyncSession = Depends(get_db)):
    # Сохраняем задачу в БД
    task_record = Task(
        action=payload.action,
        payload=payload.payload,
        session_ids=[str(sid) for sid in payload.session_ids],
        priority=TaskPriority(payload.priority),
        status=TaskStatus.QUEUED,
    )
    db.add(task_record)
    await db.flush()

    # Публикуем в Redis Stream
    envelope = TaskEnvelope(
        task_id=task_record.task_id,
        session_ids=payload.session_ids,
        action=payload.action,
        payload=payload.payload,
        priority=payload.priority,
    )
    await TaskPublisher.publish(envelope)

    return TaskResponse(task_id=str(task_record.task_id), status="queued")
