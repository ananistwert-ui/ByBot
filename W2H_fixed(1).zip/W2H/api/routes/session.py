from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from uuid import UUID
from core.database import get_db
from db.session import Session
from db.enums import SessionState, TaskPriority
from schemas.session import SessionCreate, SessionResponse
from schemas.task import TaskEnvelope
from queue.publisher import TaskPublisher

router = APIRouter(prefix="/sessions", tags=["sessions"])


@router.post("/", response_model=SessionResponse, status_code=201)
async def create_session(payload: SessionCreate, db: AsyncSession = Depends(get_db)):
    session = Session(
        name=payload.name,
        api_id=payload.api_id,
        api_hash=payload.api_hash,
        proxy_id=payload.proxy_id,
        session_path=f"sessions/{payload.name}.session",
        state=SessionState.OFFLINE,
    )
    db.add(session)
    await db.flush()

    # Ставим задачу валидации в очередь
    task = TaskEnvelope(
        session_ids=[session.id],
        action="validate_session",
        payload={},
        priority=TaskPriority.HIGH.value,
    )
    await TaskPublisher.publish(task)

    return session


@router.get("/", response_model=list[SessionResponse])
async def list_sessions(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Session))
    return result.scalars().all()


@router.get("/{session_id}", response_model=SessionResponse)
async def get_session(session_id: UUID, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Session).where(Session.id == session_id))
    session = result.scalar_one_or_none()
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    return session
