from proxy.models import ProxyRuntime


class ProxyPool:
    """Кэш прокси в памяти воркера."""

    def __init__(self):
        self._proxies: dict[str, ProxyRuntime] = {}

    def add(self, proxy: ProxyRuntime) -> None:
        self._proxies[proxy.proxy_id] = proxy

    def get(self, proxy_id: str) -> ProxyRuntime | None:
        return self._proxies.get(proxy_id)

    def remove(self, proxy_id: str) -> None:
        self._proxies.pop(proxy_id, None)

    def all(self) -> list[ProxyRuntime]:
        return list(self._proxies.values())
