from proxy.models import ProxyRuntime


class ProxyHealthChecker:

    HEALTH_THRESHOLD = 30.0

    async def check(self, proxy: ProxyRuntime) -> bool:
        """Возвращает True если прокси считается живым."""
        return proxy.health_score > self.HEALTH_THRESHOLD
