class ProxyRuntime:
    """In-memory представление прокси для воркера."""

    def __init__(
        self,
        proxy_id: str,
        proxy_type: str,
        host: str,
        port: int,
        username: str | None = None,
        password: str | None = None,
    ):
        self.proxy_id = proxy_id
        self.proxy_type = proxy_type
        self.host = host
        self.port = port
        self.username = username
        self.password = password
        self.health_score: float = 100.0
        self.active_sessions: int = 0

    def to_telethon_proxy(self) -> tuple | None:
        """Возвращает proxy-tuple для TelegramClient или None."""
        if self.proxy_type.upper() == "SOCKS5":
            import socks
            return (socks.SOCKS5, self.host, self.port, True, self.username, self.password)
        if self.proxy_type.upper() == "HTTP":
            import socks
            return (socks.HTTP, self.host, self.port, True, self.username, self.password)
        return None
