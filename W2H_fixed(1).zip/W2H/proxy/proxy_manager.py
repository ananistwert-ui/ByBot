from proxy.proxy_pool import ProxyPool
from proxy.health_checker import ProxyHealthChecker
from proxy.models import ProxyRuntime


class ProxyManager:

    def __init__(self):
        self.pool = ProxyPool()
        self.health = ProxyHealthChecker()

    def register(self, proxy: ProxyRuntime) -> None:
        self.pool.add(proxy)

    async def get_proxy(self, proxy_id: str) -> ProxyRuntime:
        proxy = self.pool.get(proxy_id)
        if proxy is None:
            raise ValueError(f"Proxy {proxy_id!r} not found")

        alive = await self.health.check(proxy)
        if not alive:
            raise RuntimeError(f"Proxy {proxy_id!r} is unhealthy (score={proxy.health_score})")

        return proxy

    async def get_any_healthy(self) -> ProxyRuntime | None:
        """Возвращает первый живой прокси из пула."""
        for proxy in self.pool.all():
            if await self.health.check(proxy):
                return proxy
        return None
