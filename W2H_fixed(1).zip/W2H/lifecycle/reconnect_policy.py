class ReconnectPolicy:
    MAX_RETRIES = 5

    @classmethod
    def backoff(cls, retry_count: int) -> int:
        """Экспоненциальная задержка, максимум 5 минут."""
        return min(2 ** retry_count, 300)

    @classmethod
    def should_retry(cls, retry_count: int) -> bool:
        return retry_count < cls.MAX_RETRIES
