import logging
from uuid import UUID
from sqlalchemy import select, update
from core.database import SessionLocal
from db.session import Session
from db.enums import SessionState

logger = logging.getLogger(__name__)


class SessionRepository:

    async def get_session(self, session_id: str | UUID) -> dict:
        """Получает данные сессии из БД."""
        async with SessionLocal() as db:
            result = await db.execute(
                select(Session).where(Session.id == session_id)
            )
            session: Session | None = result.scalar_one_or_none()

        if session is None:
            raise ValueError(f"Session {session_id!r} not found in DB")

        return {
            "session_id": str(session.id),
            "session_path": session.session_path,
            "api_id": int(session.api_id),
            "api_hash": session.api_hash,
            "proxy_id": str(session.proxy_id) if session.proxy_id else None,
        }

    async def update_state(self, session_id: str | UUID, state: SessionState) -> None:
        """Обновляет состояние сессии в БД."""
        async with SessionLocal() as db:
            await db.execute(
                update(Session)
                .where(Session.id == session_id)
                .values(state=state)
            )
            await db.commit()
        logger.info("Session %s -> %s", session_id, state)
