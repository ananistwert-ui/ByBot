from db.enums import SessionState

# Допустимые переходы состояний
TRANSITIONS: dict[SessionState, set[SessionState]] = {
    SessionState.OFFLINE: {SessionState.CONNECTING},
    SessionState.CONNECTING: {
        SessionState.ONLINE,
        SessionState.OFFLINE,
        SessionState.FLOOD_WAIT,
        SessionState.INVALID_SESSION,
        SessionState.PROXY_FAILED,
    },
    SessionState.ONLINE: {SessionState.OFFLINE, SessionState.FLOOD_WAIT, SessionState.BANNED},
    SessionState.FLOOD_WAIT: {SessionState.CONNECTING, SessionState.OFFLINE},
    SessionState.BANNED: set(),           # терминальное состояние
    SessionState.INVALID_SESSION: set(),  # терминальное состояние
    SessionState.PROXY_FAILED: {SessionState.CONNECTING, SessionState.OFFLINE},
}


def can_transition(current: SessionState, next_state: SessionState) -> bool:
    """Проверяет, допустим ли переход между состояниями."""
    return next_state in TRANSITIONS.get(current, set())


def assert_transition(current: SessionState, next_state: SessionState) -> None:
    """Бросает ValueError если переход недопустим."""
    if not can_transition(current, next_state):
        raise ValueError(
            f"Invalid state transition: {current.value} -> {next_state.value}"
        )
