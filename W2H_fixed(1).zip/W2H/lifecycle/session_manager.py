import asyncio
import logging
from telethon import TelegramClient
from telethon.errors import FloodWaitError
from db.enums import SessionState
from lifecycle.session_repository import SessionRepository
from lifecycle.reconnect_policy import ReconnectPolicy
from worker.errors import SessionUnavailable

logger = logging.getLogger(__name__)


class SessionLifecycleManager:
    """
    Управляет жизненным циклом Telegram-клиентов:
    подключение, отключение, переподключение, health-check.
    """

    def __init__(self):
        self.repository = SessionRepository()
        self.sessions: dict[str, TelegramClient] = {}

    async def connect(self, session_id: str) -> TelegramClient:
        """Создаёт и подключает нового клиента."""
        metadata = await self.repository.get_session(session_id)

        client = TelegramClient(
            metadata["session_path"],
            metadata["api_id"],
            metadata["api_hash"],
        )

        await self.repository.update_state(session_id, SessionState.CONNECTING)

        await client.connect()

        if not await client.is_user_authorized():
            await self.repository.update_state(session_id, SessionState.INVALID_SESSION)
            raise SessionUnavailable(f"Session {session_id!r} is not authorized")

        self.sessions[session_id] = client
        await self.repository.update_state(session_id, SessionState.ONLINE)
        logger.info("Session %s connected", session_id)
        return client

    async def safe_connect(self, session_id: str) -> TelegramClient:
        """Подключает с обработкой ошибок и обновлением статуса."""
        try:
            return await self.connect(session_id)

        except FloodWaitError as exc:
            logger.warning("Session %s flood wait %ds", session_id, exc.seconds)
            await self.repository.update_state(session_id, SessionState.FLOOD_WAIT)
            raise

        except SessionUnavailable:
            raise

        except Exception as exc:
            logger.error("Session %s connect failed: %s", session_id, exc)
            await self.repository.update_state(session_id, SessionState.OFFLINE)
            raise

    async def disconnect(self, session_id: str) -> None:
        """Отключает клиента и удаляет из кэша."""
        client = self.sessions.get(session_id)
        if client is None:
            return

        try:
            await client.disconnect()
        except Exception as exc:
            logger.warning("Error disconnecting %s: %s", session_id, exc)
        finally:
            self.sessions.pop(session_id, None)
            await self.repository.update_state(session_id, SessionState.OFFLINE)
            logger.info("Session %s disconnected", session_id)

    async def get_or_connect(self, session_id: str) -> TelegramClient:
        """Возвращает существующего клиента или создаёт нового."""
        if session_id in self.sessions:
            return self.sessions[session_id]
        return await self.safe_connect(session_id)

    async def reconnect_with_backoff(self, session_id: str) -> TelegramClient:
        """Переподключает с экспоненциальной задержкой."""
        for attempt in range(ReconnectPolicy.MAX_RETRIES):
            try:
                return await self.safe_connect(session_id)
            except Exception:
                delay = ReconnectPolicy.backoff(attempt)
                logger.info("Retry %d for %s in %ds", attempt + 1, session_id, delay)
                await asyncio.sleep(delay)
        raise SessionUnavailable(f"Failed to reconnect session {session_id!r}")

    async def disconnect_all(self) -> None:
        """Закрывает все активные сессии."""
        for session_id in list(self.sessions.keys()):
            await self.disconnect(session_id)
