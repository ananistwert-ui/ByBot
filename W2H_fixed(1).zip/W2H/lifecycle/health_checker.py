import logging

logger = logging.getLogger(__name__)


class SessionHealthChecker:

    async def check(self, client) -> bool:
        """Проверяет, что клиент авторизован и отвечает."""
        try:
            me = await client.get_me()
            return me is not None
        except Exception as exc:
            logger.warning("Health check failed: %s", exc)
            return False
