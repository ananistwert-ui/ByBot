from uuid import UUID, uuid4
from pydantic import BaseModel, Field
from typing import Any


class TaskCreate(BaseModel):
    session_ids: list[UUID]
    action: str
    payload: dict[str, Any] = {}
    priority: str = "NORMAL"


class TaskEnvelope(BaseModel):
    task_id: UUID = Field(default_factory=uuid4)
    session_ids: list[UUID]
    action: str
    payload: dict[str, Any]
    priority: str
    retry_count: int = 0


class TaskResponse(BaseModel):
    task_id: str
    status: str
