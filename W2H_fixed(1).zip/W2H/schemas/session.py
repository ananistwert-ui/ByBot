from pydantic import BaseModel
from uuid import UUID


class SessionCreate(BaseModel):
    name: str
    api_id: str
    api_hash: str
    proxy_id: UUID | None = None


class SessionResponse(BaseModel):
    id: UUID
    name: str
    state: str

    model_config = {"from_attributes": True}
