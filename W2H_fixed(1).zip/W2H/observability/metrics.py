from prometheus_client import Counter, Histogram, Gauge

TASK_EXECUTIONS = Counter(
    "task_executions_total",
    "Total task executions",
    ["action", "status"],
)

TASK_DURATION = Histogram(
    "task_duration_seconds",
    "Task execution duration",
    ["action"],
)

ACTIVE_SESSIONS = Gauge(
    "active_sessions_total",
    "Number of currently connected Telegram sessions",
)
