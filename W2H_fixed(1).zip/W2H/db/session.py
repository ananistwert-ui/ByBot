import uuid
from sqlalchemy import String, ForeignKey, DateTime, JSON, Enum
from sqlalchemy.orm import Mapped, mapped_column
from sqlalchemy.dialects.postgresql import UUID
from db.base import Base
from db.enums import SessionState


class Session(Base):
    __tablename__ = "sessions"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    owner_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id"), nullable=False
    )
    proxy_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("proxies.id"), nullable=True
    )
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    api_id: Mapped[str] = mapped_column(String(128), nullable=False)
    api_hash: Mapped[str] = mapped_column(String(255), nullable=False)
    session_path: Mapped[str] = mapped_column(String(500), nullable=False)
    state: Mapped[SessionState] = mapped_column(
        Enum(SessionState), default=SessionState.OFFLINE
    )
    meta: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    last_seen: Mapped[DateTime | None] = mapped_column(DateTime(timezone=True), nullable=True)
