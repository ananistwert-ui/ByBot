import uuid
from sqlalchemy import String, JSON, DateTime, func
from sqlalchemy.orm import mapped_column
from sqlalchemy.dialects.postgresql import UUID
from db.base import Base


class AuditLog(Base):
    __tablename__ = "audit_logs"

    id = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    action = mapped_column(String(255), nullable=False)
    actor_id = mapped_column(UUID(as_uuid=True), nullable=True)
    entity_type = mapped_column(String(50), nullable=True)
    entity_id = mapped_column(String(255), nullable=True)
    payload = mapped_column(JSON, nullable=True)
    created_at = mapped_column(DateTime(timezone=True), server_default=func.now())
