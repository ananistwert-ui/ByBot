from commands.send_message import SendMessageCommand
from commands.validate_session import ValidateSessionCommand
from commands.join_group import JoinGroupCommand
from worker.base_command import BaseCommand
from worker.errors import UnknownCommand


class CommandRegistry:
    COMMANDS: dict[str, type[BaseCommand]] = {
        "send_message": SendMessageCommand,
        "validate_session": ValidateSessionCommand,
        "join_group": JoinGroupCommand,
    }

    @classmethod
    def get(cls, action: str) -> type[BaseCommand]:
        if action not in cls.COMMANDS:
            raise UnknownCommand(f"Unknown command: {action!r}")
        return cls.COMMANDS[action]

    @classmethod
    def register(cls, action: str, command: type[BaseCommand]) -> None:
        """Позволяет добавлять команды динамически."""
        cls.COMMANDS[action] = command
