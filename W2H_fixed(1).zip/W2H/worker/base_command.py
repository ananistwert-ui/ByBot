from abc import ABC, abstractmethod
from typing import Any


class BaseCommand(ABC):

    @classmethod
    @abstractmethod
    async def validate(cls, payload: dict) -> None:
        """Валидирует payload. Бросает CommandValidationError при ошибке."""

    @classmethod
    @abstractmethod
    async def execute(cls, client: Any, payload: dict) -> dict:
        """Выполняет команду. Возвращает результат в виде dict."""
