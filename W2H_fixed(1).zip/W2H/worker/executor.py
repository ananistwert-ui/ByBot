import logging
from worker.command_registry import CommandRegistry
from worker.session_manager import SessionManager
from worker.errors import SessionUnavailable, CommandValidationError, UnknownCommand

logger = logging.getLogger(__name__)


class WorkerExecutor:
    """
    Обрабатывает одну задачу:
    1. Находит команду по action
    2. Валидирует payload
    3. Получает клиент по session_id из БД
    4. Выполняет команду
    """

    def __init__(self):
        self.session_manager = SessionManager()

    async def execute(self, task: dict) -> dict:
        action: str = task["action"]
        payload: dict = task.get("payload", {})
        session_ids: list = task.get("session_ids", [])

        # Берём первую сессию (для задач на несколько — расширить)
        if not session_ids:
            raise SessionUnavailable("Task has no session_ids")
        session_id = str(session_ids[0])

        command = CommandRegistry.get(action)

        try:
            await command.validate(payload)
        except CommandValidationError:
            raise
        except Exception as exc:
            raise CommandValidationError(str(exc)) from exc

        client = await self.session_manager.get_client(session_id)

        result = await command.execute(client, payload)
        logger.info("action=%s session=%s -> %s", action, session_id, result)
        return result

    async def shutdown(self) -> None:
        await self.session_manager.release_all()
