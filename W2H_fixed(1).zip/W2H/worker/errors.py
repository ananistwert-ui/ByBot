class WorkerError(Exception):
    """Базовая ошибка воркера."""


class SessionUnavailable(WorkerError):
    """Сессия недоступна или не авторизована."""


class CommandValidationError(WorkerError):
    """Невалидные данные для команды."""


class UnknownCommand(WorkerError):
    """Неизвестное действие."""
