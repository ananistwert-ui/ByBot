import logging
from telethon import TelegramClient
from lifecycle.session_manager import SessionLifecycleManager
from worker.errors import SessionUnavailable

logger = logging.getLogger(__name__)


class SessionManager:
    """
    Фасад для воркера: возвращает готового TelegramClient по session_id.
    Делегирует логику подключения SessionLifecycleManager.
    """

    def __init__(self):
        self._lifecycle = SessionLifecycleManager()

    async def get_client(self, session_id: str) -> TelegramClient:
        """Возвращает подключённого и авторизованного клиента."""
        return await self._lifecycle.get_or_connect(session_id)

    async def release_all(self) -> None:
        """Закрывает все сессии при завершении воркера."""
        await self._lifecycle.disconnect_all()
