import asyncio
import logging
import os
from queue.task_dispatcher import TaskDispatcher

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)

logger = logging.getLogger(__name__)


async def main():
    worker_name = os.getenv("WORKER_NAME", "worker-1")
    logger.info("Starting worker: %s", worker_name)

    dispatcher = TaskDispatcher()

    try:
        await dispatcher.run(worker_name)
    except (KeyboardInterrupt, asyncio.CancelledError):
        logger.info("Worker %s shutting down...", worker_name)
        await dispatcher.executor.shutdown()


if __name__ == "__main__":
    asyncio.run(main())
