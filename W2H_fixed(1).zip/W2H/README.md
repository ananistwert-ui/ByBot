# FARM TG

Система массового управления Telegram-сессиями: FastAPI сервер принимает задачи через REST API, воркер выполняет их через Telethon. Сервер и воркер общаются через Redis Stream, данные хранятся в PostgreSQL.

## Требования

- Ubuntu 22.04 / 24.04 (или другой Linux)
- Python 3.11+
- PostgreSQL 14+
- Redis 6+
- Доступ в интернет для воркера (подключение к Telegram API)

## 1. Подготовка сервера

```bash
sudo apt update
sudo apt install -y python3.11 python3.11-venv python3-pip postgresql redis-server git
```

Проверьте, что Redis и PostgreSQL запущены:

```bash
sudo systemctl status postgresql
sudo systemctl status redis-server
```

## 2. Настройка PostgreSQL

```bash
sudo -u postgres psql
```

Внутри `psql`:

```sql
CREATE DATABASE farmtg;
CREATE USER farmtg_user WITH PASSWORD 'надёжный_пароль';
GRANT ALL PRIVILEGES ON DATABASE farmtg TO farmtg_user;
\q
```

## 3. Клонирование и зависимости

```bash
git clone <ваш_репозиторий> /opt/farmtg
cd /opt/farmtg

python3.11 -m venv venv
source venv/bin/activate

pip install -r requirements.txt
```

## 4. Конфигурация

Скопируйте пример конфигурации и заполните своими значениями:

```bash
cp .env.example .env
nano .env
```

Минимально необходимые переменные:

```ini
SECRET_KEY=сгенерируйте_длинную_случайную_строку
JWT_ALGORITHM=HS256
ACCESS_TOKEN_EXPIRE_MINUTES=120

POSTGRES_DSN=postgresql+asyncpg://farmtg_user:надёжный_пароль@localhost:5432/farmtg

REDIS_HOST=localhost
REDIS_PORT=6379
```

Сгенерировать `SECRET_KEY` можно так:

```bash
python3 -c "import secrets; print(secrets.token_urlsafe(48))"
```

## 5. Создание таблиц в БД

Таблицы создаются автоматически из моделей SQLAlchemy при первом запуске. Самый простой способ — выполнить разово:

```bash
python3 -c "
import asyncio
from core.database import engine
from db.base import Base
from db import user, proxy, session, task, audit  # noqa: импорт регистрирует модели

async def init():
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

asyncio.run(init())
"
```

Для продакшена рекомендуется заменить это на Alembic-миграции.

## 6. Папка для сессий Telegram

Воркер сохраняет файлы `.session` на диск:

```bash
mkdir -p /opt/farmtg/sessions
```

## 7. Запуск вручную (проверка)

В двух отдельных терминалах:

```bash
# Терминал 1 — API сервер
source venv/bin/activate
uvicorn main:app --host 0.0.0.0 --port 8000

# Терминал 2 — воркер
source venv/bin/activate
python -m worker.main
```

Проверьте, что сервер отвечает:

```bash
curl http://localhost:8000/health
# {"status":"ok"}
```

## 8. Запуск через systemd (продакшен)

### Сервис API

Создайте `/etc/systemd/system/farmtg-api.service`:

```ini
[Unit]
Description=FARM TG API
After=network.target postgresql.service redis-server.service

[Service]
Type=simple
User=www-data
WorkingDirectory=/opt/farmtg
EnvironmentFile=/opt/farmtg/.env
ExecStart=/opt/farmtg/venv/bin/uvicorn main:app --host 0.0.0.0 --port 8000
Restart=on-failure
RestartSec=5

[Install]
WantedBy=multi-user.target
```

### Сервис воркера

Создайте `/etc/systemd/system/farmtg-worker.service`:

```ini
[Unit]
Description=FARM TG Worker
After=network.target postgresql.service redis-server.service

[Service]
Type=simple
User=www-data
WorkingDirectory=/opt/farmtg
EnvironmentFile=/opt/farmtg/.env
Environment=WORKER_NAME=worker-1
ExecStart=/opt/farmtg/venv/bin/python -m worker.main
Restart=on-failure
RestartSec=5

[Install]
WantedBy=multi-user.target
```

Если нужно несколько воркеров — скопируйте файл с другим именем (`farmtg-worker-2.service`) и измените `WORKER_NAME`.

### Применение прав и запуск

```bash
sudo chown -R www-data:www-data /opt/farmtg

sudo systemctl daemon-reload
sudo systemctl enable --now farmtg-api
sudo systemctl enable --now farmtg-worker

sudo systemctl status farmtg-api
sudo systemctl status farmtg-worker
```

Логи:

```bash
journalctl -u farmtg-api -f
journalctl -u farmtg-worker -f
```

## 9. Reverse proxy (опционально, Nginx)

```nginx
server {
    listen 80;
    server_name your-domain.com;

    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

Для HTTPS используйте `certbot --nginx`.

## Структура проекта

```
main.py                 — точка входа FastAPI
worker/main.py          — точка входа воркера
core/                   — конфигурация, БД, security
db/                     — ORM-модели и enum-ы
schemas/                — Pydantic-схемы запросов/ответов
api/routes/             — HTTP-роуты (auth, session, task)
queue/                  — Redis Stream: publisher, consumer, dispatcher
worker/                 — executor, command_registry, session_manager
commands/               — реализации команд (send_message, join_group, ...)
lifecycle/              — управление подключениями Telegram (connect/disconnect/state machine)
proxy/                  — пул прокси и health-check
observability/          — метрики Prometheus
```

## Проверка работоспособности

```bash
# Регистрация
curl -X POST http://localhost:8000/auth/register \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"пароль123"}'

# Логин — получить токен
curl -X POST http://localhost:8000/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"пароль123"}'
```

## Частые проблемы

**`ModuleNotFoundError` при запуске** — убедитесь, что запускаете команды из корня проекта (`/opt/farmtg`), а не из вложенной папки. Все импорты используют абсолютные пути от корня.

**Воркер падает с `SessionUnavailable`** — сессия не авторизована или файл `.session` повреждён. Удалите файл из `sessions/` и создайте сессию заново через Telethon.

**Задачи зависают в очереди** — проверьте, что хотя бы один процесс воркера запущен и подключён к тому же Redis (`farmtg-worker` сервис активен).

**`asyncpg.exceptions.InvalidPasswordError`** — проверьте `POSTGRES_DSN` в `.env`, пароль должен совпадать с тем, что задан в PostgreSQL.
