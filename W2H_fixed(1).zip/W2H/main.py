from fastapi import FastAPI
from api.routes.auth import router as auth_router
from api.routes.session import router as session_router
from api.routes.task import router as task_router

app = FastAPI(title="FARM TG", version="1.0.0")

app.include_router(auth_router)
app.include_router(session_router)
app.include_router(task_router)


@app.get("/health", tags=["system"])
async def health():
    return {"status": "ok"}
