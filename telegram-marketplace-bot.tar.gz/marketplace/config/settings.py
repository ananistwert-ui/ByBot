from functools import lru_cache
from typing import Literal

from pydantic import PostgresDsn, RedisDsn, field_validator, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # ── Application ──────────────────────────────────────────────────────────
    APP_ENV: Literal["development", "staging", "production"] = "development"
    APP_DEBUG: bool = False
    APP_SECRET_KEY: str  # min 32 chars, required
    APP_HOST: str = "0.0.0.0"
    APP_PORT: int = 8000

    # ── Database ─────────────────────────────────────────────────────────────
    DATABASE_URL: PostgresDsn
    DATABASE_POOL_SIZE: int = 20
    DATABASE_MAX_OVERFLOW: int = 10
    DATABASE_POOL_TIMEOUT: int = 30
    DATABASE_ECHO: bool = False  # Никогда не включать в production

    # ── Redis ────────────────────────────────────────────────────────────────
    REDIS_URL: RedisDsn
    REDIS_POOL_SIZE: int = 20

    # ── Celery ───────────────────────────────────────────────────────────────
    CELERY_BROKER_URL: str  # same redis URL but as string
    CELERY_RESULT_BACKEND: str

    # ── Telegram Bot ─────────────────────────────────────────────────────────
    BOT_TOKEN: str
    BOT_WEBHOOK_URL: str  # https://yourdomain.com/webhook/bot
    BOT_WEBHOOK_SECRET: str  # random 32+ char secret for webhook validation

    # ── CryptoBot ────────────────────────────────────────────────────────────
    CRYPTOBOT_TOKEN: str
    CRYPTOBOT_API_URL: str = "https://pay.crypt.bot/api"
    # Webhook secret для проверки подписи от CryptoBot
    CRYPTOBOT_WEBHOOK_SECRET: str

    # ── JWT / Auth ────────────────────────────────────────────────────────────
    JWT_SECRET_KEY: str
    JWT_ALGORITHM: str = "HS256"
    JWT_ACCESS_TOKEN_EXPIRE_MINUTES: int = 60
    JWT_REFRESH_TOKEN_EXPIRE_DAYS: int = 30

    # ── Security ─────────────────────────────────────────────────────────────
    RATE_LIMIT_PER_MINUTE: int = 60
    RATE_LIMIT_BOT_PER_SECOND: int = 3  # per user
    ALLOWED_ORIGINS: list[str] = ["http://localhost:3000"]

    # ── Business Logic ────────────────────────────────────────────────────────
    ORDER_PAYMENT_TIMEOUT_MINUTES: int = 30
    ORDER_POOL_VISIBILITY_LIMIT: int = 50  # макс заказов в пуле за раз

    # ── Observability ────────────────────────────────────────────────────────
    SENTRY_DSN: str | None = None
    LOG_LEVEL: Literal["DEBUG", "INFO", "WARNING", "ERROR"] = "INFO"
    LOG_FORMAT: Literal["json", "console"] = "json"

    @field_validator("APP_SECRET_KEY", "JWT_SECRET_KEY")
    @classmethod
    def validate_secret_length(cls, v: str) -> str:
        if len(v) < 32:
            raise ValueError("Secret keys must be at least 32 characters")
        return v

    @model_validator(mode="after")
    def validate_production_settings(self) -> "Settings":
        if self.APP_ENV == "production":
            if self.APP_DEBUG:
                raise ValueError("DEBUG must be False in production")
            if self.DATABASE_ECHO:
                raise ValueError("DATABASE_ECHO must be False in production")
            if not self.SENTRY_DSN:
                raise ValueError("SENTRY_DSN required in production")
        return self

    @property
    def is_production(self) -> bool:
        return self.APP_ENV == "production"

    @property
    def database_url_str(self) -> str:
        return str(self.DATABASE_URL)

    @property
    def redis_url_str(self) -> str:
        return str(self.REDIS_URL)


@lru_cache
def get_settings() -> Settings:
    """Singleton — создаётся один раз при старте."""
    return Settings()


settings = get_settings()
