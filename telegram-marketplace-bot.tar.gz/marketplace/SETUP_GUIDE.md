# Telegram Marketplace Bot — Инструкция по установке и использованию

Полное руководство по развёртыванию, настройке и ежедневной эксплуатации системы.

---

## Содержание

1. [Требования](#1-требования)
2. [Получение необходимых ключей](#2-получение-необходимых-ключей)
3. [Первичная установка](#3-первичная-установка)
4. [Настройка окружения (.env)](#4-настройка-окружения-env)
5. [Применение миграций БД](#5-применение-миграций-бд)
6. [Запуск через Docker Compose](#6-запуск-через-docker-compose)
7. [Настройка Telegram Bot Webhook](#7-настройка-telegram-bot-webhook)
8. [Настройка Nginx и SSL](#8-настройка-nginx-и-ssl)
9. [Первый запуск: создание SuperAdmin](#9-первый-запуск-создание-superadmin)
10. [Использование: SuperAdmin](#10-использование-superadmin)
11. [Использование: Operator](#11-использование-operator)
12. [Использование: Customer](#12-использование-customer)
13. [Мониторинг и логи](#13-мониторинг-и-логи)
14. [Запуск тестов](#14-запуск-тестов)
15. [Резервное копирование](#15-резервное-копирование)
16. [Troubleshooting](#16-troubleshooting)
17. [Чеклист безопасности перед production](#17-чеклист-безопасности-перед-production)

---

## 1. Требования

### Минимальные требования к серверу

| Компонент | Минимум | Рекомендуется |
|---|---|---|
| CPU | 2 vCPU | 4 vCPU |
| RAM | 4 GB | 8 GB |
| Диск | 20 GB SSD | 50 GB SSD |
| OS | Ubuntu 22.04+ / Debian 12+ | Ubuntu 24.04 |

### Программное обеспечение

```bash
# Проверьте версии перед началом
docker --version          # >= 24.0
docker compose version    # >= 2.20
git --version
```

Если Docker не установлен:

```bash
curl -fsSL https://get.docker.com | sh
sudo usermod -aG docker $USER
newgrp docker
```

### Домены

Вам понадобятся **2 поддомена** с A-записями, указывающими на IP сервера:

- `api.yourdomain.com` — REST API + admin panel
- `bot.yourdomain.com` — Telegram webhook endpoint

---

## 2. Получение необходимых ключей

### 2.1 Telegram Bot Token

1. Откройте [@BotFather](https://t.me/BotFather) в Telegram
2. Отправьте `/newbot`
3. Укажите имя и username бота (должен заканчиваться на `bot`)
4. Сохраните токен вида `123456789:AAAbbbCCCdddEEEfffGGGhhh`

```
/newbot
Marketplace Store
my_marketplace_bot
```

### 2.2 CryptoBot Token

1. Откройте [@CryptoBot](https://t.me/CryptoBot) (или `@CryptoTestnetBot` для тестов)
2. `Crypto Pay` → `My Apps` → `Create App`
3. Укажите название приложения
4. Скопируйте `API Token`

> **Важно:** для тестирования используйте `@CryptoTestnetBot` — он работает в тестовой сети, платежи там бесплатные. Перед production переключитесь на `@CryptoBot`.

### 2.3 Генерация секретов

Выполните для каждого секрета отдельно:

```bash
# APP_SECRET_KEY, JWT_SECRET_KEY, BOT_WEBHOOK_SECRET
python3 -c "import secrets; print(secrets.token_hex(32))"
```

Повторите команду 3 раза — для каждого секрета должно быть **своё** уникальное значение.

### 2.4 Sentry DSN (опционально, но рекомендуется)

1. Зарегистрируйтесь на [sentry.io](https://sentry.io)
2. Создайте новый проект, платформа — Python/FastAPI
3. Скопируйте DSN из Settings → Client Keys

---

## 3. Первичная установка

```bash
# Распакуйте архив проекта
tar -xzf telegram-marketplace-bot.tar.gz
cd marketplace

# Создайте файл окружения из шаблона
cp .env.example .env
```

Структура проекта после распаковки:

```
marketplace/
├── api/              # FastAPI backend
├── bot/              # Telegram bot (aiogram)
├── core/             # Бизнес-логика
├── models/           # SQLAlchemy модели
├── workers/          # Celery задачи
├── migrations/       # Alembic миграции
├── docker/           # Dockerfile, compose, nginx, prometheus
├── tests/            # Тесты
├── .env.example      # Шаблон конфигурации
└── pyproject.toml
```

---

## 4. Настройка окружения (.env)

Откройте `.env` и заполните **каждое** поле. Ниже — построчное объяснение.

```bash
nano .env   # или любой текстовый редактор
```

| Переменная | Что указать | Пример |
|---|---|---|
| `APP_ENV` | `production` для прода, `development` для локальной разработки | `production` |
| `APP_SECRET_KEY` | Секрет из шага 2.3 | `a1b2c3...` (64 hex символа) |
| `DATABASE_URL` | Строка подключения к PostgreSQL. **Хост `postgres`** — имя сервиса в docker-compose, не меняйте | `postgresql+asyncpg://marketplace_user:ВАШ_ПАРОЛЬ@postgres:5432/marketplace` |
| `REDIS_URL` | Аналогично, хост `redis` | `redis://:ВАШ_ПАРОЛЬ@redis:6379/0` |
| `CELERY_BROKER_URL` | Redis для очереди задач (другой db index) | `redis://:ВАШ_ПАРОЛЬ@redis:6379/1` |
| `CELERY_RESULT_BACKEND` | Redis для результатов задач | `redis://:ВАШ_ПАРОЛЬ@redis:6379/2` |
| `BOT_TOKEN` | Токен из шага 2.1 | `123456789:AAAbbb...` |
| `BOT_WEBHOOK_URL` | Публичный HTTPS URL вашего бота | `https://bot.yourdomain.com/webhook/bot` |
| `BOT_WEBHOOK_SECRET` | Секрет из шага 2.3 | `d4e5f6...` |
| `CRYPTOBOT_TOKEN` | Токен из шага 2.2 | `12345:AAxxx...` |
| `CRYPTOBOT_WEBHOOK_SECRET` | Можно оставить произвольным значением 32+ символов — реальная подпись вычисляется из `CRYPTOBOT_TOKEN` | `g7h8i9...` |
| `JWT_SECRET_KEY` | **Другой** секрет из шага 2.3 (не путать с `APP_SECRET_KEY`) | `j0k1l2...` |
| `ALLOWED_ORIGINS` | Откуда разрешены CORS-запросы к API (для веб-админки, если используете) | `["https://admin.yourdomain.com"]` |
| `SENTRY_DSN` | DSN из шага 2.4. **Обязателен в production** — без него приложение не запустится (см. валидацию в settings) | `https://xxx@sentry.io/123` |

### Создание паролей для PostgreSQL/Redis/Grafana

Docker Compose читает пароли из файлов в `docker/secrets/` (не из `.env` — это безопаснее):

```bash
mkdir -p docker/secrets
echo -n "сложный_пароль_postgres" > docker/secrets/postgres_password.txt
echo -n "сложный_пароль_redis"    > docker/secrets/redis_password.txt
echo -n "сложный_пароль_grafana"  > docker/secrets/grafana_password.txt
chmod 600 docker/secrets/*.txt
```

> ⚠️ Пароли в этих файлах должны **совпадать** с паролями, указанными в `DATABASE_URL` и `REDIS_URL` внутри `.env`.

---

## 5. Применение миграций БД

Миграции создают всю схему: таблицы, индексы, constraints, views, функции.

### Вариант А — через Docker (рекомендуется)

```bash
cd docker
docker compose up -d postgres redis
# Подождите 10-15 секунд, чтобы Postgres полностью поднялся
docker compose run --rm api alembic upgrade head
```

### Вариант Б — локально (для разработки)

```bash
pip install poetry
poetry install
poetry run alembic upgrade head
```

Проверка, что миграции применились:

```bash
docker compose exec postgres psql -U marketplace_user -d marketplace -c "\dt"
```

Вы должны увидеть таблицы: `users`, `operators`, `products`, `operator_inventory`, `orders`, `payments`, `payouts`, `audit_logs`, `sessions`.

---

## 6. Запуск через Docker Compose

```bash
cd docker
docker compose up -d --build
```

Это поднимет 9 сервисов:

| Сервис | Назначение | Реплик |
|---|---|---|
| `postgres` | База данных | 1 |
| `redis` | Кэш, FSM storage, Celery broker | 1 |
| `api` | REST API (FastAPI) | 2 |
| `bot` | Telegram бот (webhook) | 1 |
| `celery-worker` | Фоновые задачи | 2 |
| `celery-beat` | Планировщик периодических задач | 1 (всегда!) |
| `nginx` | Reverse proxy, TLS termination | 1 |
| `prometheus` | Сбор метрик | 1 |
| `grafana` | Дашборды | 1 |

Проверка статуса:

```bash
docker compose ps
docker compose logs -f api      # логи API
docker compose logs -f bot      # логи бота
docker compose logs -f celery-worker
```

Все сервисы должны быть в статусе `running (healthy)`.

---

## 7. Настройка Telegram Bot Webhook

Бот сам устанавливает webhook при старте (см. `on_startup` в `bot/main.py`), но проверьте вручную:

```bash
curl "https://api.telegram.org/bot<ВАШ_BOT_TOKEN>/getWebhookInfo"
```

Ожидаемый ответ:

```json
{
  "ok": true,
  "result": {
    "url": "https://bot.yourdomain.com/webhook/bot",
    "has_custom_certificate": false,
    "pending_update_count": 0
  }
}
```

Если `url` пустой — webhook не установился. Проверьте логи:

```bash
docker compose logs bot | grep -i webhook
```

Частая причина: домен `bot.yourdomain.com` не резолвится или SSL-сертификат не выпущен (см. следующий раздел).

---

## 8. Настройка Nginx и SSL

### 8.1 Получение SSL-сертификатов (Let's Encrypt)

```bash
# Установите certbot, если его нет
sudo apt install certbot

# Остановите nginx на время выпуска сертификата
docker compose stop nginx

# Выпустите сертификаты для обоих доменов
sudo certbot certonly --standalone \
  -d api.yourdomain.com \
  -d bot.yourdomain.com \
  --email ваш-email@example.com \
  --agree-tos

# Сертификаты появятся в /etc/letsencrypt/live/
```

### 8.2 Подключение сертификатов к контейнеру

В `docker-compose.yml` volume `certbot_certs` уже смонтирован в nginx как `/etc/letsencrypt`. Если вы получили сертификаты на хосте (не в контейнере), смонтируйте их напрямую:

```yaml
# docker/docker-compose.yml, сервис nginx — измените volume:
volumes:
  - /etc/letsencrypt:/etc/letsencrypt:ro
```

### 8.3 Замените домены в конфиге

```bash
nano docker/nginx/conf.d/marketplace.conf
```

Замените все упоминания `yourdomain.com` на ваш реальный домен (3 места: `server_name` в обоих server-блоках + пути к сертификатам).

### 8.4 Перезапустите nginx

```bash
docker compose up -d nginx
```

### 8.5 Настройте автопродление сертификата

```bash
sudo crontab -e
# Добавьте строку:
0 3 * * * certbot renew --quiet --pre-hook "docker compose -f /path/to/docker/docker-compose.yml stop nginx" --post-hook "docker compose -f /path/to/docker/docker-compose.yml start nginx"
```

---

## 9. Первый запуск: создание SuperAdmin

В системе изначально нет ни одного SuperAdmin. Первого администратора нужно создать напрямую в БД.

**Шаг 1.** Откройте бота в Telegram и отправьте `/start` — это создаст вашего `User` с ролью `customer`.

**Шаг 2.** Узнайте свой `telegram_id`:

```bash
# Через @userinfobot в Telegram, либо через лог бота:
docker compose logs bot | grep "new_user_registered"
```

**Шаг 3.** Повысьте роль до `superadmin` напрямую в БД:

```bash
docker compose exec postgres psql -U marketplace_user -d marketplace
```

```sql
UPDATE users SET role = 'superadmin' WHERE telegram_id = ВАШ_TELEGRAM_ID;
\q
```

**Шаг 4.** Отправьте боту `/admin` — должна открыться панель администратора.

> 💡 Все последующие операторы и админы создаются уже через интерфейс бота (`/admin` → Операторы → Создать), без прямых SQL-запросов.

---

## 10. Использование: SuperAdmin

Команда для входа в панель: **`/admin`**

### 10.1 Создание товара

```
/admin → 📦 Товары → ➕ Новый товар
```

Бот запросит по очереди:
1. **Название** (например: `Netflix Premium`)
2. **Описание** (или `-` чтобы пропустить)
3. **Цену** (например: `9.99`)
4. **Reward оператору** — сколько получит оператор за выполнение заказа этого товара (например: `1.50`)

После этого товар появляется в каталоге клиентов **со стоком 0**, пока операторы не выставят инвентарь.

### 10.2 Управление товарами

```
/admin → 📦 Товары → [выбрать товар]
```

Доступно:
- **🔴/🟢 Включить/Отключить** — товар скрывается из каталога, но остаётся в БД
- **🗑 Архивировать** — мягкое удаление (товары с историей заказов нельзя удалить физически — защита FK)

### 10.3 Создание оператора

Операторы создаются через REST API (нет отдельного bot-флоу для этого, так как требуется знать `telegram_id` нового оператора):

```bash
curl -X POST https://api.yourdomain.com/api/admin/operators \
  -H "Authorization: Bearer ВАШ_ADMIN_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"telegram_id": 123456789, "username": "operator_name"}'
```

> Получить `ВАШ_ADMIN_TOKEN`: войдите как админ через `/api/auth/telegram` (см. раздел 12) или временно через прямой SQL-запрос для теста.

После создания оператор должен отправить боту `/work` — откроется операторская панель.

### 10.4 Бан/разбан оператора

```
/admin → 👥 Операторы → [выбрать оператора] → 🚫 Забанить
```

При бане:
- Оператор немедленно теряет `is_active` (перестаёт видеть пул заказов)
- Уже взятые им заказы остаются за ним — это сделано умышленно, чтобы клиенты не потеряли свои заказы

### 10.5 Статистика

```
/admin → 📊 Статистика
```

Показывает топ-10 операторов: количество выполненных заказов, заработок, среднее время выполнения.

### 10.6 Мониторинг заказов

```
/admin → 🔍 Мониторинг заказов
```

Сводка по всем статусам заказов + количество "зависших" (claimed более 1 часа).

### 10.7 Расчёт и подтверждение выплат

```
/admin → 👥 Операторы → [оператор] → 💰 Рассчитать выплату
```

1. Бот попросит ввести период: `2026-06-01:2026-06-15`
2. Система посчитает сумму на основе выполненных заказов за период
3. Появится кнопка **✅ Подтвердить выплату**

> ⚠️ Если выплата за этот период уже была рассчитана — система откажет с указанием существующей выплаты (защита от двойной выплаты).

После подтверждения **фактический перевод денег оператору выполняется вручную, вне системы** (через CryptoBot transfer, банковский перевод и т.д.) — бот только фиксирует факт расчёта и подтверждения.

---

## 11. Использование: Operator

Команда для входа: **`/work`**

> Доступно только пользователям с ролью `operator`, созданным через Admin API (раздел 10.3).

### 11.1 Управление сменой

```
/work → ⚙️ Смена → 🟢 Начать смену
```

**Важно:** пока смена не начата (`is_active = false`), оператор **не видит** заказы в пуле, даже если у него есть инвентарь. Это сделано специально — оператор должен явно подтвердить готовность работать.

### 11.2 Выставление инвентаря

```
/work → 📊 Инвентарь → ➕ Добавить товар
```

1. Выберите товар из списка
2. Введите количество (целое число, например: `25`)

Это **полная замена** остатка, не добавление к текущему. Если хотите *пополнить* существующий остаток — посчитайте новую сумму сами (текущий остаток виден в `/work → 📊 Инвентарь`).

> Остаток автоматически уменьшается на 1 при каждом взятом заказе — вручную после каждого заказа корректировать не нужно.

### 11.3 Работа с пулом заказов

```
/work → 📦 Пул заказов
```

Показывает заказы, доступные **именно этому оператору** (смена активна + есть инвентарь по товару).

Нажмите на заказ → **"Заказ ваш! ✅"** или **"⚠️ Order already claimed"**, если другой оператор успел раньше.

### 11.4 Завершение заказа

```
/work → 📋 Мои заказы → [заказ] → ✅ Выполнено
```

После завершения:
- Инвентарь окончательно списывается
- На баланс оператора начисляется `reward_amount` товара
- Заказ переходит клиенту как "выполнен" (клиент видит это через `/orders`)

---

## 12. Использование: Customer

Любой пользователь, открывший бота, автоматически становится `customer`.

| Команда | Действие |
|---|---|
| `/start` | Приветствие |
| `/catalog` | Каталог товаров с ценами и наличием |
| `/orders` | История своих заказов и их статусы |

### Процесс покупки

1. `/catalog` → выбрать товар → **💳 Купить**
2. Бот создаёт invoice в CryptoBot и присылает кнопку оплаты
3. После оплаты клиент нажимает **🔄 Проверить оплату** (или ждёт автоматического обновления через webhook)
4. Заказ передаётся в пул операторам
5. Когда оператор завершает заказ — клиент видит статус "✅ Заказ выполнен" через `/orders`

---

## 13. Мониторинг и логи

### 13.1 Grafana

```
https://yourdomain.com:3000  (или через nginx, если настроен проксированный доступ)
Логин: admin
Пароль: из docker/secrets/grafana_password.txt
```

> По умолчанию Grafana доступна только из internal Docker network (`expose`, не `ports`). Для внешнего доступа добавьте отдельный nginx location с дополнительной авторизацией (Basic Auth рекомендуется), либо используйте SSH-тоннель:
> ```bash
> ssh -L 3000:localhost:3000 user@yourserver
> ```

### 13.2 Prometheus

Метрики доступны внутри сети по адресу `http://prometheus:9090`. Готовые алерты — в `docker/prometheus/alerts.yml`:
- Высокий процент конфликтов claim
- Подозрительные неудачные webhook-подписи (потенциальная атака)
- Зависшие заказы
- Переполнение пула соединений к БД
- Высокий процент 5xx ошибок API

### 13.3 Sentry

Все необработанные исключения автоматически летят в Sentry (если `SENTRY_DSN` настроен). Проверка:

```bash
docker compose logs api | grep -i sentry
```

### 13.4 Логи приложения

Все логи — в формате JSON (structlog), удобны для агрегации в ELK/Loki:

```bash
docker compose logs -f api | jq .
docker compose logs -f bot | jq .
docker compose logs --tail=100 celery-worker
```

### 13.5 Health checks

```bash
curl https://api.yourdomain.com/health        # liveness
curl https://api.yourdomain.com/health/ready  # readiness — проверяет DB и Redis
```

---

## 14. Запуск тестов

### 14.1 Полный набор тестов (требует тестовую БД)

```bash
# Поднимите тестовую инфраструктуру
docker compose -f docker/docker-compose.test.yml up -d postgres redis
# (или используйте основной compose с отдельной БД на порту 5433 — см. tests/conftest.py)

poetry install
poetry run pytest tests/ -v
```

### 14.2 Только race condition тесты (самые критичные)

```bash
poetry run pytest tests/integration/test_race_conditions.py -v -s
```

Ожидаемый вывод — все тесты должны проходить, особое внимание на:

```
test_two_operators_claim_same_order_only_one_succeeds PASSED
test_ten_operators_claim_same_order_only_one_succeeds PASSED
test_inventory_cannot_go_negative_under_concurrent_claims PASSED
```

Если хоть один из этих тестов падает — **не деплойте в production**, это означает потенциальную потерю данных (два оператора могут получить один заказ).

### 14.3 С покрытием кода

```bash
poetry run pytest --cov=core --cov=models --cov-report=html
open htmlcov/index.html
```

### 14.4 Нагрузочное тестирование

```bash
poetry run locust -f tests/load/locustfile.py --host=https://api.yourdomain.com
# Откройте http://localhost:8089 для веб-интерфейса Locust
```

> Перед нагрузочным тестом на claim-конкуренцию заполните БД тестовыми заказами в пуле — иначе тест быстро исчерпает доступные заказы.

---

## 15. Резервное копирование

### 15.1 Backup PostgreSQL

```bash
docker compose exec postgres pg_dump -U marketplace_user marketplace \
  | gzip > backup_$(date +%Y%m%d_%H%M%S).sql.gz
```

Автоматизация через cron:

```bash
crontab -e
# Ежедневный backup в 3:00
0 3 * * * docker compose -f /path/to/docker/docker-compose.yml exec -T postgres pg_dump -U marketplace_user marketplace | gzip > /backups/marketplace_$(date +\%Y\%m\%d).sql.gz
```

### 15.2 Восстановление из backup

```bash
gunzip -c backup_20260615_030000.sql.gz | \
  docker compose exec -T postgres psql -U marketplace_user marketplace
```

### 15.3 Что важно бэкапить

| Данные | Где | Критичность |
|---|---|---|
| PostgreSQL | `postgres_data` volume | Критично — основные данные |
| `.env` + `docker/secrets/` | Файловая система хоста | Критично — без них не восстановить доступ |
| Redis | `redis_data` volume | Низкая — это кэш/очередь, переживёт потерю |

> Redis **не нужно** бэкапить в строгом смысле — это FSM state и Celery очередь, потеря приведёт к временным неудобствам (пользователи начнут диалог сначала), но не к потере денег/заказов, так как все критичные данные — в PostgreSQL.

---

## 16. Troubleshooting

### Бот не отвечает

```bash
docker compose ps bot                          # сервис запущен?
docker compose logs bot --tail=50              # ошибки при старте?
curl "https://api.telegram.org/bot<TOKEN>/getWebhookInfo"  # webhook установлен?
```

Частые причины:
- Домен `bot.yourdomain.com` не резолвится → проверьте DNS
- SSL-сертификат просрочен/невалиден → `certbot certificates`
- `BOT_WEBHOOK_SECRET` не совпадает → проверьте `.env`

### Webhook от CryptoBot не доходит

```bash
docker compose logs api | grep webhook_rejected
docker compose logs api | grep cryptobot_webhook
```

Если видите `webhook_rejected_bad_signature` — проверьте, что `CRYPTOBOT_TOKEN` в `.env` **точно совпадает** с токеном приложения в @CryptoBot (подпись вычисляется из токена).

### Заказ "застрял" в pending_payment

Это нормально в первые `ORDER_PAYMENT_TIMEOUT_MINUTES` (по умолчанию 30 минут) — клиент просто не оплатил. После таймаута Celery Beat автоматически переводит заказ в `cancelled`. Проверьте, что планировщик работает:

```bash
docker compose logs celery-beat | grep cancel_expired_orders
docker compose ps celery-beat   # должна быть РОВНО 1 реплика
```

### Оператор не видит заказы в пуле

Проверьте последовательно:
1. Смена начата? (`/work → ⚙️ Смена` должна показывать "🟢 Активна")
2. Есть инвентарь по этому товару с `quantity_available > 0`?
3. Заказ действительно оплачен (`status = in_pool`, не `pending_payment`)?

```sql
SELECT o.id, o.status, oi.quantity_available, op.is_active
FROM orders o
JOIN operator_inventory oi ON oi.product_id = o.product_id
JOIN operators op ON op.id = oi.operator_id
WHERE o.status = 'in_pool' AND op.id = 'UUID_ОПЕРАТОРА';
```

### "Order already claimed" хотя я первый нажал

Это означает, что другой оператор выполнил атомарный `UPDATE` на миллисекунды раньше — система работает корректно. Это не баг, а ожидаемое поведение защиты от race condition.

### База данных не запускается

```bash
docker compose logs postgres --tail=50
```

Частая причина — несовпадение пароля в `docker/secrets/postgres_password.txt` и в `DATABASE_URL` внутри `.env`. Они должны быть идентичны.

### Высокая нагрузка / медленные ответы

```bash
# Проверьте использование connection pool
curl https://api.yourdomain.com/health/ready

# Посмотрите на активные запросы в Postgres
docker compose exec postgres psql -U marketplace_user -d marketplace \
  -c "SELECT pid, state, query FROM pg_stat_activity WHERE state != 'idle';"
```

Если `DATABASE_POOL_SIZE` исчерпан — увеличьте в `.env` и перезапустите `api`.

---

## 17. Чеклист безопасности перед production

Пройдите по списку перед тем, как открыть бота для реальных пользователей:

- [ ] Все секреты в `.env` сгенерированы случайно, ни один не оставлен как `CHANGE_ME`
- [ ] `APP_SECRET_KEY` и `JWT_SECRET_KEY` — **разные** значения
- [ ] `APP_ENV=production`, `APP_DEBUG=false`, `DATABASE_ECHO=false`
- [ ] `SENTRY_DSN` настроен и присылает тестовое событие
- [ ] SSL-сертификаты выпущены и автопродление настроено через cron
- [ ] `docker/secrets/*.txt` имеют права `600`, не закоммичены в git
- [ ] `.env` добавлен в `.gitignore` (уже сделано, проверьте `git status`)
- [ ] CryptoBot переключён с `@CryptoTestnetBot` на `@CryptoBot` (production токен)
- [ ] Первый SuperAdmin создан и проверен (`/admin` открывается)
- [ ] Race condition тесты пройдены (`pytest tests/integration/test_race_conditions.py`)
- [ ] `/metrics` endpoint закрыт от внешнего доступа (проверьте `curl https://api.yourdomain.com/metrics` → должен вернуть 403)
- [ ] Backup БД настроен и протестирован (сделайте тестовое восстановление)
- [ ] Rate limiting протестирован (отправьте >60 запросов/мин на API — должен вернуться 429)
- [ ] Webhook signature validation протестирована (отправьте POST на `/webhook/cryptobot` без подписи — должен вернуться 401)
- [ ] Grafana доступна только через VPN/SSH-тоннель или с Basic Auth, не публично
- [ ] Celery Beat запущен **ровно в одном** экземпляре (`docker compose ps celery-beat`)

---

## Быстрая справка: основные команды

```bash
# Запуск всей системы
docker compose -f docker/docker-compose.yml up -d

# Остановка
docker compose -f docker/docker-compose.yml down

# Перезапуск одного сервиса после изменения кода
docker compose up -d --build api

# Применить новую миграцию
docker compose run --rm api alembic upgrade head

# Создать новую миграцию после изменения моделей
docker compose run --rm api alembic revision --autogenerate -m "описание изменения"

# Зайти в psql
docker compose exec postgres psql -U marketplace_user -d marketplace

# Зайти в Redis CLI
docker compose exec redis redis-cli -a ВАШ_ПАРОЛЬ

# Посмотреть очередь Celery
docker compose exec celery-worker celery -A workers.celery_app inspect active

# Полный рестарт с пересборкой образов
docker compose down && docker compose up -d --build
```
