from aiogram.fsm.state import State, StatesGroup


class CustomerStates(StatesGroup):
    """Customer покупка товара."""
    browsing_catalog = State()
    viewing_product = State()
    awaiting_payment = State()


class OperatorInventoryStates(StatesGroup):
    """Оператор редактирует инвентарь."""
    selecting_product = State()
    entering_quantity = State()


class AdminProductStates(StatesGroup):
    """SuperAdmin создаёт/редактирует продукт."""
    entering_title = State()
    entering_description = State()
    entering_price = State()
    entering_reward = State()
    confirming = State()


class AdminPayoutStates(StatesGroup):
    """SuperAdmin рассчитывает выплату."""
    selecting_operator = State()
    selecting_period = State()
    confirming_amount = State()
