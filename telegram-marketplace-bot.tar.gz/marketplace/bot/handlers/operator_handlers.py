import uuid

import structlog
from aiogram import F, Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message
from sqlalchemy.ext.asyncio import AsyncSession

from bot.keyboards.operator_keyboards import (
    claimed_order_keyboard,
    inventory_keyboard,
    operator_menu_keyboard,
    order_pool_keyboard,
    product_select_keyboard,
    shift_keyboard,
)
from bot.states.states import OperatorInventoryStates
from core.repositories.inventory_repository import InventoryRepository
from core.repositories.operator_repository import OperatorRepository
from core.repositories.order_repository import OrderRepository
from core.services.audit_service import AuditService
from core.services.order_service import (
    InsufficientInventoryError,
    OrderAlreadyClaimedError,
    OrderNotFoundError,
    OrderService,
)
from core.services.payment_service import CryptoBotService
from models.models import Operator, OrderStatus, Product, User, UserRole

logger = structlog.get_logger(__name__)
router = Router(name="operator")


def _build_order_service(session: AsyncSession) -> OrderService:
    return OrderService(
        order_repo=OrderRepository(session),
        inventory_repo=InventoryRepository(session),
        audit_service=AuditService(session),
        cryptobot=CryptoBotService(),
    )


def _require_operator(operator: Operator | None) -> bool:
    """Guard: только зарегистрированные операторы проходят дальше."""
    return operator is not None


@router.message(Command("work"))
async def cmd_operator_menu(
    message: Message, user: User, operator: Operator | None
) -> None:
    if user.role != UserRole.operator or not _require_operator(operator):
        await message.answer("⛔️ У вас нет доступа к панели оператора.")
        return

    status = "🟢 Активна" if operator.is_active else "🔴 Не активна"
    await message.answer(
        f"👨‍💻 <b>Панель оператора</b>\n\nСмена: {status}",
        reply_markup=operator_menu_keyboard(),
    )


@router.callback_query(F.data == "shift:menu")
async def cb_shift_menu(callback: CallbackQuery, operator: Operator | None) -> None:
    if not _require_operator(operator):
        await callback.answer("Доступ запрещён", show_alert=True)
        return
    await callback.message.edit_text(
        f"Смена: {'🟢 Активна' if operator.is_active else '🔴 Не активна'}",
        reply_markup=shift_keyboard(operator.is_active),
    )
    await callback.answer()


@router.callback_query(F.data == "shift:start")
async def cb_shift_start(
    callback: CallbackQuery, session: AsyncSession, operator: Operator | None
) -> None:
    if not _require_operator(operator):
        await callback.answer("Доступ запрещён", show_alert=True)
        return

    repo = OperatorRepository(session)
    await repo.start_shift(operator.id)

    audit = AuditService(session)
    await audit.log(
        action="operator.shift_started",
        entity_type="operator",
        entity_id=operator.id,
        actor_id=operator.user_id,
    )

    await callback.message.edit_text(
        "🟢 Смена начата. Теперь вы видите заказы в пуле.",
        reply_markup=shift_keyboard(is_active=True),
    )
    await callback.answer()


@router.callback_query(F.data == "shift:stop")
async def cb_shift_stop(
    callback: CallbackQuery, session: AsyncSession, operator: Operator | None
) -> None:
    if not _require_operator(operator):
        await callback.answer("Доступ запрещён", show_alert=True)
        return

    repo = OperatorRepository(session)
    await repo.stop_shift(operator.id)

    audit = AuditService(session)
    await audit.log(
        action="operator.shift_stopped",
        entity_type="operator",
        entity_id=operator.id,
        actor_id=operator.user_id,
    )

    await callback.message.edit_text(
        "🔴 Смена завершена. Вы больше не видите новые заказы в пуле.\n"
        "Уже взятые заказы остаются за вами.",
        reply_markup=shift_keyboard(is_active=False),
    )
    await callback.answer()


@router.callback_query(F.data == "pool:show")
async def cb_show_pool(
    callback: CallbackQuery, session: AsyncSession, operator: Operator | None
) -> None:
    if not _require_operator(operator):
        await callback.answer("Доступ запрещён", show_alert=True)
        return

    if not operator.is_active:
        await callback.answer(
            "⚠️ Начните смену, чтобы видеть заказы в пуле", show_alert=True
        )
        return

    order_service = _build_order_service(session)
    orders = await order_service.get_pool_for_operator(operator.id)

    if not orders:
        await callback.message.edit_text(
            "📭 Пул заказов пуст.\n\n"
            "Заказы появятся, когда у вас будет инвентарь по оплаченным товарам.",
            reply_markup=order_pool_keyboard([]),
        )
        await callback.answer()
        return

    orders_data = [
        {
            "id": o.id,
            "product_title": o.product.title if o.product else "N/A",
            "amount": o.amount,
            "currency": o.currency,
        }
        for o in orders
    ]

    await callback.message.edit_text(
        f"📦 <b>Доступные заказы ({len(orders)}):</b>",
        reply_markup=order_pool_keyboard(orders_data),
    )
    await callback.answer()


@router.callback_query(F.data.startswith("claim:"))
async def cb_claim_order(
    callback: CallbackQuery, session: AsyncSession, operator: Operator | None
) -> None:
    """
    КРИТИЧНЫЙ путь: атомарный claim с защитой от race condition.
    Если другой оператор успел раньше — пользователь получает
    конкретное сообщение "Order already claimed".
    """
    if not _require_operator(operator):
        await callback.answer("Доступ запрещён", show_alert=True)
        return

    order_id = uuid.UUID(callback.data.split(":", 1)[1])

    order_repo = OrderRepository(session)
    order_row = await order_repo.get_by_id(order_id)
    if not order_row:
        await callback.answer("Заказ не найден", show_alert=True)
        return

    order_service = _build_order_service(session)

    try:
        order = await order_service.claim_order(
            order_id=order_id,
            operator_id=operator.id,
            product_id=order_row.product_id,
        )
    except OrderAlreadyClaimedError:
        await callback.answer("⚠️ Order already claimed", show_alert=True)
        # Обновляем пул, чтобы убрать уже забронированный заказ из списка
        await cb_show_pool(callback, session, operator)
        return
    except InsufficientInventoryError:
        await callback.answer(
            "⚠️ Недостаточно товара на складе", show_alert=True
        )
        return

    await callback.message.edit_text(
        f"✅ <b>Заказ принят в работу</b>\n\n"
        f"Товар: {order.product.title if order.product else 'N/A'}\n"
        f"Сумма: {order.amount} {order.currency}\n\n"
        f"Выполните заказ и нажмите «Выполнено».",
        reply_markup=claimed_order_keyboard(order.id),
    )
    await callback.answer("Заказ ваш! ✅")


@router.callback_query(F.data.startswith("complete:"))
async def cb_complete_order(
    callback: CallbackQuery, session: AsyncSession, operator: Operator | None
) -> None:
    if not _require_operator(operator):
        await callback.answer("Доступ запрещён", show_alert=True)
        return

    order_id = uuid.UUID(callback.data.split(":", 1)[1])
    order_service = _build_order_service(session)

    try:
        order = await order_service.complete_order(
            order_id=order_id, operator_id=operator.id
        )
    except OrderNotFoundError:
        await callback.answer(
            "Заказ не найден или не принадлежит вам", show_alert=True
        )
        return

    await callback.message.edit_text(
        f"🎉 <b>Заказ выполнен!</b>\n\n"
        f"Начислено: {order.product.reward_amount if order.product else 0} "
        f"к балансу.",
    )
    await callback.answer("Заказ выполнен ✅")


@router.callback_query(F.data == "orders:mine")
async def cb_my_orders(
    callback: CallbackQuery, session: AsyncSession, operator: Operator | None
) -> None:
    if not _require_operator(operator):
        await callback.answer("Доступ запрещён", show_alert=True)
        return

    order_repo = OrderRepository(session)
    orders = await order_repo.get_operator_orders(
        operator.id, status=OrderStatus.claimed
    )

    if not orders:
        await callback.message.edit_text("У вас нет активных заказов.")
        await callback.answer()
        return

    lines = ["📋 <b>Ваши активные заказы:</b>\n"]
    for o in orders:
        lines.append(
            f"• {o.product.title if o.product else 'N/A'} — {o.amount} {o.currency}"
        )

    await callback.message.edit_text("\n".join(lines))
    await callback.answer()


# ─────────────────────────────────────────────────────────────────────────────
# Inventory management
# ─────────────────────────────────────────────────────────────────────────────

@router.callback_query(F.data == "inventory:show")
async def cb_show_inventory(
    callback: CallbackQuery, session: AsyncSession, operator: Operator | None
) -> None:
    if not _require_operator(operator):
        await callback.answer("Доступ запрещён", show_alert=True)
        return

    inv_repo = InventoryRepository(session)
    items = await inv_repo.get_operator_inventory(operator.id)

    items_data = [
        {
            "product_id": i.product_id,
            "title": i.product.title if i.product else "N/A",
            "quantity_available": i.quantity_available,
        }
        for i in items
    ]

    text_msg = "📊 <b>Ваш инвентарь:</b>" if items_data else "📊 Инвентарь пуст."

    await callback.message.edit_text(
        text_msg, reply_markup=inventory_keyboard(items_data)
    )
    await callback.answer()


@router.callback_query(F.data == "add_inventory")
async def cb_add_inventory_start(
    callback: CallbackQuery,
    session: AsyncSession,
    operator: Operator | None,
    state: FSMContext,
) -> None:
    if not _require_operator(operator):
        await callback.answer("Доступ запрещён", show_alert=True)
        return

    from sqlalchemy import select
    stmt = select(Product).where(
        Product.is_active.is_(True), Product.is_archived.is_(False)
    )
    result = await session.execute(stmt)
    products = result.scalars().all()

    products_data = [{"id": p.id, "title": p.title} for p in products]

    await callback.message.edit_text(
        "Выберите товар:", reply_markup=product_select_keyboard(products_data)
    )
    await state.set_state(OperatorInventoryStates.selecting_product)
    await callback.answer()


@router.callback_query(F.data.startswith("select_product:"))
@router.callback_query(F.data.startswith("edit_inventory:"))
async def cb_select_product_for_inventory(
    callback: CallbackQuery,
    state: FSMContext,
) -> None:
    product_id = uuid.UUID(callback.data.split(":", 1)[1])
    await state.update_data(product_id=str(product_id))
    await state.set_state(OperatorInventoryStates.entering_quantity)

    await callback.message.edit_text(
        "Введите количество товара (целое число, например: 25):"
    )
    await callback.answer()


@router.message(OperatorInventoryStates.entering_quantity)
async def msg_enter_quantity(
    message: Message,
    session: AsyncSession,
    operator: Operator | None,
    state: FSMContext,
) -> None:
    if not _require_operator(operator):
        await message.answer("⛔️ Доступ запрещён.")
        await state.clear()
        return

    raw = message.text.strip() if message.text else ""
    if not raw.isdigit():
        await message.answer(
            "⚠️ Введите целое неотрицательное число (например: 25)."
        )
        return

    quantity = int(raw)
    if quantity > 100_000:
        await message.answer("⚠️ Слишком большое значение.")
        return

    data = await state.get_data()
    product_id = uuid.UUID(data["product_id"])

    product = await session.get(Product, product_id)
    if not product or not product.is_active:
        await message.answer("⚠️ Товар недоступен.")
        await state.clear()
        return

    inv_repo = InventoryRepository(session)
    await inv_repo.upsert(operator.id, product_id, quantity)

    audit = AuditService(session)
    await audit.log(
        action="inventory.updated",
        entity_type="operator_inventory",
        entity_id=operator.id,
        actor_id=operator.user_id,
        after_data={"product_id": str(product_id), "quantity": quantity},
    )

    await message.answer(
        f"✅ Остаток «{product.title}» установлен: {quantity} шт.",
        reply_markup=operator_menu_keyboard(),
    )
    await state.clear()
