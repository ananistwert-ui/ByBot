import uuid
from datetime import date, datetime, timedelta, timezone
from decimal import Decimal, InvalidOperation

import structlog
from aiogram import F, Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message
from sqlalchemy import select, text
from sqlalchemy.ext.asyncio import AsyncSession

from bot.keyboards.admin_keyboards import (
    admin_menu_keyboard,
    operator_actions_keyboard,
    operators_admin_keyboard,
    payout_confirm_keyboard,
    product_actions_keyboard,
    products_admin_keyboard,
)
from bot.states.states import AdminPayoutStates, AdminProductStates
from core.repositories.order_repository import OrderRepository
from core.services.audit_service import AuditService
from models.models import Operator, Order, Payout, PayoutStatus, Product, User, UserRole

logger = structlog.get_logger(__name__)
router = Router(name="admin")


def _require_admin(user: User) -> bool:
    return user.role == UserRole.superadmin


@router.message(Command("admin"))
async def cmd_admin_menu(message: Message, user: User) -> None:
    if not _require_admin(user):
        await message.answer("⛔️ У вас нет доступа к панели администратора.")
        return

    await message.answer(
        "🛡 <b>Панель SuperAdmin</b>", reply_markup=admin_menu_keyboard()
    )


@router.callback_query(F.data == "admin:products")
async def cb_admin_products(
    callback: CallbackQuery, session: AsyncSession, user: User
) -> None:
    if not _require_admin(user):
        await callback.answer("Доступ запрещён", show_alert=True)
        return

    stmt = select(Product).where(Product.is_archived.is_(False)).order_by(Product.sort_order)
    result = await session.execute(stmt)
    products = result.scalars().all()

    products_data = [
        {"id": p.id, "title": p.title, "is_active": p.is_active} for p in products
    ]

    await callback.message.edit_text(
        "📦 <b>Управление товарами:</b>",
        reply_markup=products_admin_keyboard(products_data),
    )
    await callback.answer()


@router.callback_query(F.data == "admin_product:new")
async def cb_new_product_start(
    callback: CallbackQuery, state: FSMContext, user: User
) -> None:
    if not _require_admin(user):
        await callback.answer("Доступ запрещён", show_alert=True)
        return

    await callback.message.edit_text("Введите название товара:")
    await state.set_state(AdminProductStates.entering_title)
    await callback.answer()


@router.message(AdminProductStates.entering_title)
async def msg_product_title(message: Message, state: FSMContext) -> None:
    title = (message.text or "").strip()
    if not title or len(title) > 256:
        await message.answer("⚠️ Название должно быть от 1 до 256 символов.")
        return

    await state.update_data(title=title)
    await message.answer("Введите описание товара (или «-» чтобы пропустить):")
    await state.set_state(AdminProductStates.entering_description)


@router.message(AdminProductStates.entering_description)
async def msg_product_description(message: Message, state: FSMContext) -> None:
    desc = (message.text or "").strip()
    description = None if desc == "-" else desc[:4096]

    await state.update_data(description=description)
    await message.answer("Введите цену (например: 9.99):")
    await state.set_state(AdminProductStates.entering_price)


@router.message(AdminProductStates.entering_price)
async def msg_product_price(message: Message, state: FSMContext) -> None:
    raw = (message.text or "").strip().replace(",", ".")
    try:
        price = Decimal(raw)
        if price <= 0:
            raise InvalidOperation
    except InvalidOperation:
        await message.answer("⚠️ Введите корректную положительную цену (например: 9.99).")
        return

    await state.update_data(price=str(price))
    await message.answer("Введите reward оператору за заказ (например: 1.50):")
    await state.set_state(AdminProductStates.entering_reward)


@router.message(AdminProductStates.entering_reward)
async def msg_product_reward(
    message: Message, session: AsyncSession, state: FSMContext, user: User
) -> None:
    raw = (message.text or "").strip().replace(",", ".")
    try:
        reward = Decimal(raw)
        if reward < 0:
            raise InvalidOperation
    except InvalidOperation:
        await message.answer("⚠️ Введите корректное неотрицательное число.")
        return

    data = await state.get_data()

    product = Product(
        title=data["title"],
        description=data.get("description"),
        price=Decimal(data["price"]),
        reward_amount=reward,
    )
    session.add(product)
    await session.flush()

    audit = AuditService(session)
    await audit.log(
        action="product.created",
        entity_type="product",
        entity_id=product.id,
        actor_id=user.id,
        after_data={"title": product.title, "price": str(product.price)},
    )

    await message.answer(
        f"✅ Товар «{product.title}» создан.\n"
        f"Цена: {product.price} | Reward: {reward}",
        reply_markup=admin_menu_keyboard(),
    )
    await state.clear()


@router.callback_query(F.data.startswith("admin_product:"))
async def cb_view_product(
    callback: CallbackQuery, session: AsyncSession, user: User
) -> None:
    if not _require_admin(user):
        await callback.answer("Доступ запрещён", show_alert=True)
        return

    product_id = uuid.UUID(callback.data.split(":", 1)[1])
    product = await session.get(Product, product_id)
    if not product:
        await callback.answer("Товар не найден", show_alert=True)
        return

    text_msg = (
        f"📦 <b>{product.title}</b>\n\n"
        f"{product.description or '—'}\n\n"
        f"Цена: {product.price} {product.currency}\n"
        f"Reward: {product.reward_amount}\n"
        f"Статус: {'🟢 Активен' if product.is_active else '🔴 Отключен'}"
    )

    await callback.message.edit_text(
        text_msg,
        reply_markup=product_actions_keyboard(product.id, product.is_active),
    )
    await callback.answer()


@router.callback_query(F.data.startswith("toggle_product:"))
async def cb_toggle_product(
    callback: CallbackQuery, session: AsyncSession, user: User
) -> None:
    if not _require_admin(user):
        await callback.answer("Доступ запрещён", show_alert=True)
        return

    product_id = uuid.UUID(callback.data.split(":", 1)[1])
    product = await session.get(Product, product_id)
    if not product:
        await callback.answer("Товар не найден", show_alert=True)
        return

    product.is_active = not product.is_active

    audit = AuditService(session)
    await audit.log(
        action="product.toggled",
        entity_type="product",
        entity_id=product.id,
        actor_id=user.id,
        after_data={"is_active": product.is_active},
    )

    await callback.message.edit_text(
        f"Статус товара «{product.title}» изменён: "
        f"{'🟢 Активен' if product.is_active else '🔴 Отключен'}",
        reply_markup=product_actions_keyboard(product.id, product.is_active),
    )
    await callback.answer()


# ─────────────────────────────────────────────────────────────────────────────
# Operators management
# ─────────────────────────────────────────────────────────────────────────────

@router.callback_query(F.data == "admin:operators")
async def cb_admin_operators(
    callback: CallbackQuery, session: AsyncSession, user: User
) -> None:
    if not _require_admin(user):
        await callback.answer("Доступ запрещён", show_alert=True)
        return

    stmt = (
        select(Operator, User)
        .join(User, User.id == Operator.user_id)
    )
    result = await session.execute(stmt)
    rows = result.all()

    operators_data = [
        {
            "id": op.id,
            "is_active": op.is_active,
            "username": u.username,
            "telegram_id": u.telegram_id,
        }
        for op, u in rows
    ]

    text_msg = "👥 <b>Операторы:</b>" if operators_data else "Операторов пока нет."
    await callback.message.edit_text(
        text_msg, reply_markup=operators_admin_keyboard(operators_data)
    )
    await callback.answer()


@router.callback_query(F.data.startswith("admin_operator:"))
async def cb_view_operator(
    callback: CallbackQuery, session: AsyncSession, user: User
) -> None:
    if not _require_admin(user):
        await callback.answer("Доступ запрещён", show_alert=True)
        return

    operator_id = uuid.UUID(callback.data.split(":", 1)[1])
    operator = await session.get(Operator, operator_id)
    if not operator:
        await callback.answer("Оператор не найден", show_alert=True)
        return

    op_user = await session.get(User, operator.user_id)

    text_msg = (
        f"👨‍💻 <b>{op_user.username or op_user.telegram_id}</b>\n\n"
        f"Статус: {'🟢 Активен' if operator.is_active else '⚪️ Не активен'}\n"
        f"Забанен: {'Да 🚫' if op_user.is_banned else 'Нет'}\n"
        f"Заработано: {operator.total_earned}"
    )

    await callback.message.edit_text(
        text_msg,
        reply_markup=operator_actions_keyboard(operator.id, op_user.is_banned),
    )
    await callback.answer()


@router.callback_query(F.data.startswith("ban_toggle:"))
async def cb_ban_toggle(
    callback: CallbackQuery, session: AsyncSession, user: User
) -> None:
    if not _require_admin(user):
        await callback.answer("Доступ запрещён", show_alert=True)
        return

    operator_id = uuid.UUID(callback.data.split(":", 1)[1])
    operator = await session.get(Operator, operator_id)
    if not operator:
        await callback.answer("Оператор не найден", show_alert=True)
        return

    op_user = await session.get(User, operator.user_id)
    op_user.is_banned = not op_user.is_banned

    # При бане немедленно убираем оператора из активного пула
    if op_user.is_banned:
        operator.is_active = False

    audit = AuditService(session)
    await audit.log(
        action="operator.ban_toggled",
        entity_type="operator",
        entity_id=operator.id,
        actor_id=user.id,
        after_data={"is_banned": op_user.is_banned},
    )

    await callback.message.edit_text(
        f"Статус изменён: {'🚫 Забанен' if op_user.is_banned else '✅ Разбанен'}",
        reply_markup=operator_actions_keyboard(operator.id, op_user.is_banned),
    )
    await callback.answer()


# ─────────────────────────────────────────────────────────────────────────────
# Stats
# ─────────────────────────────────────────────────────────────────────────────

@router.callback_query(F.data == "admin:stats")
async def cb_admin_stats(
    callback: CallbackQuery, session: AsyncSession, user: User
) -> None:
    if not _require_admin(user):
        await callback.answer("Доступ запрещён", show_alert=True)
        return

    stmt = text("""
        SELECT username, completed_orders, total_earned, avg_completion_seconds
        FROM v_operator_stats
        ORDER BY completed_orders DESC
        LIMIT 10
    """)
    result = await session.execute(stmt)
    rows = result.all()

    if not rows:
        await callback.message.edit_text("Нет данных по операторам.")
        await callback.answer()
        return

    lines = ["📊 <b>Топ операторов:</b>\n"]
    for row in rows:
        avg_min = round(row.avg_completion_seconds / 60, 1) if row.avg_completion_seconds else "—"
        lines.append(
            f"• {row.username or 'N/A'}: {row.completed_orders} заказов, "
            f"{row.total_earned} заработано, ~{avg_min} мин/заказ"
        )

    await callback.message.edit_text("\n".join(lines))
    await callback.answer()


@router.callback_query(F.data == "admin:monitor")
async def cb_admin_monitor(
    callback: CallbackQuery, session: AsyncSession, user: User
) -> None:
    if not _require_admin(user):
        await callback.answer("Доступ запрещён", show_alert=True)
        return

    order_repo = OrderRepository(session)
    counts = await order_repo.count_by_status()

    stuck_threshold = datetime.now(timezone.utc) - timedelta(hours=1)
    stuck_stmt = text("""
        SELECT COUNT(*) FROM orders
        WHERE status = 'claimed' AND claimed_at < :threshold
    """)
    stuck_result = await session.execute(stuck_stmt, {"threshold": stuck_threshold})
    stuck_count = stuck_result.scalar_one()

    lines = ["🔍 <b>Мониторинг заказов:</b>\n"]
    for status_name, count in counts.items():
        lines.append(f"• {status_name}: {count}")
    lines.append(f"\n⚠️ Зависшие заказы (>1ч в claimed): {stuck_count}")

    await callback.message.edit_text("\n".join(lines))
    await callback.answer()


# ─────────────────────────────────────────────────────────────────────────────
# Payouts
# ─────────────────────────────────────────────────────────────────────────────

@router.callback_query(F.data.startswith("calc_payout:"))
async def cb_calc_payout_start(
    callback: CallbackQuery, state: FSMContext, user: User
) -> None:
    if not _require_admin(user):
        await callback.answer("Доступ запрещён", show_alert=True)
        return

    operator_id = uuid.UUID(callback.data.split(":", 1)[1])
    await state.update_data(operator_id=str(operator_id))

    await callback.message.edit_text(
        "Введите период в формате YYYY-MM-DD:YYYY-MM-DD\n"
        "(например: 2026-06-01:2026-06-15)"
    )
    await state.set_state(AdminPayoutStates.selecting_period)
    await callback.answer()


@router.message(AdminPayoutStates.selecting_period)
async def msg_payout_period(
    message: Message, session: AsyncSession, state: FSMContext, user: User
) -> None:
    raw = (message.text or "").strip()
    parts = raw.split(":")
    if len(parts) != 2:
        await message.answer("⚠️ Неверный формат. Пример: 2026-06-01:2026-06-15")
        return

    try:
        period_start = date.fromisoformat(parts[0])
        period_end = date.fromisoformat(parts[1])
    except ValueError:
        await message.answer("⚠️ Неверный формат даты. Используйте YYYY-MM-DD.")
        return

    if period_end < period_start:
        await message.answer("⚠️ Дата конца периода раньше начала.")
        return

    data = await state.get_data()
    operator_id = uuid.UUID(data["operator_id"])

    # Защита от дублирования payout за тот же период
    existing_stmt = select(Payout).where(
        Payout.operator_id == operator_id,
        Payout.period_start == period_start,
        Payout.period_end == period_end,
    )
    existing = (await session.execute(existing_stmt)).scalar_one_or_none()
    if existing:
        await message.answer(
            f"⚠️ Выплата за этот период уже существует (id: {existing.id}, "
            f"сумма: {existing.amount}, статус: {existing.status.value})."
        )
        await state.clear()
        return

    period_start_dt = datetime.combine(period_start, datetime.min.time()).replace(
        tzinfo=timezone.utc
    )
    period_end_dt = datetime.combine(period_end, datetime.max.time()).replace(
        tzinfo=timezone.utc
    )

    order_repo = OrderRepository(session)
    orders = await order_repo.get_completed_for_payout(
        operator_id, period_start_dt, period_end_dt
    )

    if not orders:
        await message.answer("⚠️ Нет выполненных заказов за этот период.")
        await state.clear()
        return

    total_amount = sum(
        (o.product.reward_amount if o.product else Decimal("0")) for o in orders
    )

    payout = Payout(
        operator_id=operator_id,
        amount=total_amount,
        status=PayoutStatus.pending,
        period_start=period_start,
        period_end=period_end,
        order_ids=[o.id for o in orders],
        orders_count=len(orders),
    )
    session.add(payout)
    await session.flush()
    await session.refresh(payout)

    audit = AuditService(session)
    await audit.log(
        action="payout.calculated",
        entity_type="payout",
        entity_id=payout.id,
        actor_id=user.id,
        after_data={"amount": str(total_amount), "orders_count": len(orders)},
    )

    await message.answer(
        f"💰 <b>Расчёт выплаты:</b>\n\n"
        f"Заказов: {len(orders)}\n"
        f"Сумма: {total_amount}\n"
        f"Период: {period_start} — {period_end}\n\n"
        f"Подтвердите выплату:",
        reply_markup=payout_confirm_keyboard(payout.id),
    )
    await state.clear()


@router.callback_query(F.data.startswith("confirm_payout:"))
async def cb_confirm_payout(
    callback: CallbackQuery, session: AsyncSession, user: User
) -> None:
    if not _require_admin(user):
        await callback.answer("Доступ запрещён", show_alert=True)
        return

    payout_id = uuid.UUID(callback.data.split(":", 1)[1])
    payout = await session.get(Payout, payout_id)
    if not payout:
        await callback.answer("Выплата не найдена", show_alert=True)
        return

    if payout.status != PayoutStatus.pending:
        await callback.answer(
            f"Выплата уже в статусе {payout.status.value}", show_alert=True
        )
        return

    payout.status = PayoutStatus.confirmed
    payout.confirmed_by = user.id
    payout.confirmed_at = datetime.now(timezone.utc)

    audit = AuditService(session)
    await audit.log(
        action="payout.confirmed",
        entity_type="payout",
        entity_id=payout.id,
        actor_id=user.id,
    )

    await callback.message.edit_text(
        f"✅ Выплата подтверждена.\nСумма: {payout.amount}"
    )
    await callback.answer("Подтверждено ✅")
