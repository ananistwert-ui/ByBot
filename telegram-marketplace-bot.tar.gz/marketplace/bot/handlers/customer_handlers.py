import uuid

import structlog
from aiogram import F, Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from bot.keyboards.customer_keyboards import (
    catalog_keyboard,
    payment_check_keyboard,
    product_detail_keyboard,
)
from bot.states.states import CustomerStates
from core.repositories.inventory_repository import InventoryRepository
from core.repositories.order_repository import OrderRepository
from core.repositories.payment_repository import PaymentRepository
from core.services.audit_service import AuditService
from core.services.order_service import OrderService
from core.services.payment_service import CryptoBotService
from models.models import OrderStatus, Product, User

logger = structlog.get_logger(__name__)
router = Router(name="customer")


def _build_order_service(session: AsyncSession) -> OrderService:
    return OrderService(
        order_repo=OrderRepository(session),
        inventory_repo=InventoryRepository(session),
        audit_service=AuditService(session),
        cryptobot=CryptoBotService(),
    )


@router.message(Command("start"))
async def cmd_start(message: Message, user: User, session: AsyncSession) -> None:
    await message.answer(
        f"👋 Привет, {user.first_name or 'друг'}!\n\n"
        "Это маркетплейс премиум-подписок.\n"
        "Используй /catalog чтобы посмотреть товары."
    )


@router.message(Command("catalog"))
async def cmd_catalog(message: Message, session: AsyncSession, state: FSMContext) -> None:
    await _show_catalog(message, session, state)


@router.callback_query(F.data == "catalog:back")
async def cb_catalog_back(
    callback: CallbackQuery, session: AsyncSession, state: FSMContext
) -> None:
    await _show_catalog(callback.message, session, state, edit=True)
    await callback.answer()


async def _show_catalog(
    message: Message,
    session: AsyncSession,
    state: FSMContext,
    edit: bool = False,
) -> None:
    stmt = text("""
        SELECT id, title, description, price, currency, total_stock
        FROM v_product_catalog
    """)
    result = await session.execute(stmt)
    products = [
        {
            "id": row.id,
            "title": row.title,
            "price": row.price,
            "currency": row.currency,
            "total_stock": row.total_stock,
        }
        for row in result.all()
    ]

    if not products:
        text_msg = "😔 Каталог пуст. Загляните позже."
    else:
        text_msg = "🛍 <b>Каталог товаров:</b>"

    keyboard = catalog_keyboard(products) if products else None

    if edit:
        await message.edit_text(text_msg, reply_markup=keyboard)
    else:
        await message.answer(text_msg, reply_markup=keyboard)

    await state.set_state(CustomerStates.browsing_catalog)


@router.callback_query(F.data.startswith("product:"))
async def cb_view_product(
    callback: CallbackQuery, session: AsyncSession, state: FSMContext
) -> None:
    product_id = uuid.UUID(callback.data.split(":", 1)[1])
    product = await session.get(Product, product_id)

    if not product or not product.is_active or product.is_archived:
        await callback.answer("Товар недоступен", show_alert=True)
        return

    inv_repo = InventoryRepository(session)
    stock_map = await inv_repo.get_total_stock_by_product()
    total_stock = stock_map.get(str(product_id), 0)

    text_msg = (
        f"📦 <b>{product.title}</b>\n\n"
        f"{product.description or ''}\n\n"
        f"💰 Цена: {product.price} {product.currency}\n"
        f"📊 В наличии: {total_stock} шт."
    )

    await callback.message.edit_text(
        text_msg,
        reply_markup=product_detail_keyboard(product_id, in_stock=total_stock > 0),
    )
    await state.update_data(selected_product_id=str(product_id))
    await state.set_state(CustomerStates.viewing_product)
    await callback.answer()


@router.callback_query(F.data.startswith("buy:"))
async def cb_buy_product(
    callback: CallbackQuery,
    session: AsyncSession,
    user: User,
    state: FSMContext,
) -> None:
    """
    Создаёт invoice + order(pending_payment).
    КРИТИЧНО: проверка наличия товара повторяется здесь, так как
    между просмотром продукта и нажатием "Купить" сток может измениться.
    Финальная защита — на уровне claim в order pool (атомарный UPDATE).
    """
    product_id = uuid.UUID(callback.data.split(":", 1)[1])
    product = await session.get(Product, product_id)

    if not product or not product.is_active or product.is_archived:
        await callback.answer("Товар недоступен", show_alert=True)
        return

    inv_repo = InventoryRepository(session)
    stock_map = await inv_repo.get_total_stock_by_product()
    if stock_map.get(str(product_id), 0) <= 0:
        await callback.answer("К сожалению, товар закончился", show_alert=True)
        return

    order_service = _build_order_service(session)

    try:
        order, pay_url = await order_service.create_pending_order(user, product)
    except Exception as e:
        logger.error("order_creation_failed", error=str(e))
        await callback.answer(
            "Ошибка при создании заказа. Попробуйте позже.", show_alert=True
        )
        return

    text_msg = (
        f"💳 <b>Оплата заказа</b>\n\n"
        f"Товар: {product.title}\n"
        f"Сумма: {order.amount} {order.currency}\n\n"
        f"Нажмите кнопку ниже для оплаты через CryptoBot.\n"
        f"После оплаты нажмите «Проверить оплату»."
    )

    from aiogram.types import InlineKeyboardButton
    from aiogram.utils.keyboard import InlineKeyboardBuilder

    builder = InlineKeyboardBuilder()
    builder.row(InlineKeyboardButton(text="💳 Перейти к оплате", url=pay_url))
    builder.row(
        InlineKeyboardButton(
            text="🔄 Проверить оплату",
            callback_data=f"check_payment:{order.id}",
        )
    )

    await callback.message.edit_text(text_msg, reply_markup=builder.as_markup())
    await state.set_state(CustomerStates.awaiting_payment)
    await state.update_data(order_id=str(order.id))
    await callback.answer()


@router.callback_query(F.data.startswith("check_payment:"))
async def cb_check_payment(
    callback: CallbackQuery,
    session: AsyncSession,
    user: User,
) -> None:
    """
    Ручная проверка статуса оплаты.
    Основной механизм подтверждения — webhook, эта кнопка для UX
    (на случай если webhook задержался или для нетерпеливых пользователей).
    """
    order_id = uuid.UUID(callback.data.split(":", 1)[1])
    order_repo = OrderRepository(session)
    order = await order_repo.get_by_id(order_id)

    if not order or order.customer_id != user.id:
        await callback.answer("Заказ не найден", show_alert=True)
        return

    status_messages = {
        OrderStatus.pending_payment: "⏳ Оплата ещё не получена. Попробуйте через минуту.",
        OrderStatus.paid: "✅ Оплата получена! Заказ передан оператору.",
        OrderStatus.in_pool: "✅ Оплата получена! Заказ передан оператору.",
        OrderStatus.claimed: "👨‍💻 Оператор уже работает над вашим заказом.",
        OrderStatus.completed: "🎉 Заказ выполнен! Спасибо за покупку.",
        OrderStatus.cancelled: "❌ Заказ отменён.",
        OrderStatus.refunded: "💸 Средства возвращены.",
    }

    msg = status_messages.get(order.status, "Статус неизвестен")

    if order.status == OrderStatus.pending_payment:
        await callback.answer(msg, show_alert=True)
    else:
        await callback.message.edit_text(msg)
        await callback.answer()


@router.message(Command("orders"))
async def cmd_my_orders(message: Message, session: AsyncSession, user: User) -> None:
    order_repo = OrderRepository(session)
    orders = await order_repo.get_customer_orders(user.id, limit=10)

    if not orders:
        await message.answer("У вас пока нет заказов.")
        return

    status_emoji = {
        OrderStatus.pending_payment: "⏳",
        OrderStatus.paid: "💰",
        OrderStatus.in_pool: "📦",
        OrderStatus.claimed: "👨‍💻",
        OrderStatus.completed: "✅",
        OrderStatus.cancelled: "❌",
        OrderStatus.refunded: "💸",
    }

    lines = ["📋 <b>Ваши заказы:</b>\n"]
    for o in orders:
        emoji = status_emoji.get(o.status, "")
        lines.append(
            f"{emoji} {o.product.title if o.product else 'N/A'} — "
            f"{o.amount} {o.currency} ({o.status.value})"
        )

    await message.answer("\n".join(lines))
