import uuid

from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup
from aiogram.utils.keyboard import InlineKeyboardBuilder


def shift_keyboard(is_active: bool) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    if is_active:
        builder.row(
            InlineKeyboardButton(text="🔴 Завершить смену", callback_data="shift:stop")
        )
    else:
        builder.row(
            InlineKeyboardButton(text="🟢 Начать смену", callback_data="shift:start")
        )
    return builder.as_markup()


def operator_menu_keyboard() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="📦 Пул заказов", callback_data="pool:show"),
        InlineKeyboardButton(text="📋 Мои заказы", callback_data="orders:mine"),
    )
    builder.row(
        InlineKeyboardButton(text="📊 Инвентарь", callback_data="inventory:show"),
        InlineKeyboardButton(text="⚙️ Смена", callback_data="shift:menu"),
    )
    return builder.as_markup()


def order_pool_keyboard(orders: list[dict]) -> InlineKeyboardMarkup:
    """orders: [{"id": uuid, "product_title": str, "amount": Decimal}, ...]"""
    builder = InlineKeyboardBuilder()
    for o in orders:
        builder.row(
            InlineKeyboardButton(
                text=f"📦 {o['product_title']} — {o['amount']} {o['currency']}",
                callback_data=f"claim:{o['id']}",
            )
        )
    builder.row(
        InlineKeyboardButton(text="🔄 Обновить", callback_data="pool:show")
    )
    return builder.as_markup()


def claimed_order_keyboard(order_id: uuid.UUID) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(
            text="✅ Выполнено",
            callback_data=f"complete:{order_id}",
        )
    )
    return builder.as_markup()


def inventory_keyboard(items: list[dict]) -> InlineKeyboardMarkup:
    """items: [{"product_id": uuid, "title": str, "quantity_available": int}, ...]"""
    builder = InlineKeyboardBuilder()
    for item in items:
        builder.row(
            InlineKeyboardButton(
                text=f"{item['title']}: {item['quantity_available']} шт. ✏️",
                callback_data=f"edit_inventory:{item['product_id']}",
            )
        )
    builder.row(
        InlineKeyboardButton(text="➕ Добавить товар", callback_data="add_inventory")
    )
    return builder.as_markup()


def product_select_keyboard(products: list[dict]) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for p in products:
        builder.row(
            InlineKeyboardButton(
                text=p["title"],
                callback_data=f"select_product:{p['id']}",
            )
        )
    return builder.as_markup()
