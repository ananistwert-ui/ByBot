import uuid

from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup
from aiogram.utils.keyboard import InlineKeyboardBuilder


def catalog_keyboard(products: list[dict]) -> InlineKeyboardMarkup:
    """
    products: [{"id": uuid, "title": str, "price": Decimal, "total_stock": int}, ...]
    """
    builder = InlineKeyboardBuilder()
    for p in products:
        stock_label = f" ({p['total_stock']} шт.)" if p["total_stock"] > 0 else " — нет в наличии"
        builder.row(
            InlineKeyboardButton(
                text=f"{p['title']} — {p['price']} {p['currency']}{stock_label}",
                callback_data=f"product:{p['id']}",
            )
        )
    return builder.as_markup()


def product_detail_keyboard(product_id: uuid.UUID, in_stock: bool) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    if in_stock:
        builder.row(
            InlineKeyboardButton(
                text="💳 Купить",
                callback_data=f"buy:{product_id}",
            )
        )
    builder.row(
        InlineKeyboardButton(text="⬅️ Назад к каталогу", callback_data="catalog:back")
    )
    return builder.as_markup()


def payment_check_keyboard(order_id: uuid.UUID) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(
            text="🔄 Проверить оплату",
            callback_data=f"check_payment:{order_id}",
        )
    )
    return builder.as_markup()
