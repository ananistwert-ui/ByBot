import uuid

from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup
from aiogram.utils.keyboard import InlineKeyboardBuilder


def admin_menu_keyboard() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="📦 Товары", callback_data="admin:products"),
        InlineKeyboardButton(text="👥 Операторы", callback_data="admin:operators"),
    )
    builder.row(
        InlineKeyboardButton(text="📊 Статистика", callback_data="admin:stats"),
        InlineKeyboardButton(text="💰 Выплаты", callback_data="admin:payouts"),
    )
    builder.row(
        InlineKeyboardButton(text="🔍 Мониторинг заказов", callback_data="admin:monitor"),
    )
    return builder.as_markup()


def products_admin_keyboard(products: list[dict]) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for p in products:
        status_icon = "🟢" if p["is_active"] else "🔴"
        builder.row(
            InlineKeyboardButton(
                text=f"{status_icon} {p['title']}",
                callback_data=f"admin_product:{p['id']}",
            )
        )
    builder.row(
        InlineKeyboardButton(text="➕ Новый товар", callback_data="admin_product:new")
    )
    return builder.as_markup()


def product_actions_keyboard(product_id: uuid.UUID, is_active: bool) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    toggle_text = "🔴 Отключить" if is_active else "🟢 Включить"
    builder.row(
        InlineKeyboardButton(
            text=toggle_text,
            callback_data=f"toggle_product:{product_id}",
        )
    )
    builder.row(
        InlineKeyboardButton(
            text="🗑 Архивировать",
            callback_data=f"archive_product:{product_id}",
        )
    )
    return builder.as_markup()


def operators_admin_keyboard(operators: list[dict]) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for op in operators:
        status_icon = "🟢" if op["is_active"] else "⚪️"
        builder.row(
            InlineKeyboardButton(
                text=f"{status_icon} {op['username'] or op['telegram_id']}",
                callback_data=f"admin_operator:{op['id']}",
            )
        )
    return builder.as_markup()


def operator_actions_keyboard(operator_id: uuid.UUID, is_banned: bool) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    ban_text = "✅ Разбанить" if is_banned else "🚫 Забанить"
    builder.row(
        InlineKeyboardButton(
            text=ban_text,
            callback_data=f"ban_toggle:{operator_id}",
        ),
        InlineKeyboardButton(
            text="💰 Рассчитать выплату",
            callback_data=f"calc_payout:{operator_id}",
        ),
    )
    return builder.as_markup()


def payout_confirm_keyboard(payout_id: uuid.UUID) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(
            text="✅ Подтвердить выплату",
            callback_data=f"confirm_payout:{payout_id}",
        )
    )
    return builder.as_markup()
