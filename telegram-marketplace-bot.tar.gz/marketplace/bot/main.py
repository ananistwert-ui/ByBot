import asyncio

import structlog
from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.fsm.storage.redis import RedisStorage
from aiogram.webhook.aiohttp_server import SimpleRequestHandler, setup_application
from aiohttp import web
from redis.asyncio import Redis

from bot.handlers import admin_handlers, customer_handlers, operator_handlers
from bot.middlewares.auth_middleware import AuthMiddleware
from bot.middlewares.db_middleware import DatabaseMiddleware
from bot.middlewares.throttling_middleware import ThrottlingMiddleware
from config.logging import configure_logging
from config.settings import settings
from models.database import AsyncSessionFactory, engine

logger = structlog.get_logger(__name__)


def create_bot() -> Bot:
    return Bot(
        token=settings.BOT_TOKEN,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML),
    )


def create_dispatcher(redis: Redis) -> Dispatcher:
    """
    Создаёт Dispatcher с FSM storage в Redis (переживает restart бота)
    и подключает все middlewares + routers.
    """
    storage = RedisStorage(redis=redis)
    dp = Dispatcher(storage=storage)

    # ── Middlewares (порядок важен) ───────────────────────────────────────────
    # 1. DB session — должна быть первой, остальные могут её использовать
    dp.update.middleware(DatabaseMiddleware(AsyncSessionFactory))
    # 2. Auth — определяет роль пользователя, баны
    dp.update.middleware(AuthMiddleware())
    # 3. Throttling — защита от спама командами
    dp.message.middleware(ThrottlingMiddleware(redis))
    dp.callback_query.middleware(ThrottlingMiddleware(redis))

    # ── Routers по ролям ─────────────────────────────────────────────────────
    dp.include_router(customer_handlers.router)
    dp.include_router(operator_handlers.router)
    dp.include_router(admin_handlers.router)

    return dp


async def on_startup(bot: Bot) -> None:
    webhook_info = await bot.get_webhook_info()
    if webhook_info.url != settings.BOT_WEBHOOK_URL:
        await bot.set_webhook(
            url=settings.BOT_WEBHOOK_URL,
            secret_token=settings.BOT_WEBHOOK_SECRET,
            allowed_updates=["message", "callback_query"],
            drop_pending_updates=True,
        )
    logger.info("bot_webhook_set", url=settings.BOT_WEBHOOK_URL)


async def on_shutdown(bot: Bot) -> None:
    await bot.delete_webhook()
    await engine.dispose()
    logger.info("bot_shutdown_complete")


def create_webhook_app() -> web.Application:
    """
    Production: используем webhook вместо polling.
    Polling не масштабируется горизонтально и менее надёжен под нагрузкой.
    """
    configure_logging()

    redis = Redis.from_url(settings.redis_url_str, decode_responses=False)
    bot = create_bot()
    dp = create_dispatcher(redis)

    dp.startup.register(on_startup)
    dp.shutdown.register(on_shutdown)

    app = web.Application()

    # SimpleRequestHandler проверяет secret_token автоматически —
    # защита от подделки webhook-запросов (кто угодно может POST на публичный URL)
    webhook_handler = SimpleRequestHandler(
        dispatcher=dp,
        bot=bot,
        secret_token=settings.BOT_WEBHOOK_SECRET,
    )
    webhook_handler.register(app, path="/webhook/bot")

    setup_application(app, dp, bot=bot)
    return app


def main() -> None:
    app = create_webhook_app()
    web.run_app(app, host=settings.APP_HOST, port=settings.APP_PORT)


if __name__ == "__main__":
    main()
