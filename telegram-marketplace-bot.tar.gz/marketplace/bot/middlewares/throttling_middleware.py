from collections.abc import Awaitable, Callable
from typing import Any

from aiogram import BaseMiddleware
from aiogram.types import CallbackQuery, Message, TelegramObject
from redis.asyncio import Redis

from config.settings import settings


class ThrottlingMiddleware(BaseMiddleware):
    """
    Redis-based rate limit для бота.
    Защита от:
    - спама командами (DoS на бота)
    - брутфорса callback кнопок (например, попытки угадать order_id)
    """

    def __init__(self, redis: Redis) -> None:
        self._redis = redis
        self._limit_per_second = settings.RATE_LIMIT_BOT_PER_SECOND

    async def __call__(
        self,
        handler: Callable[[TelegramObject, dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: dict[str, Any],
    ) -> Any:
        user_id = self._extract_user_id(event)
        if user_id is None:
            return await handler(event, data)

        key = f"throttle:{user_id}"
        current = await self._redis.incr(key)
        if current == 1:
            await self._redis.expire(key, 1)  # окно 1 секунда

        if current > self._limit_per_second:
            # Тихо игнорируем — не отвечаем, чтобы не плодить лишний трафик
            return None

        return await handler(event, data)

    @staticmethod
    def _extract_user_id(event: TelegramObject) -> int | None:
        if isinstance(event, Message):
            return event.from_user.id if event.from_user else None
        if isinstance(event, CallbackQuery):
            return event.from_user.id
        return None
