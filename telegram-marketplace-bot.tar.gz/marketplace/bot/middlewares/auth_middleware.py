from collections.abc import Awaitable, Callable
from typing import Any

import structlog
from aiogram import BaseMiddleware
from aiogram.types import CallbackQuery, Message, TelegramObject, Update
from sqlalchemy import select

from core.repositories.operator_repository import OperatorRepository
from models.models import Operator, User, UserRole

logger = structlog.get_logger(__name__)


class AuthMiddleware(BaseMiddleware):
    """
    На каждый update:
    1. Находит или создаёт User по telegram_id
    2. Проверяет is_banned — если забанен, прерывает обработку
    3. Если role == operator, загружает Operator profile
    4. Прокидывает user/operator в data для всех handlers
    """

    async def __call__(
        self,
        handler: Callable[[TelegramObject, dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: dict[str, Any],
    ) -> Any:
        session = data["session"]

        tg_user = self._extract_telegram_user(event)
        if not tg_user:
            return await handler(event, data)

        stmt = select(User).where(User.telegram_id == tg_user.id)
        result = await session.execute(stmt)
        user = result.scalar_one_or_none()

        if not user:
            user = User(
                telegram_id=tg_user.id,
                username=tg_user.username,
                first_name=tg_user.first_name,
                last_name=tg_user.last_name,
                role=UserRole.customer,
            )
            session.add(user)
            await session.flush()
            logger.info("new_user_registered", telegram_id=tg_user.id)

        if user.is_banned:
            await self._notify_banned(event)
            return  # прерываем pipeline — handler не вызывается

        data["user"] = user
        structlog.contextvars.bind_contextvars(
            telegram_id=tg_user.id, role=user.role.value
        )

        if user.role == UserRole.operator:
            op_repo = OperatorRepository(session)
            operator = await op_repo.get_by_user_id(user.id)
            data["operator"] = operator
            if operator:
                await op_repo.update_last_seen(operator.id)

        return await handler(event, data)

    @staticmethod
    def _extract_telegram_user(event: TelegramObject):
        if isinstance(event, Update):
            if event.message:
                return event.message.from_user
            if event.callback_query:
                return event.callback_query.from_user
        if isinstance(event, Message):
            return event.from_user
        if isinstance(event, CallbackQuery):
            return event.from_user
        return None

    @staticmethod
    async def _notify_banned(event: TelegramObject) -> None:
        text = "🚫 Ваш аккаунт заблокирован. Обратитесь к администратору."
        if isinstance(event, Message):
            await event.answer(text)
        elif isinstance(event, CallbackQuery):
            await event.answer(text, show_alert=True)
        elif isinstance(event, Update):
            if event.message:
                await event.message.answer(text)
            elif event.callback_query:
                await event.callback_query.answer(text, show_alert=True)
