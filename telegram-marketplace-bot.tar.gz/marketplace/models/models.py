import uuid
from datetime import date, datetime
from decimal import Decimal
from typing import TYPE_CHECKING

from sqlalchemy import (
    BigInteger,
    Boolean,
    CheckConstraint,
    Date,
    DateTime,
    Enum,
    ForeignKey,
    Index,
    Integer,
    Numeric,
    String,
    Text,
    UniqueConstraint,
    text,
)
from sqlalchemy.dialects.postgresql import ARRAY, INET, JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from models.base import Base, TimestampMixin, UUIDPrimaryKeyMixin

if TYPE_CHECKING:
    pass

import enum


# ─────────────────────────────────────────────────────────────────────────────
# Python Enums (зеркалят PostgreSQL enums)
# ─────────────────────────────────────────────────────────────────────────────

class UserRole(str, enum.Enum):
    customer   = "customer"
    operator   = "operator"
    superadmin = "superadmin"


class OrderStatus(str, enum.Enum):
    pending_payment = "pending_payment"
    paid            = "paid"
    in_pool         = "in_pool"
    claimed         = "claimed"
    completed       = "completed"
    cancelled       = "cancelled"
    refunded        = "refunded"


class PaymentStatus(str, enum.Enum):
    pending  = "pending"
    paid     = "paid"
    failed   = "failed"
    refunded = "refunded"


class PayoutStatus(str, enum.Enum):
    pending   = "pending"
    confirmed = "confirmed"
    paid      = "paid"
    cancelled = "cancelled"


# ─────────────────────────────────────────────────────────────────────────────
# User
# ─────────────────────────────────────────────────────────────────────────────

class User(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "users"
    __table_args__ = (
        Index("uq_users_telegram_id", "telegram_id", unique=True),
        Index("idx_users_role", "role"),
        Index(
            "idx_users_active", "telegram_id",
            postgresql_where=text("is_banned = FALSE"),
        ),
    )

    telegram_id: Mapped[int]  = mapped_column(BigInteger, nullable=False)
    username:    Mapped[str | None] = mapped_column(String(64))
    first_name:  Mapped[str | None] = mapped_column(String(128))
    last_name:   Mapped[str | None] = mapped_column(String(128))
    role:        Mapped[UserRole] = mapped_column(
        Enum(UserRole, name="user_role"),
        nullable=False,
        default=UserRole.customer,
        server_default=UserRole.customer.value,
    )
    is_banned:  Mapped[bool] = mapped_column(
        Boolean, nullable=False, default=False, server_default="false"
    )
    ban_reason: Mapped[str | None] = mapped_column(Text)

    # Relationships
    operator:  Mapped["Operator | None"] = relationship(
        back_populates="user", uselist=False
    )
    orders:    Mapped[list["Order"]] = relationship(
        back_populates="customer",
        foreign_keys="Order.customer_id",
    )
    sessions:  Mapped[list["Session"]] = relationship(back_populates="user")
    audit_logs: Mapped[list["AuditLog"]] = relationship(back_populates="actor")

    def __repr__(self) -> str:
        return f"<User {self.telegram_id} role={self.role}>"


# ─────────────────────────────────────────────────────────────────────────────
# Operator
# ─────────────────────────────────────────────────────────────────────────────

class Operator(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "operators"
    __table_args__ = (
        UniqueConstraint("user_id", name="uq_operators_user_id"),
        Index(
            "idx_operators_active", "id",
            postgresql_where=text("is_active = TRUE"),
        ),
        CheckConstraint("total_earned >= 0", name="chk_operators_earned_positive"),
    )

    user_id:          Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id", ondelete="CASCADE"),
        nullable=False,
    )
    is_active:        Mapped[bool] = mapped_column(
        Boolean, nullable=False, default=False, server_default="false"
    )
    shift_started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    last_seen:        Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    total_earned:     Mapped[Decimal] = mapped_column(
        Numeric(12, 2), nullable=False, default=Decimal("0.00"),
        server_default="0.00",
    )

    # Relationships
    user:      Mapped["User"] = relationship(back_populates="operator")
    inventory: Mapped[list["OperatorInventory"]] = relationship(
        back_populates="operator", cascade="all, delete-orphan"
    )
    orders:    Mapped[list["Order"]] = relationship(
        back_populates="operator",
        foreign_keys="Order.operator_id",
    )
    payouts:   Mapped[list["Payout"]] = relationship(back_populates="operator")

    def __repr__(self) -> str:
        return f"<Operator user={self.user_id} active={self.is_active}>"


# ─────────────────────────────────────────────────────────────────────────────
# Product
# ─────────────────────────────────────────────────────────────────────────────

class Product(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "products"
    __table_args__ = (
        Index(
            "idx_products_active", "sort_order",
            postgresql_where=text("is_active = TRUE AND is_archived = FALSE"),
        ),
        CheckConstraint("price > 0",            name="chk_products_price_positive"),
        CheckConstraint("reward_amount >= 0",   name="chk_products_reward_positive"),
    )

    title:         Mapped[str]     = mapped_column(String(256), nullable=False)
    description:   Mapped[str | None] = mapped_column(Text)
    price:         Mapped[Decimal] = mapped_column(Numeric(12, 2), nullable=False)
    currency:      Mapped[str]     = mapped_column(
        String(10), nullable=False, default="USDT", server_default="USDT"
    )
    reward_amount: Mapped[Decimal] = mapped_column(
        Numeric(12, 2), nullable=False,
        default=Decimal("0.00"), server_default="0.00",
    )
    is_active:    Mapped[bool] = mapped_column(
        Boolean, nullable=False, default=True, server_default="true"
    )
    is_archived:  Mapped[bool] = mapped_column(
        Boolean, nullable=False, default=False, server_default="false"
    )
    sort_order:   Mapped[int] = mapped_column(
        Integer, nullable=False, default=0, server_default="0"
    )

    # Relationships
    inventory: Mapped[list["OperatorInventory"]] = relationship(
        back_populates="product"
    )
    orders:    Mapped[list["Order"]] = relationship(back_populates="product")

    def __repr__(self) -> str:
        return f"<Product {self.title!r} price={self.price}>"


# ─────────────────────────────────────────────────────────────────────────────
# OperatorInventory
# ─────────────────────────────────────────────────────────────────────────────

class OperatorInventory(Base, UUIDPrimaryKeyMixin):
    __tablename__ = "operator_inventory"
    __table_args__ = (
        UniqueConstraint(
            "operator_id", "product_id",
            name="uq_inventory_operator_product",
        ),
        Index(
            "idx_inventory_available", "product_id", "operator_id",
            postgresql_where=text("quantity_available > 0"),
        ),
        CheckConstraint(
            "quantity_available >= 0",
            name="chk_inventory_available_gte_zero",
        ),
        CheckConstraint(
            "quantity_reserved >= 0",
            name="chk_inventory_reserved_gte_zero",
        ),
        CheckConstraint(
            "quantity_reserved <= quantity_available",
            name="chk_inventory_reserved_lte_avail",
        ),
    )

    operator_id:        Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("operators.id", ondelete="CASCADE"),
        nullable=False,
    )
    product_id:         Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("products.id", ondelete="RESTRICT"),
        nullable=False,
    )
    quantity_available: Mapped[int] = mapped_column(
        Integer, nullable=False, default=0, server_default="0"
    )
    quantity_reserved:  Mapped[int] = mapped_column(
        Integer, nullable=False, default=0, server_default="0"
    )
    updated_at:         Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=text("NOW()"), nullable=False
    )

    # Relationships
    operator: Mapped["Operator"] = relationship(back_populates="inventory")
    product:  Mapped["Product"]  = relationship(back_populates="inventory")


# ─────────────────────────────────────────────────────────────────────────────
# Order
# ─────────────────────────────────────────────────────────────────────────────

class Order(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "orders"
    __table_args__ = (
        Index(
            "idx_orders_pool", "product_id", "created_at",
            postgresql_where=text("status = 'in_pool'"),
        ),
        Index(
            "idx_orders_operator", "operator_id", "status", "created_at",
            postgresql_where=text("operator_id IS NOT NULL"),
        ),
        Index("idx_orders_customer", "customer_id", "created_at"),
        Index(
            "idx_orders_expires", "expires_at",
            postgresql_where=text("status = 'pending_payment'"),
        ),
        CheckConstraint("amount > 0", name="chk_orders_amount_positive"),
        CheckConstraint(
            "(operator_id IS NULL AND claimed_at IS NULL) OR "
            "(operator_id IS NOT NULL AND claimed_at IS NOT NULL)",
            name="chk_orders_claimed_consistency",
        ),
    )

    customer_id:  Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id", ondelete="RESTRICT"),
        nullable=False,
    )
    product_id:   Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("products.id", ondelete="RESTRICT"),
        nullable=False,
    )
    operator_id:  Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("operators.id", ondelete="SET NULL"),
    )
    status:       Mapped[OrderStatus] = mapped_column(
        Enum(OrderStatus, name="order_status"),
        nullable=False,
        default=OrderStatus.pending_payment,
    )
    amount:       Mapped[Decimal]     = mapped_column(Numeric(12, 2), nullable=False)
    currency:     Mapped[str]         = mapped_column(
        String(10), nullable=False, default="USDT"
    )
    claimed_at:   Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    cancelled_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    expires_at:   Mapped[datetime]        = mapped_column(
        DateTime(timezone=True), nullable=False
    )
    admin_note:   Mapped[str | None]  = mapped_column(Text)

    # Relationships
    customer: Mapped["User"]     = relationship(
        back_populates="orders", foreign_keys=[customer_id]
    )
    product:  Mapped["Product"]  = relationship(back_populates="orders")
    operator: Mapped["Operator | None"] = relationship(
        back_populates="orders", foreign_keys=[operator_id]
    )
    payment:  Mapped["Payment | None"] = relationship(
        back_populates="order", uselist=False
    )

    def __repr__(self) -> str:
        return f"<Order {self.id} status={self.status}>"


# ─────────────────────────────────────────────────────────────────────────────
# Payment
# ─────────────────────────────────────────────────────────────────────────────

class Payment(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "payments"
    __table_args__ = (
        UniqueConstraint("external_invoice_id", name="uq_payments_invoice"),
        UniqueConstraint("order_id",            name="uq_payments_order"),
        Index("idx_payments_external_invoice", "external_invoice_id"),
        Index(
            "idx_payments_pending", "status",
            postgresql_where=text("status = 'pending'"),
        ),
    )

    order_id:            Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("orders.id", ondelete="RESTRICT"),
        nullable=False,
    )
    external_invoice_id: Mapped[str]       = mapped_column(String(256), nullable=False)
    external_check_id:   Mapped[str | None] = mapped_column(String(256))
    status:              Mapped[PaymentStatus] = mapped_column(
        Enum(PaymentStatus, name="payment_status"),
        nullable=False,
        default=PaymentStatus.pending,
    )
    amount:              Mapped[Decimal]   = mapped_column(Numeric(12, 2), nullable=False)
    currency:            Mapped[str]       = mapped_column(String(10), nullable=False)
    paid_at:             Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    webhook_payload:     Mapped[dict | None]     = mapped_column(JSONB)

    # Relationships
    order: Mapped["Order"] = relationship(back_populates="payment")


# ─────────────────────────────────────────────────────────────────────────────
# Payout
# ─────────────────────────────────────────────────────────────────────────────

class Payout(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "payouts"
    __table_args__ = (
        Index("idx_payouts_operator", "operator_id", "created_at"),
        Index(
            "idx_payouts_status", "status",
            postgresql_where=text("status IN ('pending', 'confirmed')"),
        ),
        CheckConstraint("amount > 0",              name="chk_payouts_amount_positive"),
        CheckConstraint("period_end >= period_start", name="chk_payouts_period"),
    )

    operator_id:  Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("operators.id", ondelete="RESTRICT"),
        nullable=False,
    )
    amount:       Mapped[Decimal]  = mapped_column(Numeric(12, 2), nullable=False)
    status:       Mapped[PayoutStatus] = mapped_column(
        Enum(PayoutStatus, name="payout_status"),
        nullable=False,
        default=PayoutStatus.pending,
    )
    period_start: Mapped[date]     = mapped_column(Date, nullable=False)
    period_end:   Mapped[date]     = mapped_column(Date, nullable=False)
    order_ids:    Mapped[list[uuid.UUID]] = mapped_column(
        ARRAY(UUID(as_uuid=True)), nullable=False, server_default="{}"
    )
    orders_count: Mapped[int]      = mapped_column(
        Integer, nullable=False, default=0, server_default="0"
    )
    confirmed_by: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id", ondelete="SET NULL"),
    )
    confirmed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    paid_at:      Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    note:         Mapped[str | None] = mapped_column(Text)

    # Relationships
    operator: Mapped["Operator"] = relationship(back_populates="payouts")


# ─────────────────────────────────────────────────────────────────────────────
# AuditLog
# ─────────────────────────────────────────────────────────────────────────────

class AuditLog(Base, UUIDPrimaryKeyMixin):
    """
    Иммутабельная запись. Никогда не обновляется/удаляется через ORM.
    Только INSERT.
    """
    __tablename__ = "audit_logs"
    __table_args__ = (
        Index("idx_audit_actor",  "actor_id",   "created_at"),
        Index("idx_audit_entity", "entity_type", "entity_id", "created_at"),
        Index("idx_audit_action", "action",      "created_at"),
    )

    actor_id:    Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id", ondelete="SET NULL"),
    )
    actor_type:  Mapped[str]      = mapped_column(
        String(32), nullable=False, default="user", server_default="user"
    )
    action:      Mapped[str]      = mapped_column(String(128), nullable=False)
    entity_type: Mapped[str]      = mapped_column(String(64),  nullable=False)
    entity_id:   Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True))
    before_data: Mapped[dict | None] = mapped_column(JSONB)
    after_data:  Mapped[dict | None] = mapped_column(JSONB)
    ip_address:  Mapped[str | None]  = mapped_column(INET)
    meta:        Mapped[dict | None] = mapped_column(JSONB)
    created_at:  Mapped[datetime]    = mapped_column(
        DateTime(timezone=True),
        server_default=text("NOW()"),
        nullable=False,
    )

    # Relationships
    actor: Mapped["User | None"] = relationship(back_populates="audit_logs")


# ─────────────────────────────────────────────────────────────────────────────
# Session
# ─────────────────────────────────────────────────────────────────────────────

class Session(Base, UUIDPrimaryKeyMixin):
    __tablename__ = "sessions"
    __table_args__ = (
        UniqueConstraint("token_hash", name="uq_sessions_token_hash"),
        Index(
            "idx_sessions_user", "user_id",
            postgresql_where=text("is_valid = TRUE"),
        ),
        Index(
            "idx_sessions_expires", "expires_at",
            postgresql_where=text("is_valid = TRUE"),
        ),
    )

    user_id:     Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id", ondelete="CASCADE"),
        nullable=False,
    )
    token_hash:  Mapped[str]      = mapped_column(String(256), nullable=False)
    is_valid:    Mapped[bool]     = mapped_column(
        Boolean, nullable=False, default=True, server_default="true"
    )
    ip_address:  Mapped[str | None] = mapped_column(INET)
    user_agent:  Mapped[str | None] = mapped_column(Text)
    expires_at:  Mapped[datetime]   = mapped_column(
        DateTime(timezone=True), nullable=False
    )
    created_at:  Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=text("NOW()"), nullable=False
    )
    last_used_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=text("NOW()"), nullable=False
    )

    # Relationships
    user: Mapped["User"] = relationship(back_populates="sessions")
