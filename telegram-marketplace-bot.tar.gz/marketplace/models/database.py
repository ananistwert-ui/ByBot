from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager

from sqlalchemy.ext.asyncio import (
    AsyncEngine,
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)

from config.settings import settings


def create_engine() -> AsyncEngine:
    """
    Создаёт async engine с production настройками пула.
    NullPool используется в worker-процессах (Celery).
    """
    return create_async_engine(
        settings.database_url_str,
        pool_size=settings.DATABASE_POOL_SIZE,
        max_overflow=settings.DATABASE_MAX_OVERFLOW,
        pool_timeout=settings.DATABASE_POOL_TIMEOUT,
        pool_pre_ping=True,     # проверяет соединение перед использованием
        pool_recycle=3600,      # переподключение раз в час
        echo=settings.DATABASE_ECHO,
        # JSON сериализация через orjson для скорости
        json_serializer=_orjson_serializer,
        json_deserializer=_orjson_deserializer,
    )


def _orjson_serializer(obj: object) -> str:
    import orjson
    return orjson.dumps(obj).decode()


def _orjson_deserializer(s: str) -> object:
    import orjson
    return orjson.loads(s)


engine: AsyncEngine = create_engine()

AsyncSessionFactory: async_sessionmaker[AsyncSession] = async_sessionmaker(
    engine,
    class_=AsyncSession,
    expire_on_commit=False,  # Важно для async: объекты живут после commit
    autoflush=False,         # Ручной контроль flush
    autocommit=False,
)


async def get_db_session() -> AsyncGenerator[AsyncSession, None]:
    """
    FastAPI dependency для получения сессии БД.
    Автоматически откатывает транзакцию при исключении.
    """
    async with AsyncSessionFactory() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()


@asynccontextmanager
async def get_db_session_context() -> AsyncGenerator[AsyncSession, None]:
    """
    Context manager для использования вне FastAPI (например, в Celery tasks).
    """
    async with AsyncSessionFactory() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()
