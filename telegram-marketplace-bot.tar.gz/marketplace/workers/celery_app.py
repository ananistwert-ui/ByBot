from celery import Celery
from celery.schedules import crontab

from config.settings import settings

celery_app = Celery(
    "marketplace",
    broker=settings.CELERY_BROKER_URL,
    backend=settings.CELERY_RESULT_BACKEND,
    include=["workers.tasks"],
)

celery_app.conf.update(
    task_serializer="json",
    accept_content=["json"],
    result_serializer="json",
    timezone="UTC",
    enable_utc=True,
    task_track_started=True,
    task_time_limit=300,        # hard limit 5 минут
    task_soft_time_limit=240,   # soft limit 4 минуты
    worker_prefetch_multiplier=1,  # важно для долгих задач — не забирать лишнее
    worker_max_tasks_per_child=1000,  # защита от утечек памяти
)

# ─────────────────────────────────────────────────────────────────────────────
# Periodic tasks (Celery Beat)
# ─────────────────────────────────────────────────────────────────────────────

celery_app.conf.beat_schedule = {
    "cancel-expired-orders": {
        "task": "workers.tasks.cancel_expired_orders_task",
        "schedule": crontab(minute="*/2"),  # каждые 2 минуты
    },
    "cleanup-expired-sessions": {
        "task": "workers.tasks.cleanup_expired_sessions_task",
        "schedule": crontab(hour="*/6", minute=0),  # каждые 6 часов
    },
    "alert-stuck-orders": {
        "task": "workers.tasks.alert_stuck_orders_task",
        "schedule": crontab(minute="*/15"),  # каждые 15 минут
    },
}
