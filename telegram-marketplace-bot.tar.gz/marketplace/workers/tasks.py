import asyncio
from datetime import datetime, timedelta, timezone

import structlog

from core.repositories.order_repository import OrderRepository
from core.services.audit_service import AuditService
from models.database import get_db_session_context
from workers.celery_app import celery_app

logger = structlog.get_logger(__name__)


def _run_async(coro):
    """
    Celery worker — синхронный по умолчанию.
    Запускаем async код через новый event loop на каждую задачу.
    """
    loop = asyncio.new_event_loop()
    try:
        return loop.run_until_complete(coro)
    finally:
        loop.close()


@celery_app.task(name="workers.tasks.cancel_expired_orders_task", bind=True, max_retries=3)
def cancel_expired_orders_task(self) -> dict:
    """
    Отменяет заказы, висящие в pending_payment дольше таймаута.
    Защита от "зависших" заказов, которые занимают место в БД
    и могут путать статистику.
    """
    try:
        return _run_async(_cancel_expired_orders())
    except Exception as e:
        logger.error("cancel_expired_orders_failed", error=str(e))
        raise self.retry(exc=e, countdown=30)


async def _cancel_expired_orders() -> dict:
    async with get_db_session_context() as session:
        order_repo = OrderRepository(session)
        audit = AuditService(session)

        count = await order_repo.cancel_expired_orders()

        if count > 0:
            await audit.log_system(
                action="order.batch_expired_cancelled",
                entity_type="order",
                meta={"count": count},
            )
            logger.info("expired_orders_cancelled", count=count)

        return {"cancelled_count": count}


@celery_app.task(name="workers.tasks.cleanup_expired_sessions_task")
def cleanup_expired_sessions_task() -> dict:
    """Инвалидирует истёкшие сессии (housekeeping)."""
    return _run_async(_cleanup_expired_sessions())


async def _cleanup_expired_sessions() -> dict:
    from sqlalchemy import update

    from models.models import Session

    async with get_db_session_context() as session:
        now = datetime.now(timezone.utc)
        stmt = (
            update(Session)
            .where(Session.expires_at < now, Session.is_valid.is_(True))
            .values(is_valid=False)
        )
        result = await session.execute(stmt)
        count = result.rowcount

        if count:
            logger.info("sessions_invalidated", count=count)

        return {"invalidated_count": count}


@celery_app.task(name="workers.tasks.alert_stuck_orders_task")
def alert_stuck_orders_task() -> dict:
    """
    Находит заказы, застрявшие в claimed > 1 час.
    Отправляет алерт админам (через Telegram или Sentry).
    Не отменяет автоматически — требует ручного вмешательства,
    так как причина может быть легитимной (сложный заказ).
    """
    return _run_async(_alert_stuck_orders())


async def _alert_stuck_orders() -> dict:
    from sqlalchemy import select

    from models.models import Order, OrderStatus

    async with get_db_session_context() as session:
        threshold = datetime.now(timezone.utc) - timedelta(hours=1)
        stmt = select(Order).where(
            Order.status == OrderStatus.claimed,
            Order.claimed_at < threshold,
        )
        result = await session.execute(stmt)
        stuck_orders = list(result.scalars().all())

        if stuck_orders:
            logger.warning(
                "stuck_orders_detected",
                count=len(stuck_orders),
                order_ids=[str(o.id) for o in stuck_orders],
            )
            await _notify_admins_stuck_orders(stuck_orders)

        return {"stuck_count": len(stuck_orders)}


async def _notify_admins_stuck_orders(stuck_orders: list) -> None:
    """Отправка уведомления админам через Telegram Bot API."""
    from aiogram import Bot

    from config.settings import settings
    from sqlalchemy import select
    from models.models import User, UserRole
    from models.database import get_db_session_context

    bot = Bot(token=settings.BOT_TOKEN)
    try:
        async with get_db_session_context() as session:
            stmt = select(User).where(User.role == UserRole.superadmin)
            result = await session.execute(stmt)
            admins = result.scalars().all()

        text = (
            f"⚠️ <b>Внимание: {len(stuck_orders)} зависших заказов</b>\n"
            f"(в статусе claimed более 1 часа)\n\n"
            + "\n".join(f"• Order {o.id}" for o in stuck_orders[:10])
        )

        for admin in admins:
            try:
                await bot.send_message(admin.telegram_id, text, parse_mode="HTML")
            except Exception as e:
                logger.error(
                    "admin_notification_failed",
                    admin_id=str(admin.id),
                    error=str(e),
                )
    finally:
        await bot.session.close()


@celery_app.task(name="workers.tasks.send_payout_reminder_task")
def send_payout_reminder_task(operator_telegram_id: int, amount: str) -> None:
    """Уведомляет оператора о новой выплате."""
    _run_async(_send_payout_reminder(operator_telegram_id, amount))


async def _send_payout_reminder(telegram_id: int, amount: str) -> None:
    from aiogram import Bot

    from config.settings import settings

    bot = Bot(token=settings.BOT_TOKEN)
    try:
        await bot.send_message(
            telegram_id,
            f"💰 Рассчитана новая выплата на сумму {amount}. "
            f"Ожидайте подтверждения от администратора.",
        )
    finally:
        await bot.session.close()
