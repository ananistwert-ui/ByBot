import time
import uuid
from typing import Callable

import structlog
from fastapi import Request, Response, status
from fastapi.responses import ORJSONResponse
from redis.asyncio import Redis
from starlette.middleware.base import BaseHTTPMiddleware

from config.settings import settings

logger = structlog.get_logger(__name__)


class RequestIDMiddleware(BaseHTTPMiddleware):
    """Добавляет уникальный X-Request-ID к каждому запросу."""

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        request_id = request.headers.get("X-Request-ID", str(uuid.uuid4()))
        structlog.contextvars.clear_contextvars()
        structlog.contextvars.bind_contextvars(request_id=request_id)
        response = await call_next(request)
        response.headers["X-Request-ID"] = request_id
        return response


class StructlogMiddleware(BaseHTTPMiddleware):
    """Structured logging для каждого HTTP запроса."""

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        start = time.perf_counter()
        response = await call_next(request)
        duration_ms = (time.perf_counter() - start) * 1000

        logger.info(
            "http_request",
            method=request.method,
            path=request.url.path,
            status_code=response.status_code,
            duration_ms=round(duration_ms, 2),
            client_ip=request.client.host if request.client else None,
        )
        return response


class RateLimitMiddleware(BaseHTTPMiddleware):
    """
    Redis-based sliding window rate limiter.
    Лимиты: настраиваются через settings.
    Пропускает /health и /metrics без проверки.
    """

    SKIP_PATHS = {"/health", "/health/", "/metrics"}

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        if request.url.path in self.SKIP_PATHS:
            return await call_next(request)

        # Идентификатор клиента: IP + path prefix
        client_ip = request.client.host if request.client else "unknown"
        key = f"rl:{client_ip}:{request.url.path.split('/')[2] if len(request.url.path.split('/')) > 2 else 'root'}"

        try:
            redis: Redis = request.app.state.redis
            current = await redis.incr(key)
            if current == 1:
                await redis.expire(key, 60)  # 1 минута окно

            limit = settings.RATE_LIMIT_PER_MINUTE
            if current > limit:
                logger.warning(
                    "rate_limit_exceeded",
                    client_ip=client_ip,
                    path=request.url.path,
                    current=current,
                    limit=limit,
                )
                return ORJSONResponse(
                    status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                    content={"detail": "Too many requests"},
                    headers={"Retry-After": "60"},
                )
        except Exception:
            # Redis недоступен — пропускаем rate limit (fail open)
            # В production можно настроить fail closed
            logger.warning("rate_limit_redis_unavailable")

        return await call_next(request)
