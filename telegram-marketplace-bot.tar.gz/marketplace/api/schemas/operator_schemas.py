import uuid
from datetime import date, datetime
from decimal import Decimal

from pydantic import BaseModel, ConfigDict, Field

from models.models import PayoutStatus


# ─────────────────────────────────────────────────────────────────────────────
# Operator
# ─────────────────────────────────────────────────────────────────────────────

class OperatorCreate(BaseModel):
    telegram_id: int = Field(gt=0)
    username: str | None = None


class OperatorResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    user_id: uuid.UUID
    is_active: bool
    shift_started_at: datetime | None
    last_seen: datetime | None
    total_earned: Decimal


class ShiftToggleResponse(BaseModel):
    is_active: bool
    shift_started_at: datetime | None


# ─────────────────────────────────────────────────────────────────────────────
# Inventory
# ─────────────────────────────────────────────────────────────────────────────

class InventoryUpsertRequest(BaseModel):
    product_id: uuid.UUID
    quantity: int = Field(ge=0, le=100_000)


class InventoryItemResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    product_id: uuid.UUID
    product_title: str
    quantity_available: int
    quantity_reserved: int
    updated_at: datetime


# ─────────────────────────────────────────────────────────────────────────────
# Stats
# ─────────────────────────────────────────────────────────────────────────────

class OperatorStatsResponse(BaseModel):
    operator_id: uuid.UUID
    username: str | None
    is_active: bool
    total_earned: Decimal
    completed_orders: int
    active_orders: int
    avg_completion_seconds: float | None
    last_seen: datetime | None


class OrderCountsByStatus(BaseModel):
    pending_payment: int = 0
    paid: int = 0
    in_pool: int = 0
    claimed: int = 0
    completed: int = 0
    cancelled: int = 0
    refunded: int = 0


# ─────────────────────────────────────────────────────────────────────────────
# Payouts
# ─────────────────────────────────────────────────────────────────────────────

class PayoutCalculateRequest(BaseModel):
    operator_id: uuid.UUID
    period_start: date
    period_end: date


class PayoutResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    operator_id: uuid.UUID
    amount: Decimal
    status: PayoutStatus
    period_start: date
    period_end: date
    orders_count: int
    confirmed_at: datetime | None
    paid_at: datetime | None


class PayoutConfirmRequest(BaseModel):
    payout_id: uuid.UUID
    note: str | None = Field(default=None, max_length=1024)
