import uuid
from datetime import datetime
from decimal import Decimal

from pydantic import BaseModel, ConfigDict, Field

from models.models import OrderStatus


class OrderCreate(BaseModel):
    product_id: uuid.UUID


class OrderCreateResponse(BaseModel):
    order_id: uuid.UUID
    pay_url: str
    amount: Decimal
    currency: str
    expires_at: datetime


class OrderResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    customer_id: uuid.UUID
    product_id: uuid.UUID
    operator_id: uuid.UUID | None
    status: OrderStatus
    amount: Decimal
    currency: str
    claimed_at: datetime | None
    completed_at: datetime | None
    created_at: datetime


class OrderPoolItem(BaseModel):
    """Заказ как видит его оператор в пуле."""
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    product_title: str
    amount: Decimal
    currency: str
    created_at: datetime


class OrderClaimRequest(BaseModel):
    order_id: uuid.UUID


class OrderCompleteRequest(BaseModel):
    order_id: uuid.UUID
    note: str | None = Field(default=None, max_length=1024)
