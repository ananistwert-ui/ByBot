import uuid
from datetime import datetime
from decimal import Decimal

from pydantic import BaseModel, ConfigDict, Field, field_validator


class ProductBase(BaseModel):
    title: str = Field(min_length=1, max_length=256)
    description: str | None = Field(default=None, max_length=4096)
    price: Decimal = Field(gt=0, decimal_places=2)
    currency: str = Field(default="USDT", min_length=3, max_length=10)
    reward_amount: Decimal = Field(default=Decimal("0.00"), ge=0, decimal_places=2)

    @field_validator("currency")
    @classmethod
    def currency_uppercase(cls, v: str) -> str:
        return v.upper()


class ProductCreate(ProductBase):
    sort_order: int = Field(default=0, ge=0)


class ProductUpdate(BaseModel):
    """Все поля опциональны — partial update."""
    title: str | None = Field(default=None, min_length=1, max_length=256)
    description: str | None = Field(default=None, max_length=4096)
    price: Decimal | None = Field(default=None, gt=0, decimal_places=2)
    reward_amount: Decimal | None = Field(default=None, ge=0, decimal_places=2)
    is_active: bool | None = None
    sort_order: int | None = Field(default=None, ge=0)


class ProductResponse(ProductBase):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    is_active: bool
    is_archived: bool
    sort_order: int
    created_at: datetime


class ProductCatalogItem(BaseModel):
    """Что видит клиент: продукт + агрегированный сток."""
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    title: str
    description: str | None
    price: Decimal
    currency: str
    total_stock: int
