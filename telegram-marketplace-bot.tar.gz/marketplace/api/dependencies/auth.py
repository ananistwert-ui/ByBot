import uuid
from typing import Annotated

import structlog
from fastapi import Depends, Header, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy.ext.asyncio import AsyncSession

from core.repositories.inventory_repository import InventoryRepository
from core.repositories.order_repository import OrderRepository
from core.security.auth import decode_token
from core.services.audit_service import AuditService
from core.services.order_service import OrderService
from core.services.payment_service import CryptoBotService
from models.database import get_db_session
from models.models import Operator, User, UserRole

logger = structlog.get_logger(__name__)

security = HTTPBearer(auto_error=False)


# ─────────────────────────────────────────────────────────────────────────────
# Database session
# ─────────────────────────────────────────────────────────────────────────────

DBSession = Annotated[AsyncSession, Depends(get_db_session)]


# ─────────────────────────────────────────────────────────────────────────────
# Auth dependencies
# ─────────────────────────────────────────────────────────────────────────────

async def get_current_user(
    db: DBSession,
    credentials: HTTPAuthorizationCredentials | None = Depends(security),
) -> User:
    """
    Декодирует JWT, загружает пользователя из БД.
    Проверяет бан.
    """
    if not credentials:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Not authenticated",
            headers={"WWW-Authenticate": "Bearer"},
        )

    try:
        payload = decode_token(credentials.credentials)
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=str(e),
        ) from e

    from sqlalchemy import select
    from models.models import Session

    # Проверяем сессию в БД (поддержка revocation)
    token_hash = _hash_token(credentials.credentials)
    session_stmt = (
        select(Session)
        .where(
            Session.token_hash == token_hash,
            Session.is_valid.is_(True),
        )
    )
    session_result = await db.execute(session_stmt)
    db_session = session_result.scalar_one_or_none()

    if not db_session:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Session expired or revoked",
        )

    user = await db.get(User, uuid.UUID(payload.sub))
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User not found",
        )

    if user.is_banned:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Account is banned",
        )

    # Добавляем user_id в structured log context
    structlog.contextvars.bind_contextvars(user_id=str(user.id))

    return user


CurrentUser = Annotated[User, Depends(get_current_user)]


def require_role(*roles: UserRole):
    """Factory для role-based access."""
    async def _check(user: CurrentUser) -> User:
        if user.role not in roles:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Required roles: {[r.value for r in roles]}",
            )
        return user
    return _check


RequireOperator = Annotated[User, Depends(require_role(UserRole.operator))]
RequireAdmin    = Annotated[User, Depends(require_role(UserRole.superadmin))]
RequireAny      = Annotated[User, Depends(require_role(
    UserRole.customer, UserRole.operator, UserRole.superadmin
))]


async def get_current_operator(
    user: RequireOperator,
    db: DBSession,
) -> Operator:
    """Загружает Operator profile для текущего пользователя."""
    from sqlalchemy import select
    stmt = select(Operator).where(Operator.user_id == user.id)
    result = await db.execute(stmt)
    operator = result.scalar_one_or_none()
    if not operator:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Operator profile not found",
        )
    return operator


CurrentOperator = Annotated[Operator, Depends(get_current_operator)]


# ─────────────────────────────────────────────────────────────────────────────
# Service dependencies (DI)
# ─────────────────────────────────────────────────────────────────────────────

def get_order_service(db: DBSession) -> OrderService:
    order_repo = OrderRepository(db)
    inv_repo   = InventoryRepository(db)
    audit_svc  = AuditService(db)
    crypto_svc = CryptoBotService()
    return OrderService(order_repo, inv_repo, audit_svc, crypto_svc)


OrderSvc = Annotated[OrderService, Depends(get_order_service)]


def get_audit_service(db: DBSession) -> AuditService:
    return AuditService(db)


AuditSvc = Annotated[AuditService, Depends(get_audit_service)]


# ─────────────────────────────────────────────────────────────────────────────
# Webhook signature header
# ─────────────────────────────────────────────────────────────────────────────

async def require_cryptobot_signature(
    crypto_pay_api_signature: Annotated[str | None, Header()] = None,
) -> str:
    """Проверяет наличие подписи CryptoBot в заголовке."""
    if not crypto_pay_api_signature:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Missing webhook signature",
        )
    return crypto_pay_api_signature


CryptoBotSignature = Annotated[str, Depends(require_cryptobot_signature)]


def _hash_token(token: str) -> str:
    import hashlib
    return hashlib.sha256(token.encode()).hexdigest()
