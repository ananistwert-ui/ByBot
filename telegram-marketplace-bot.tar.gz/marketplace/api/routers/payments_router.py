import structlog
from fastapi import APIRouter, HTTPException, Request, status
from redis.asyncio import Redis

from api.dependencies.auth import CryptoBotSignature, OrderSvc
from core.services.order_service import InvalidOrderTransitionError, OrderNotFoundError
from core.services.payment_service import CryptoBotService, WebhookSignatureError

router = APIRouter()
logger = structlog.get_logger(__name__)


@router.post("/webhook/cryptobot", status_code=status.HTTP_200_OK)
async def cryptobot_webhook(
    request: Request,
    signature: CryptoBotSignature,
    order_service: OrderSvc,
) -> dict[str, str]:
    """
    Webhook от CryptoBot после оплаты.

    КРИТИЧНО:
    1. Проверка подписи (HMAC) — защита от поддельных webhook
    2. Идемпотентность через UNIQUE(external_invoice_id) +
       redis distributed lock — защита от двойной обработки
       при параллельных retry от CryptoBot
    3. Заказ переводится paid -> in_pool только при первой
       успешной обработке
    """
    raw_body = await request.body()

    cryptobot = CryptoBotService()
    try:
        cryptobot.validate_webhook_signature(raw_body, signature)
    except WebhookSignatureError as e:
        logger.warning("webhook_rejected_bad_signature", error=str(e))
        raise HTTPException(
            status.HTTP_401_UNAUTHORIZED, "Invalid signature"
        ) from e

    parsed = cryptobot.parse_webhook_body(raw_body)
    if not parsed:
        # update_type не invoice_paid — игнорируем но отвечаем 200
        # (чтобы CryptoBot не делал retry на неинтересующие нас события)
        return {"status": "ignored"}

    invoice_id = parsed["invoice_id"]

    # Distributed lock через Redis — защита от параллельной обработки
    # одного и того же webhook (CryptoBot может retry при таймауте ответа)
    redis: Redis = request.app.state.redis
    lock_key = f"webhook_lock:cryptobot:{invoice_id}"
    lock_acquired = await redis.set(lock_key, "1", nx=True, ex=30)

    if not lock_acquired:
        logger.info("webhook_duplicate_locked", invoice_id=invoice_id)
        return {"status": "duplicate_processing"}

    try:
        order = await order_service.handle_payment_webhook(
            invoice_id=invoice_id,
            check_id=parsed["check_id"],
            payload=parsed["raw"],
        )
        logger.info(
            "webhook_processed",
            invoice_id=invoice_id,
            order_id=str(order.id),
        )
        return {"status": "ok", "order_id": str(order.id)}

    except OrderNotFoundError as e:
        # Неизвестный invoice — возвращаем 200, чтобы CryptoBot
        # не делал бесконечные retry на чужой/тестовый инвойс
        logger.warning("webhook_unknown_invoice", invoice_id=invoice_id, error=str(e))
        return {"status": "unknown_invoice"}

    except InvalidOrderTransitionError as e:
        logger.error(
            "webhook_invalid_transition",
            invoice_id=invoice_id,
            error=str(e),
        )
        # 200, чтобы избежать бесконечных retry — но логируем для расследования
        return {"status": "error", "detail": "invalid_transition"}

    finally:
        await redis.delete(lock_key)
