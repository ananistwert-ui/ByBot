import uuid

from fastapi import APIRouter, HTTPException, status

from api.dependencies.auth import AuditSvc, DBSession, RequireAdmin
from api.schemas.operator_schemas import OperatorCreate, OperatorResponse
from models.models import Operator, OrderStatus, User, UserRole

router = APIRouter()


@router.post("/operators", response_model=OperatorResponse, status_code=status.HTTP_201_CREATED)
async def create_operator(
    payload: OperatorCreate,
    admin: RequireAdmin,
    db: DBSession,
    audit: AuditSvc,
) -> Operator:
    """
    Создаёт User (если не существует) + Operator profile.
    telegram_id должен быть уникальным.
    """
    from sqlalchemy import select

    stmt = select(User).where(User.telegram_id == payload.telegram_id)
    result = await db.execute(stmt)
    user = result.scalar_one_or_none()

    if user and user.role != UserRole.customer:
        raise HTTPException(
            status.HTTP_409_CONFLICT,
            f"User already has role {user.role}",
        )

    if not user:
        user = User(
            telegram_id=payload.telegram_id,
            username=payload.username,
            role=UserRole.operator,
        )
        db.add(user)
        await db.flush()
    else:
        user.role = UserRole.operator

    operator = Operator(user_id=user.id)
    db.add(operator)
    await db.flush()
    await db.refresh(operator)

    await audit.log(
        action="operator.created",
        entity_type="operator",
        entity_id=operator.id,
        actor_id=admin.id,
        after_data={"telegram_id": payload.telegram_id},
    )
    return operator


@router.post("/operators/{operator_id}/ban", status_code=status.HTTP_204_NO_CONTENT)
async def ban_operator(
    operator_id: uuid.UUID,
    admin: RequireAdmin,
    db: DBSession,
    audit: AuditSvc,
) -> None:
    operator = await db.get(Operator, operator_id)
    if not operator:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Operator not found")

    user = await db.get(User, operator.user_id)
    if user:
        user.is_banned = True
    operator.is_active = False  # немедленно убираем из пула

    await audit.log(
        action="operator.banned",
        entity_type="operator",
        entity_id=operator.id,
        actor_id=admin.id,
    )


@router.post("/operators/{operator_id}/unban", status_code=status.HTTP_204_NO_CONTENT)
async def unban_operator(
    operator_id: uuid.UUID,
    admin: RequireAdmin,
    db: DBSession,
    audit: AuditSvc,
) -> None:
    operator = await db.get(Operator, operator_id)
    if not operator:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Operator not found")

    user = await db.get(User, operator.user_id)
    if user:
        user.is_banned = False

    await audit.log(
        action="operator.unbanned",
        entity_type="operator",
        entity_id=operator.id,
        actor_id=admin.id,
    )


@router.get("/orders/monitor")
async def monitor_orders(
    admin: RequireAdmin,
    db: DBSession,
):
    """
    Сводка по всем заказам для админ дашборда:
    active (in_pool), claimed, completed, stuck (claimed > 1 час).
    """
    from datetime import datetime, timedelta, timezone

    from sqlalchemy import func, select

    from models.models import Order

    counts_stmt = select(Order.status, func.count(Order.id)).group_by(Order.status)
    counts_result = await db.execute(counts_stmt)
    counts = {row[0].value: row[1] for row in counts_result.all()}

    stuck_threshold = datetime.now(timezone.utc) - timedelta(hours=1)
    stuck_stmt = (
        select(func.count(Order.id))
        .where(
            Order.status == OrderStatus.claimed,
            Order.claimed_at < stuck_threshold,
        )
    )
    stuck_count = (await db.execute(stuck_stmt)).scalar_one()

    return {
        "counts_by_status": counts,
        "stuck_orders": stuck_count,
    }


@router.post("/orders/{order_id}/force-cancel", status_code=status.HTTP_204_NO_CONTENT)
async def force_cancel_order(
    order_id: uuid.UUID,
    admin: RequireAdmin,
    db: DBSession,
    audit: AuditSvc,
    note: str | None = None,
) -> None:
    """
    Ручное вмешательство админа: отмена зависшего/проблемного заказа.
    Если заказ был claimed — возвращаем инвентарь оператору.
    """
    from datetime import datetime, timezone

    from core.repositories.inventory_repository import InventoryRepository
    from models.models import Order

    order = await db.get(Order, order_id)
    if not order:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Order not found")

    if order.status in (OrderStatus.completed, OrderStatus.cancelled, OrderStatus.refunded):
        raise HTTPException(
            status.HTTP_400_BAD_REQUEST,
            f"Cannot cancel order in status {order.status}",
        )

    before_status = order.status

    # Если был claimed — возвращаем инвентарь
    if order.status == OrderStatus.claimed and order.operator_id:
        inv_repo = InventoryRepository(db)
        from sqlalchemy import update as sa_update
        from models.models import OperatorInventory
        stmt = (
            sa_update(OperatorInventory)
            .where(
                OperatorInventory.operator_id == order.operator_id,
                OperatorInventory.product_id == order.product_id,
            )
            .values(
                quantity_available=OperatorInventory.quantity_available + 1,
                quantity_reserved=OperatorInventory.quantity_reserved - 1,
            )
        )
        await db.execute(stmt)

    order.status = OrderStatus.cancelled
    order.cancelled_at = datetime.now(timezone.utc)
    order.admin_note = note

    await audit.log(
        action="order.force_cancelled",
        entity_type="order",
        entity_id=order.id,
        actor_id=admin.id,
        before_data={"status": before_status.value},
        after_data={"status": "cancelled", "note": note},
    )
