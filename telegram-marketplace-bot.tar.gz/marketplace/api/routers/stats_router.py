from fastapi import APIRouter
from sqlalchemy import text

from api.dependencies.auth import DBSession, RequireAdmin
from api.schemas.operator_schemas import OperatorStatsResponse

router = APIRouter()


@router.get("/operators", response_model=list[OperatorStatsResponse])
async def operator_stats(
    admin: RequireAdmin,
    db: DBSession,
) -> list[OperatorStatsResponse]:
    """Использует v_operator_stats view (определён в DB schema)."""
    stmt = text("""
        SELECT operator_id, username, is_active, total_earned,
               completed_orders, active_orders,
               avg_completion_seconds, last_seen
        FROM v_operator_stats
        ORDER BY completed_orders DESC
    """)
    result = await db.execute(stmt)
    return [
        OperatorStatsResponse(
            operator_id=row.operator_id,
            username=row.username,
            is_active=row.is_active,
            total_earned=row.total_earned,
            completed_orders=row.completed_orders,
            active_orders=row.active_orders,
            avg_completion_seconds=float(row.avg_completion_seconds)
            if row.avg_completion_seconds else None,
            last_seen=row.last_seen,
        )
        for row in result.all()
    ]


@router.get("/overview")
async def overview_stats(
    admin: RequireAdmin,
    db: DBSession,
) -> dict:
    """Общая сводка: revenue, completion rate, active operators."""
    stmt = text("""
        SELECT
            COUNT(*) FILTER (WHERE status = 'completed') AS completed,
            COUNT(*) FILTER (WHERE status IN ('completed','cancelled','refunded')) AS finished,
            COALESCE(SUM(amount) FILTER (WHERE status = 'completed'), 0) AS revenue
        FROM orders
    """)
    result = await db.execute(stmt)
    row = result.one()

    completion_rate = (
        round(row.completed / row.finished * 100, 2) if row.finished else 0.0
    )

    active_ops_stmt = text(
        "SELECT COUNT(*) FROM operators WHERE is_active = TRUE"
    )
    active_ops = (await db.execute(active_ops_stmt)).scalar_one()

    return {
        "completed_orders": row.completed,
        "total_revenue": str(row.revenue),
        "completion_rate_pct": completion_rate,
        "active_operators": active_ops,
    }
