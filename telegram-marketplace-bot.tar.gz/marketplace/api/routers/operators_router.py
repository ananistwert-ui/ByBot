import uuid

from fastapi import APIRouter, HTTPException, status

from api.dependencies.auth import (
    AuditSvc,
    CurrentOperator,
    DBSession,
    OrderSvc,
)
from api.schemas.operator_schemas import (
    InventoryItemResponse,
    InventoryUpsertRequest,
    ShiftToggleResponse,
)
from api.schemas.order_schemas import (
    OrderClaimRequest,
    OrderCompleteRequest,
    OrderPoolItem,
    OrderResponse,
)
from core.repositories.inventory_repository import InventoryRepository
from core.repositories.operator_repository import OperatorRepository
from core.services.order_service import (
    InsufficientInventoryError,
    OrderAlreadyClaimedError,
    OrderNotFoundError,
)

router = APIRouter()


# ─────────────────────────────────────────────────────────────────────────────
# Shift management
# ─────────────────────────────────────────────────────────────────────────────

@router.post("/shift/start", response_model=ShiftToggleResponse)
async def start_shift(
    operator: CurrentOperator,
    db: DBSession,
    audit: AuditSvc,
) -> ShiftToggleResponse:
    repo = OperatorRepository(db)
    updated = await repo.start_shift(operator.id)
    if not updated:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Operator not found")

    await audit.log(
        action="operator.shift_started",
        entity_type="operator",
        entity_id=operator.id,
        actor_id=operator.user_id,
    )
    return ShiftToggleResponse(
        is_active=updated.is_active,
        shift_started_at=updated.shift_started_at,
    )


@router.post("/shift/stop", response_model=ShiftToggleResponse)
async def stop_shift(
    operator: CurrentOperator,
    db: DBSession,
    audit: AuditSvc,
) -> ShiftToggleResponse:
    repo = OperatorRepository(db)
    updated = await repo.stop_shift(operator.id)
    if not updated:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Operator not found")

    await audit.log(
        action="operator.shift_stopped",
        entity_type="operator",
        entity_id=operator.id,
        actor_id=operator.user_id,
    )
    return ShiftToggleResponse(
        is_active=updated.is_active,
        shift_started_at=updated.shift_started_at,
    )


# ─────────────────────────────────────────────────────────────────────────────
# Order pool / claim / complete
# ─────────────────────────────────────────────────────────────────────────────

@router.get("/orders/pool", response_model=list[OrderPoolItem])
async def get_order_pool(
    operator: CurrentOperator,
    order_service: OrderSvc,
) -> list[OrderPoolItem]:
    """
    Заказы, видимые ЭТОМУ оператору.
    Условия: is_active=True (проверяется при auth), inventory > 0,
    оператор владеет этим продуктом.
    """
    orders = await order_service.get_pool_for_operator(operator.id)
    return [
        OrderPoolItem(
            id=o.id,
            product_title=o.product.title if o.product else "",
            amount=o.amount,
            currency=o.currency,
            created_at=o.created_at,
        )
        for o in orders
    ]


@router.post("/orders/claim", response_model=OrderResponse)
async def claim_order(
    payload: OrderClaimRequest,
    operator: CurrentOperator,
    db: DBSession,
    order_service: OrderSvc,
) -> OrderResponse:
    """
    Атомарный claim. Если заказ уже забрали — 409 Conflict.
    """
    from models.models import Order
    order_row = await db.get(Order, payload.order_id)
    if not order_row:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Order not found")

    try:
        order = await order_service.claim_order(
            order_id=payload.order_id,
            operator_id=operator.id,
            product_id=order_row.product_id,
        )
    except OrderAlreadyClaimedError as e:
        raise HTTPException(
            status.HTTP_409_CONFLICT,
            "Order already claimed",
        ) from e
    except InsufficientInventoryError as e:
        raise HTTPException(
            status.HTTP_409_CONFLICT,
            "Insufficient inventory",
        ) from e

    return OrderResponse.model_validate(order)


@router.post("/orders/complete", response_model=OrderResponse)
async def complete_order(
    payload: OrderCompleteRequest,
    operator: CurrentOperator,
    order_service: OrderSvc,
) -> OrderResponse:
    try:
        order = await order_service.complete_order(
            order_id=payload.order_id,
            operator_id=operator.id,
        )
    except OrderNotFoundError as e:
        raise HTTPException(
            status.HTTP_404_NOT_FOUND,
            "Order not found or not claimed by you",
        ) from e

    return OrderResponse.model_validate(order)


@router.get("/orders/mine", response_model=list[OrderResponse])
async def my_active_orders(
    operator: CurrentOperator,
    order_service: OrderSvc,
) -> list[OrderResponse]:
    from models.models import OrderStatus
    orders = await order_service._orders.get_operator_orders(
        operator.id, status=OrderStatus.claimed
    )
    return [OrderResponse.model_validate(o) for o in orders]


# ─────────────────────────────────────────────────────────────────────────────
# Inventory management
# ─────────────────────────────────────────────────────────────────────────────

@router.get("/inventory", response_model=list[InventoryItemResponse])
async def get_my_inventory(
    operator: CurrentOperator,
    db: DBSession,
) -> list[InventoryItemResponse]:
    repo = InventoryRepository(db)
    items = await repo.get_operator_inventory(operator.id)
    return [
        InventoryItemResponse(
            product_id=i.product_id,
            product_title=i.product.title if i.product else "",
            quantity_available=i.quantity_available,
            quantity_reserved=i.quantity_reserved,
            updated_at=i.updated_at,
        )
        for i in items
    ]


@router.put("/inventory", response_model=InventoryItemResponse)
async def upsert_inventory(
    payload: InventoryUpsertRequest,
    operator: CurrentOperator,
    db: DBSession,
    audit: AuditSvc,
) -> InventoryItemResponse:
    """
    Оператор устанавливает остаток.
    Валидация: quantity >= 0 (Pydantic), product должен существовать
    и быть активным (FK constraint + проверка ниже).
    """
    from models.models import Product

    product = await db.get(Product, payload.product_id)
    if not product or not product.is_active:
        raise HTTPException(
            status.HTTP_400_BAD_REQUEST,
            "Invalid or inactive product",
        )

    repo = InventoryRepository(db)
    item = await repo.upsert(operator.id, payload.product_id, payload.quantity)

    await audit.log(
        action="inventory.updated",
        entity_type="operator_inventory",
        entity_id=item.id,
        actor_id=operator.user_id,
        after_data={
            "product_id": str(payload.product_id),
            "quantity": payload.quantity,
        },
    )

    return InventoryItemResponse(
        product_id=item.product_id,
        product_title=product.title,
        quantity_available=item.quantity_available,
        quantity_reserved=item.quantity_reserved,
        updated_at=item.updated_at,
    )
