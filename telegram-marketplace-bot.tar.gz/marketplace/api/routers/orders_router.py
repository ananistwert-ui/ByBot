import uuid

from fastapi import APIRouter, HTTPException, status

from api.dependencies.auth import CurrentUser, DBSession, OrderSvc
from api.schemas.order_schemas import OrderCreate, OrderCreateResponse, OrderResponse
from core.services.order_service import OrderNotFoundError
from models.models import Product

router = APIRouter()


@router.post("", response_model=OrderCreateResponse, status_code=status.HTTP_201_CREATED)
async def create_order(
    payload: OrderCreate,
    user: CurrentUser,
    db: DBSession,
    order_service: OrderSvc,
) -> OrderCreateResponse:
    """
    Клиент создаёт заказ. Сначала создаётся CryptoBot invoice,
    затем order в статусе pending_payment.

    Заказ НЕ переходит в paid до подтверждения webhook.
    """
    product = await db.get(Product, payload.product_id)
    if not product or not product.is_active or product.is_archived:
        raise HTTPException(
            status.HTTP_404_NOT_FOUND,
            "Product not found or unavailable",
        )

    order, pay_url = await order_service.create_pending_order(user, product)

    return OrderCreateResponse(
        order_id=order.id,
        pay_url=pay_url,
        amount=order.amount,
        currency=order.currency,
        expires_at=order.expires_at,
    )


@router.get("/{order_id}", response_model=OrderResponse)
async def get_order(
    order_id: uuid.UUID,
    user: CurrentUser,
    db: DBSession,
) -> OrderResponse:
    """Клиент проверяет статус своего заказа."""
    from models.models import Order

    order = await db.get(Order, order_id)
    if not order:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Order not found")

    # Клиент видит только свои заказы (если не админ)
    if order.customer_id != user.id and user.role.value != "superadmin":
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Not your order")

    return OrderResponse.model_validate(order)


@router.get("", response_model=list[OrderResponse])
async def list_my_orders(
    user: CurrentUser,
    order_service: OrderSvc,
    limit: int = 20,
    offset: int = 0,
) -> list[OrderResponse]:
    """История заказов текущего клиента."""
    orders = await order_service._orders.get_customer_orders(
        user.id, limit=limit, offset=offset
    )
    return [OrderResponse.model_validate(o) for o in orders]
