from fastapi import APIRouter, HTTPException, status
from pydantic import BaseModel
from sqlalchemy import select

from api.dependencies.auth import DBSession
from core.security.auth import (
    create_access_token,
    create_refresh_token,
    hash_token,
    validate_telegram_init_data,
)
from models.models import Session, User, UserRole

router = APIRouter()


class TelegramAuthRequest(BaseModel):
    init_data: str


class AuthResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    role: str


@router.post("/telegram", response_model=AuthResponse)
async def login_via_telegram(
    payload: TelegramAuthRequest,
    db: DBSession,
) -> AuthResponse:
    """
    Авторизация через Telegram WebApp initData.
    Создаёт User при первом входе с ролью customer.
    """
    try:
        data = validate_telegram_init_data(payload.init_data)
    except ValueError as e:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, str(e)) from e

    import json
    user_data = json.loads(data.get("user", "{}"))
    telegram_id = user_data.get("id")
    if not telegram_id:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Missing user data")

    stmt = select(User).where(User.telegram_id == telegram_id)
    result = await db.execute(stmt)
    user = result.scalar_one_or_none()

    if not user:
        user = User(
            telegram_id=telegram_id,
            username=user_data.get("username"),
            first_name=user_data.get("first_name"),
            last_name=user_data.get("last_name"),
            role=UserRole.customer,
        )
        db.add(user)
        await db.flush()

    if user.is_banned:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Account is banned")

    access_token, access_jti = create_access_token(user.id, user.role)
    refresh_token, refresh_jti = create_refresh_token(user.id, user.role)

    from datetime import datetime, timedelta, timezone
    from config.settings import settings

    db.add(Session(
        user_id=user.id,
        token_hash=hash_token(access_token),
        expires_at=datetime.now(timezone.utc) + timedelta(
            minutes=settings.JWT_ACCESS_TOKEN_EXPIRE_MINUTES
        ),
    ))

    return AuthResponse(
        access_token=access_token,
        refresh_token=refresh_token,
        role=user.role.value,
    )


@router.post("/logout", status_code=status.HTTP_204_NO_CONTENT)
async def logout(db: DBSession, token: str) -> None:
    """Revoke session by marking is_valid=False."""
    stmt = select(Session).where(Session.token_hash == hash_token(token))
    result = await db.execute(stmt)
    session = result.scalar_one_or_none()
    if session:
        session.is_valid = False
