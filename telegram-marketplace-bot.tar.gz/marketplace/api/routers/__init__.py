from api.routers.admin_router import router as admin_router
from api.routers.auth_router import router as auth_router
from api.routers.health_router import router as health_router
from api.routers.operators_router import router as operators_router
from api.routers.orders_router import router as orders_router
from api.routers.payments_router import router as payments_router
from api.routers.payouts_router import router as payouts_router
from api.routers.products_router import router as products_router
from api.routers.stats_router import router as stats_router

__all__ = [
    "admin_router",
    "auth_router",
    "health_router",
    "operators_router",
    "orders_router",
    "payments_router",
    "payouts_router",
    "products_router",
    "stats_router",
]
