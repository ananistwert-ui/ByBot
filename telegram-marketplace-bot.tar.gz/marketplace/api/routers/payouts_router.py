import uuid
from datetime import datetime, timezone
from decimal import Decimal

from fastapi import APIRouter, HTTPException, status
from sqlalchemy import select

from api.dependencies.auth import AuditSvc, DBSession, OrderSvc, RequireAdmin
from api.schemas.operator_schemas import (
    PayoutCalculateRequest,
    PayoutConfirmRequest,
    PayoutResponse,
)
from models.models import Operator, Payout, PayoutStatus

router = APIRouter()


@router.post("/calculate", response_model=PayoutResponse, status_code=status.HTTP_201_CREATED)
async def calculate_payout(
    payload: PayoutCalculateRequest,
    admin: RequireAdmin,
    db: DBSession,
    order_service: OrderSvc,
    audit: AuditSvc,
) -> Payout:
    """
    Рассчитывает выплату оператору за период на основе
    выполненных заказов.

    Защита от double-calculation:
    UNIQUE constraint (operator_id, period_start, period_end)
    в БД — повторный вызов с тем же периодом вызовет конфликт.
    """
    operator = await db.get(Operator, payload.operator_id)
    if not operator:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Operator not found")

    # Проверяем, нет ли уже payout за этот период
    existing_stmt = select(Payout).where(
        Payout.operator_id == payload.operator_id,
        Payout.period_start == payload.period_start,
        Payout.period_end == payload.period_end,
    )
    existing = (await db.execute(existing_stmt)).scalar_one_or_none()
    if existing:
        raise HTTPException(
            status.HTTP_409_CONFLICT,
            f"Payout for this period already exists: {existing.id}",
        )

    period_start_dt = datetime.combine(
        payload.period_start, datetime.min.time()
    ).replace(tzinfo=timezone.utc)
    period_end_dt = datetime.combine(
        payload.period_end, datetime.max.time()
    ).replace(tzinfo=timezone.utc)

    orders = await order_service._orders.get_completed_for_payout(
        payload.operator_id, period_start_dt, period_end_dt
    )

    if not orders:
        raise HTTPException(
            status.HTTP_400_BAD_REQUEST,
            "No completed orders in this period",
        )

    total_amount = sum(
        (o.product.reward_amount if o.product else Decimal("0")) for o in orders
    )

    payout = Payout(
        operator_id=payload.operator_id,
        amount=total_amount,
        status=PayoutStatus.pending,
        period_start=payload.period_start,
        period_end=payload.period_end,
        order_ids=[o.id for o in orders],
        orders_count=len(orders),
    )
    db.add(payout)
    await db.flush()
    await db.refresh(payout)

    await audit.log(
        action="payout.calculated",
        entity_type="payout",
        entity_id=payout.id,
        actor_id=admin.id,
        after_data={
            "operator_id": str(payload.operator_id),
            "amount": str(total_amount),
            "orders_count": len(orders),
        },
    )
    return payout


@router.post("/confirm", response_model=PayoutResponse)
async def confirm_payout(
    payload: PayoutConfirmRequest,
    admin: RequireAdmin,
    db: DBSession,
    audit: AuditSvc,
) -> Payout:
    """
    Подтверждает payout (pending -> confirmed -> paid).
    Только после confirm деньги фактически переводятся (внешний процесс).
    """
    payout = await db.get(Payout, payload.payout_id)
    if not payout:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Payout not found")

    if payout.status != PayoutStatus.pending:
        raise HTTPException(
            status.HTTP_400_BAD_REQUEST,
            f"Payout already in status {payout.status}",
        )

    now = datetime.now(timezone.utc)
    payout.status = PayoutStatus.confirmed
    payout.confirmed_by = admin.id
    payout.confirmed_at = now
    payout.note = payload.note

    await audit.log(
        action="payout.confirmed",
        entity_type="payout",
        entity_id=payout.id,
        actor_id=admin.id,
    )
    return payout


@router.get("/history/{operator_id}", response_model=list[PayoutResponse])
async def payout_history(
    operator_id: uuid.UUID,
    admin: RequireAdmin,
    db: DBSession,
) -> list[Payout]:
    stmt = (
        select(Payout)
        .where(Payout.operator_id == operator_id)
        .order_by(Payout.created_at.desc())
    )
    result = await db.execute(stmt)
    return list(result.scalars().all())
