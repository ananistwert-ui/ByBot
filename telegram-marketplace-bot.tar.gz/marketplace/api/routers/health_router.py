from fastapi import APIRouter, Request
from sqlalchemy import text

from api.dependencies.auth import DBSession

router = APIRouter()


@router.get("")
async def health() -> dict[str, str]:
    """Liveness probe — не проверяет зависимости."""
    return {"status": "ok"}


@router.get("/ready")
async def readiness(request: Request, db: DBSession) -> dict[str, str]:
    """
    Readiness probe — проверяет DB и Redis.
    Используется Kubernetes/Docker для определения готовности принимать трафик.
    """
    checks = {}

    try:
        await db.execute(text("SELECT 1"))
        checks["database"] = "ok"
    except Exception as e:
        checks["database"] = f"error: {e}"

    try:
        redis = request.app.state.redis
        await redis.ping()
        checks["redis"] = "ok"
    except Exception as e:
        checks["redis"] = f"error: {e}"

    overall = "ok" if all(v == "ok" for v in checks.values()) else "degraded"
    return {"status": overall, **checks}
