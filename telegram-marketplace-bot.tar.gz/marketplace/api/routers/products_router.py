import uuid

from fastapi import APIRouter, HTTPException, status
from sqlalchemy import select, text

from api.dependencies.auth import AuditSvc, DBSession, RequireAdmin
from api.schemas.product_schemas import (
    ProductCatalogItem,
    ProductCreate,
    ProductResponse,
    ProductUpdate,
)
from models.models import Product

router = APIRouter()


@router.get("/catalog", response_model=list[ProductCatalogItem])
async def get_catalog(db: DBSession) -> list[ProductCatalogItem]:
    """
    Публичный каталог для клиента.
    Использует view v_product_catalog с агрегированным стоком.
    """
    stmt = text("""
        SELECT id, title, description, price, currency, total_stock
        FROM v_product_catalog
    """)
    result = await db.execute(stmt)
    return [
        ProductCatalogItem(
            id=row.id,
            title=row.title,
            description=row.description,
            price=row.price,
            currency=row.currency,
            total_stock=row.total_stock,
        )
        for row in result.all()
    ]


@router.get("", response_model=list[ProductResponse])
async def list_products(
    db: DBSession,
    admin: RequireAdmin,
    include_archived: bool = False,
) -> list[Product]:
    """Полный список продуктов для админки (включая неактивные)."""
    stmt = select(Product).order_by(Product.sort_order)
    if not include_archived:
        stmt = stmt.where(Product.is_archived.is_(False))
    result = await db.execute(stmt)
    return list(result.scalars().all())


@router.post("", response_model=ProductResponse, status_code=status.HTTP_201_CREATED)
async def create_product(
    payload: ProductCreate,
    db: DBSession,
    admin: RequireAdmin,
    audit: AuditSvc,
) -> Product:
    """Только SuperAdmin создаёт продукты."""
    product = Product(**payload.model_dump())
    db.add(product)
    await db.flush()
    await db.refresh(product)

    await audit.log(
        action="product.created",
        entity_type="product",
        entity_id=product.id,
        actor_id=admin.id,
        after_data={"title": product.title, "price": str(product.price)},
    )
    return product


@router.patch("/{product_id}", response_model=ProductResponse)
async def update_product(
    product_id: uuid.UUID,
    payload: ProductUpdate,
    db: DBSession,
    admin: RequireAdmin,
    audit: AuditSvc,
) -> Product:
    product = await db.get(Product, product_id)
    if not product:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Product not found")

    before = {"title": product.title, "price": str(product.price), "is_active": product.is_active}

    update_data = payload.model_dump(exclude_unset=True)
    for key, value in update_data.items():
        setattr(product, key, value)

    await db.flush()
    await db.refresh(product)

    await audit.log(
        action="product.updated",
        entity_type="product",
        entity_id=product.id,
        actor_id=admin.id,
        before_data=before,
        after_data=update_data,
    )
    return product


@router.delete("/{product_id}", status_code=status.HTTP_204_NO_CONTENT)
async def archive_product(
    product_id: uuid.UUID,
    db: DBSession,
    admin: RequireAdmin,
    audit: AuditSvc,
) -> None:
    """
    Soft delete: архивируем, не удаляем физически.
    Продукты с существующими заказами нельзя удалить (FK RESTRICT).
    """
    product = await db.get(Product, product_id)
    if not product:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Product not found")

    product.is_active = False
    product.is_archived = True
    await db.flush()

    await audit.log(
        action="product.archived",
        entity_type="product",
        entity_id=product.id,
        actor_id=admin.id,
    )
