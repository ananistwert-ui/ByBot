import hashlib
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any

from jose import JWTError, jwt
from passlib.context import CryptContext

from config.settings import settings
from models.models import UserRole

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


# ─────────────────────────────────────────────────────────────────────────────
# JWT
# ─────────────────────────────────────────────────────────────────────────────

class TokenPayload:
    def __init__(self, sub: str, role: UserRole, jti: str) -> None:
        self.sub = sub        # user_id
        self.role = role
        self.jti = jti        # JWT ID — для revocation


def create_access_token(
    user_id: uuid.UUID,
    role: UserRole,
) -> tuple[str, str]:
    """
    Создаёт JWT access token.
    Returns: (token_string, jti)
    jti нужен для хранения хэша в sessions таблице.
    """
    jti = str(uuid.uuid4())
    expire = datetime.now(timezone.utc) + timedelta(
        minutes=settings.JWT_ACCESS_TOKEN_EXPIRE_MINUTES
    )
    payload: dict[str, Any] = {
        "sub": str(user_id),
        "role": role.value,
        "jti": jti,
        "exp": expire,
        "iat": datetime.now(timezone.utc),
        "type": "access",
    }
    token = jwt.encode(
        payload,
        settings.JWT_SECRET_KEY,
        algorithm=settings.JWT_ALGORITHM,
    )
    return token, jti


def create_refresh_token(
    user_id: uuid.UUID,
    role: UserRole,
) -> tuple[str, str]:
    jti = str(uuid.uuid4())
    expire = datetime.now(timezone.utc) + timedelta(
        days=settings.JWT_REFRESH_TOKEN_EXPIRE_DAYS
    )
    payload: dict[str, Any] = {
        "sub": str(user_id),
        "role": role.value,
        "jti": jti,
        "exp": expire,
        "iat": datetime.now(timezone.utc),
        "type": "refresh",
    }
    token = jwt.encode(
        payload,
        settings.JWT_SECRET_KEY,
        algorithm=settings.JWT_ALGORITHM,
    )
    return token, jti


def decode_token(token: str) -> TokenPayload:
    """
    Декодирует и валидирует JWT.
    Raises JWTError при невалидном токене.
    """
    try:
        payload = jwt.decode(
            token,
            settings.JWT_SECRET_KEY,
            algorithms=[settings.JWT_ALGORITHM],
        )
    except JWTError as e:
        raise ValueError(f"Invalid token: {e}") from e

    sub = payload.get("sub")
    role_str = payload.get("role")
    jti = payload.get("jti")

    if not sub or not role_str or not jti:
        raise ValueError("Token missing required claims")

    try:
        role = UserRole(role_str)
    except ValueError:
        raise ValueError(f"Unknown role: {role_str}")

    return TokenPayload(sub=sub, role=role, jti=jti)


def hash_token(token: str) -> str:
    """SHA-256 хэш токена для хранения в sessions."""
    return hashlib.sha256(token.encode()).hexdigest()


# ─────────────────────────────────────────────────────────────────────────────
# Telegram WebApp / Bot auth
# ─────────────────────────────────────────────────────────────────────────────

def validate_telegram_init_data(init_data: str) -> dict[str, str]:
    """
    Проверяет initData от Telegram WebApp.
    Документация: https://core.telegram.org/bots/webapps#validating-data-received-via-the-web-app
    """
    import hashlib
    import hmac
    from urllib.parse import parse_qsl, urlencode

    params = dict(parse_qsl(init_data, keep_blank_values=True))
    check_hash = params.pop("hash", None)
    if not check_hash:
        raise ValueError("No hash in init_data")

    # Строка для проверки
    data_check_string = "\n".join(
        f"{k}={v}" for k, v in sorted(params.items())
    )
    secret_key = hmac.new(
        b"WebAppData",
        settings.BOT_TOKEN.encode(),
        hashlib.sha256,
    ).digest()
    computed = hmac.new(
        secret_key,
        data_check_string.encode(),
        hashlib.sha256,
    ).hexdigest()

    if not hmac.compare_digest(computed, check_hash):
        raise ValueError("Invalid Telegram init_data signature")

    return params


# ─────────────────────────────────────────────────────────────────────────────
# RBAC
# ─────────────────────────────────────────────────────────────────────────────

ROLE_PERMISSIONS: dict[UserRole, set[str]] = {
    UserRole.customer: {
        "order:create",
        "order:read_own",
        "product:read",
    },
    UserRole.operator: {
        "order:read_pool",
        "order:claim",
        "order:complete",
        "inventory:read_own",
        "inventory:write_own",
        "shift:manage",
        "payout:read_own",
    },
    UserRole.superadmin: {
        "order:read_all",
        "order:cancel",
        "product:create",
        "product:update",
        "product:delete",
        "operator:create",
        "operator:ban",
        "stats:read",
        "payout:create",
        "payout:confirm",
        "audit:read",
    },
}


def has_permission(role: UserRole, permission: str) -> bool:
    return permission in ROLE_PERMISSIONS.get(role, set())


def require_permission(role: UserRole, permission: str) -> None:
    if not has_permission(role, permission):
        raise PermissionError(
            f"Role {role} does not have permission: {permission}"
        )
