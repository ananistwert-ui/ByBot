import uuid
from datetime import datetime, timezone

from sqlalchemy import and_, func, select, text, update
from sqlalchemy.orm import joinedload

from models.models import Operator, OperatorInventory, Order, OrderStatus
from core.repositories.base import BaseRepository


class OrderRepository(BaseRepository[Order]):
    model = Order

    # ──────────────────────────────────────────────────────────────────────────
    # Pool queries
    # ──────────────────────────────────────────────────────────────────────────

    async def get_pool_for_operator(
        self,
        operator_id: uuid.UUID,
        *,
        limit: int = 50,
    ) -> list[Order]:
        """
        Возвращает заказы из пула, видимые конкретному оператору.
        Условия видимости (все три должны быть истинны):
          1. order.status = 'in_pool'
          2. operator.is_active = True
          3. operator_inventory.quantity_available > 0
             для данного продукта
        """
        stmt = (
            select(Order)
            .join(
                OperatorInventory,
                and_(
                    OperatorInventory.product_id == Order.product_id,
                    OperatorInventory.operator_id == operator_id,
                    OperatorInventory.quantity_available > 0,
                ),
            )
            .join(
                Operator,
                and_(
                    Operator.id == operator_id,
                    Operator.is_active.is_(True),
                ),
            )
            .where(Order.status == OrderStatus.in_pool)
            .options(joinedload(Order.product))
            .order_by(Order.created_at.asc())
            .limit(limit)
        )
        result = await self._session.execute(stmt)
        return list(result.scalars().unique().all())

    # ──────────────────────────────────────────────────────────────────────────
    # CRITICAL: Atomic claim — race condition protection
    # ──────────────────────────────────────────────────────────────────────────

    async def atomic_claim(
        self,
        order_id: uuid.UUID,
        operator_id: uuid.UUID,
    ) -> Order | None:
        """
        Атомарно клеймит заказ в одном UPDATE.

        Возвращает Order если успешно, None если заказ уже забрали.

        ВАЖНО: вызывается внутри транзакции вместе с
        atomic_decrement_inventory(). Оба UPDATE должны выполниться
        или ни один (транзакция обеспечивает это).
        """
        now = datetime.now(timezone.utc)
        stmt = (
            update(Order)
            .where(
                and_(
                    Order.id == order_id,
                    Order.status == OrderStatus.in_pool,  # атомарная проверка
                )
            )
            .values(
                status=OrderStatus.claimed,
                operator_id=operator_id,
                claimed_at=now,
                updated_at=now,
            )
            .returning(Order)
        )
        result = await self._session.execute(stmt)
        return result.scalar_one_or_none()

    async def atomic_complete(
        self,
        order_id: uuid.UUID,
        operator_id: uuid.UUID,
    ) -> Order | None:
        """
        Завершает заказ. Проверяет что оператор — именно тот,
        кто клеймил (защита от чужого завершения).
        """
        now = datetime.now(timezone.utc)
        stmt = (
            update(Order)
            .where(
                and_(
                    Order.id == order_id,
                    Order.operator_id == operator_id,
                    Order.status == OrderStatus.claimed,
                )
            )
            .values(
                status=OrderStatus.completed,
                completed_at=now,
                updated_at=now,
            )
            .returning(Order)
        )
        result = await self._session.execute(stmt)
        return result.scalar_one_or_none()

    async def transition_paid_to_pool(self, order_id: uuid.UUID) -> Order | None:
        """Переводит оплаченный заказ в пул."""
        now = datetime.now(timezone.utc)
        stmt = (
            update(Order)
            .where(
                and_(
                    Order.id == order_id,
                    Order.status == OrderStatus.paid,
                )
            )
            .values(status=OrderStatus.in_pool, updated_at=now)
            .returning(Order)
        )
        result = await self._session.execute(stmt)
        return result.scalar_one_or_none()

    async def cancel_expired_orders(self) -> int:
        """
        Для Celery task: отменяет просроченные pending_payment заказы.
        Возвращает количество отменённых.
        """
        now = datetime.now(timezone.utc)
        stmt = (
            update(Order)
            .where(
                and_(
                    Order.status == OrderStatus.pending_payment,
                    Order.expires_at < now,
                )
            )
            .values(
                status=OrderStatus.cancelled,
                cancelled_at=now,
                updated_at=now,
            )
        )
        result = await self._session.execute(stmt)
        return result.rowcount  # type: ignore[return-value]

    async def get_operator_orders(
        self,
        operator_id: uuid.UUID,
        *,
        status: OrderStatus | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> list[Order]:
        stmt = (
            select(Order)
            .where(Order.operator_id == operator_id)
            .options(joinedload(Order.product))
            .order_by(Order.created_at.desc())
            .limit(limit)
            .offset(offset)
        )
        if status:
            stmt = stmt.where(Order.status == status)
        result = await self._session.execute(stmt)
        return list(result.scalars().unique().all())

    async def get_customer_orders(
        self,
        customer_id: uuid.UUID,
        *,
        limit: int = 20,
        offset: int = 0,
    ) -> list[Order]:
        stmt = (
            select(Order)
            .where(Order.customer_id == customer_id)
            .options(
                joinedload(Order.product),
                joinedload(Order.payment),
            )
            .order_by(Order.created_at.desc())
            .limit(limit)
            .offset(offset)
        )
        result = await self._session.execute(stmt)
        return list(result.scalars().unique().all())

    async def get_completed_for_payout(
        self,
        operator_id: uuid.UUID,
        period_start: datetime,
        period_end: datetime,
    ) -> list[Order]:
        """Заказы для расчёта выплаты за период."""
        stmt = (
            select(Order)
            .join(Order.product)
            .where(
                and_(
                    Order.operator_id == operator_id,
                    Order.status == OrderStatus.completed,
                    Order.completed_at >= period_start,
                    Order.completed_at <= period_end,
                )
            )
            .options(joinedload(Order.product))
        )
        result = await self._session.execute(stmt)
        return list(result.scalars().unique().all())

    async def count_by_status(self) -> dict[str, int]:
        """Для admin dashboard: количество заказов по статусам."""
        stmt = (
            select(Order.status, func.count(Order.id))
            .group_by(Order.status)
        )
        result = await self._session.execute(stmt)
        return {row[0].value: row[1] for row in result.all()}
