import uuid

from sqlalchemy import and_, select, text, update
from sqlalchemy.orm import joinedload

from models.models import Operator, OperatorInventory
from core.repositories.base import BaseRepository


class InventoryRepository(BaseRepository[OperatorInventory]):
    model = OperatorInventory

    async def get_by_operator_product(
        self,
        operator_id: uuid.UUID,
        product_id: uuid.UUID,
    ) -> OperatorInventory | None:
        stmt = select(OperatorInventory).where(
            and_(
                OperatorInventory.operator_id == operator_id,
                OperatorInventory.product_id == product_id,
            )
        )
        result = await self._session.execute(stmt)
        return result.scalar_one_or_none()

    async def get_operator_inventory(
        self,
        operator_id: uuid.UUID,
    ) -> list[OperatorInventory]:
        stmt = (
            select(OperatorInventory)
            .where(OperatorInventory.operator_id == operator_id)
            .options(joinedload(OperatorInventory.product))
            .order_by(OperatorInventory.product_id)
        )
        result = await self._session.execute(stmt)
        return list(result.scalars().unique().all())

    async def upsert(
        self,
        operator_id: uuid.UUID,
        product_id: uuid.UUID,
        quantity: int,
    ) -> OperatorInventory:
        """
        INSERT ... ON CONFLICT UPDATE.
        Оператор может выставить количество заново.
        quantity НЕ может быть меньше quantity_reserved.
        """
        stmt = text("""
            INSERT INTO operator_inventory
                (id, operator_id, product_id, quantity_available,
                 quantity_reserved, updated_at)
            VALUES
                (uuid_generate_v4(), :operator_id, :product_id,
                 :quantity, 0, NOW())
            ON CONFLICT (operator_id, product_id) DO UPDATE SET
                quantity_available = GREATEST(
                    :quantity,
                    operator_inventory.quantity_reserved
                ),
                updated_at = NOW()
            RETURNING *
        """)
        result = await self._session.execute(stmt, {
            "operator_id": operator_id,
            "product_id": product_id,
            "quantity": quantity,
        })
        row = result.fetchone()
        await self._session.flush()
        # Возвращаем обновлённый объект через ORM
        return await self.get_by_operator_product(operator_id, product_id)  # type: ignore

    async def atomic_decrement(
        self,
        operator_id: uuid.UUID,
        product_id: uuid.UUID,
    ) -> bool:
        """
        Атомарно уменьшает quantity_available на 1,
        увеличивает quantity_reserved на 1.

        Возвращает True если успешно, False если quantity = 0.
        CHECK constraint quantity_available >= 0 — дополнительная защита.
        """
        stmt = (
            update(OperatorInventory)
            .where(
                and_(
                    OperatorInventory.operator_id == operator_id,
                    OperatorInventory.product_id == product_id,
                    OperatorInventory.quantity_available > 0,  # атомарная проверка
                )
            )
            .values(
                quantity_available=OperatorInventory.quantity_available - 1,
                quantity_reserved=OperatorInventory.quantity_reserved + 1,
            )
        )
        result = await self._session.execute(stmt)
        return result.rowcount > 0

    async def atomic_release_reserved(
        self,
        operator_id: uuid.UUID,
        product_id: uuid.UUID,
    ) -> None:
        """
        При завершении заказа: убирает резерв.
        quantity_available уже уменьшен — просто снимаем reservation.
        """
        stmt = (
            update(OperatorInventory)
            .where(
                and_(
                    OperatorInventory.operator_id == operator_id,
                    OperatorInventory.product_id == product_id,
                    OperatorInventory.quantity_reserved > 0,
                )
            )
            .values(
                quantity_reserved=OperatorInventory.quantity_reserved - 1,
            )
        )
        await self._session.execute(stmt)

    async def get_total_stock_by_product(self) -> dict[str, int]:
        """
        Суммарный сток по всем активным операторам.
        Используется в каталоге для клиента.
        """
        stmt = text("""
            SELECT
                oi.product_id::text,
                COALESCE(SUM(oi.quantity_available), 0)::int AS total
            FROM operator_inventory oi
            JOIN operators op ON op.id = oi.operator_id
            WHERE op.is_active = TRUE
              AND oi.quantity_available > 0
            GROUP BY oi.product_id
        """)
        result = await self._session.execute(stmt)
        return {row[0]: row[1] for row in result.all()}
