from datetime import datetime, timezone
from typing import Any

from sqlalchemy import select, update

from core.repositories.base import BaseRepository
from models.models import Payment, PaymentStatus


class PaymentRepository(BaseRepository[Payment]):
    model = Payment

    async def get_by_invoice_id(self, invoice_id: str) -> Payment | None:
        stmt = select(Payment).where(Payment.external_invoice_id == invoice_id)
        result = await self._session.execute(stmt)
        return result.scalar_one_or_none()

    async def mark_paid(
        self,
        payment_id,
        check_id: str,
        payload: dict[str, Any],
    ) -> Payment | None:
        """
        Атомарно помечает оплату как paid.
        WHERE status != 'paid' защищает от повторной обработки в race условиях
        (хотя основная защита — UNIQUE constraint на external_invoice_id).
        """
        stmt = (
            update(Payment)
            .where(
                Payment.id == payment_id,
                Payment.status != PaymentStatus.paid,
            )
            .values(
                status=PaymentStatus.paid,
                external_check_id=check_id,
                paid_at=datetime.now(timezone.utc),
                webhook_payload=payload,
            )
            .returning(Payment)
        )
        result = await self._session.execute(stmt)
        return result.scalar_one_or_none()
