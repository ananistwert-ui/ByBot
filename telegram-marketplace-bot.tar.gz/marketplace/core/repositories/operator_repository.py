import uuid
from datetime import datetime, timezone
from decimal import Decimal

from sqlalchemy import select, update

from core.repositories.base import BaseRepository
from models.models import Operator


class OperatorRepository(BaseRepository[Operator]):
    model = Operator

    async def get_by_user_id(self, user_id: uuid.UUID) -> Operator | None:
        stmt = select(Operator).where(Operator.user_id == user_id)
        result = await self._session.execute(stmt)
        return result.scalar_one_or_none()

    async def start_shift(self, operator_id: uuid.UUID) -> Operator | None:
        now = datetime.now(timezone.utc)
        stmt = (
            update(Operator)
            .where(Operator.id == operator_id)
            .values(
                is_active=True,
                shift_started_at=now,
                last_seen=now,
            )
            .returning(Operator)
        )
        result = await self._session.execute(stmt)
        return result.scalar_one_or_none()

    async def stop_shift(self, operator_id: uuid.UUID) -> Operator | None:
        stmt = (
            update(Operator)
            .where(Operator.id == operator_id)
            .values(
                is_active=False,
                shift_started_at=None,
            )
            .returning(Operator)
        )
        result = await self._session.execute(stmt)
        return result.scalar_one_or_none()

    async def update_last_seen(self, operator_id: uuid.UUID) -> None:
        stmt = (
            update(Operator)
            .where(Operator.id == operator_id)
            .values(last_seen=datetime.now(timezone.utc))
        )
        await self._session.execute(stmt)

    async def increment_earnings(
        self,
        operator_id: uuid.UUID,
        amount: Decimal,
    ) -> Operator | None:
        """Атомарное начисление reward за выполненный заказ."""
        stmt = (
            update(Operator)
            .where(Operator.id == operator_id)
            .values(total_earned=Operator.total_earned + amount)
            .returning(Operator)
        )
        result = await self._session.execute(stmt)
        return result.scalar_one_or_none()

    async def decrement_earnings(
        self,
        operator_id: uuid.UUID,
        amount: Decimal,
    ) -> Operator | None:
        """
        Используется при выплате payout — earnings "снимаются" после paid.
        Защищено CHECK constraint total_earned >= 0 на уровне БД.
        """
        stmt = (
            update(Operator)
            .where(
                Operator.id == operator_id,
                Operator.total_earned >= amount,  # атомарная проверка
            )
            .values(total_earned=Operator.total_earned - amount)
            .returning(Operator)
        )
        result = await self._session.execute(stmt)
        return result.scalar_one_or_none()

    async def list_active(self) -> list[Operator]:
        stmt = select(Operator).where(Operator.is_active.is_(True))
        result = await self._session.execute(stmt)
        return list(result.scalars().all())
