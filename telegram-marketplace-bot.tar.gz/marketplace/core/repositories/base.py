import uuid
from typing import Any, Generic, TypeVar

from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from models.base import Base

ModelT = TypeVar("ModelT", bound=Base)


class BaseRepository(Generic[ModelT]):
    """
    Generic репозиторий. Изолирует SQLAlchemy от бизнес-логики.
    Все конкретные репозитории наследуются отсюда.
    """

    model: type[ModelT]

    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def get_by_id(self, entity_id: uuid.UUID) -> ModelT | None:
        return await self._session.get(self.model, entity_id)

    async def get_by_id_or_raise(self, entity_id: uuid.UUID) -> ModelT:
        obj = await self.get_by_id(entity_id)
        if obj is None:
            raise ValueError(f"{self.model.__name__} {entity_id} not found")
        return obj

    async def create(self, **kwargs: Any) -> ModelT:
        obj = self.model(**kwargs)
        self._session.add(obj)
        await self._session.flush()  # получаем id без commit
        await self._session.refresh(obj)
        return obj

    async def update(
        self,
        entity_id: uuid.UUID,
        **kwargs: Any,
    ) -> ModelT | None:
        stmt = (
            update(self.model)
            .where(self.model.id == entity_id)  # type: ignore[attr-defined]
            .values(**kwargs)
            .returning(self.model)
        )
        result = await self._session.execute(stmt)
        return result.scalar_one_or_none()

    async def exists(self, entity_id: uuid.UUID) -> bool:
        obj = await self.get_by_id(entity_id)
        return obj is not None

    async def list_all(
        self,
        *,
        limit: int = 100,
        offset: int = 0,
    ) -> list[ModelT]:
        stmt = (
            select(self.model)
            .limit(limit)
            .offset(offset)
        )
        result = await self._session.execute(stmt)
        return list(result.scalars().all())
