import uuid
from datetime import datetime, timedelta, timezone
from decimal import Decimal

import structlog

from config.settings import settings
from core.repositories.inventory_repository import InventoryRepository
from core.repositories.order_repository import OrderRepository
from core.services.audit_service import AuditService
from core.services.payment_service import CryptoBotService
from models.models import Order, OrderStatus, Product, User

logger = structlog.get_logger(__name__)


class OrderAlreadyClaimedError(Exception):
    pass


class OrderNotFoundError(Exception):
    pass


class InsufficientInventoryError(Exception):
    pass


class InvalidOrderTransitionError(Exception):
    pass


class OrderService:
    """
    Центральная бизнес-логика заказов.
    Не знает о HTTP/Telegram — только о бизнес-правилах.
    """

    def __init__(
        self,
        order_repo: OrderRepository,
        inventory_repo: InventoryRepository,
        audit_service: AuditService,
        cryptobot: CryptoBotService,
    ) -> None:
        self._orders = order_repo
        self._inventory = inventory_repo
        self._audit = audit_service
        self._cryptobot = cryptobot

    async def create_pending_order(
        self,
        customer: User,
        product: Product,
    ) -> tuple[Order, str]:
        """
        Шаг 1: создаёт заказ и invoice в CryptoBot.
        Заказ НЕ создаётся до получения invoice_id.

        Returns: (order, pay_url)
        """
        # Создаём invoice сначала — если CryptoBot недоступен,
        # заказ не создаётся вообще
        invoice = await self._cryptobot.create_invoice(
            amount=product.price,
            currency=product.currency,
            description=f"Order: {product.title}",
            payload=str(uuid.uuid4()),  # internal idempotency key
        )

        expires_at = datetime.now(timezone.utc) + timedelta(
            minutes=settings.ORDER_PAYMENT_TIMEOUT_MINUTES
        )

        order = await self._orders.create(
            customer_id=customer.id,
            product_id=product.id,
            status=OrderStatus.pending_payment,
            amount=product.price,
            currency=product.currency,
            expires_at=expires_at,
        )

        # Payment record сразу — для idempotency при webhook
        from core.repositories.payment_repository import PaymentRepository
        # Импорт внутри метода избегает циклического импорта
        payment_repo = PaymentRepository(self._orders._session)
        await payment_repo.create(
            order_id=order.id,
            external_invoice_id=str(invoice["invoice_id"]),
            amount=product.price,
            currency=product.currency,
        )

        await self._audit.log(
            action="order.created",
            entity_type="order",
            entity_id=order.id,
            actor_id=customer.id,
            after_data={"order_id": str(order.id), "product": product.title},
        )

        logger.info(
            "order_created",
            order_id=str(order.id),
            customer_id=str(customer.id),
            product=product.title,
        )

        return order, invoice["bot_invoice_url"]

    async def handle_payment_webhook(
        self,
        invoice_id: str,
        check_id: str,
        payload: dict,
    ) -> Order:
        """
        Шаг 2: обрабатывает подтверждённую оплату от CryptoBot.
        Идемпотентен: повторный вызов с тем же invoice_id
        возвращает уже обработанный заказ без side effects.
        """
        from core.repositories.payment_repository import PaymentRepository
        payment_repo = PaymentRepository(self._orders._session)

        payment = await payment_repo.get_by_invoice_id(invoice_id)
        if payment is None:
            raise OrderNotFoundError(f"Invoice {invoice_id} not found")

        # Идемпотентность: уже обработан
        if payment.status.value == "paid":
            logger.warning("duplicate_webhook", invoice_id=invoice_id)
            order = await self._orders.get_by_id_or_raise(payment.order_id)
            return order

        # Обновляем payment
        await payment_repo.mark_paid(
            payment_id=payment.id,
            check_id=check_id,
            payload=payload,
        )

        # Переводим заказ: paid → in_pool
        order = await self._orders.transition_paid_to_pool(payment.order_id)
        if order is None:
            raise InvalidOrderTransitionError(
                f"Order {payment.order_id} cannot transition to in_pool"
            )

        await self._audit.log(
            action="order.paid_and_pooled",
            entity_type="order",
            entity_id=order.id,
            after_data={"invoice_id": invoice_id, "status": "in_pool"},
        )

        logger.info("order_moved_to_pool", order_id=str(order.id))
        return order

    async def claim_order(
        self,
        order_id: uuid.UUID,
        operator_id: uuid.UUID,
        product_id: uuid.UUID,
    ) -> Order:
        """
        Шаг 3: оператор берёт заказ.

        КРИТИЧНО: атомарное выполнение двух операций:
        1. atomic_claim — UPDATE orders WHERE status='in_pool'
        2. atomic_decrement — UPDATE inventory WHERE quantity > 0

        Если любая из операций не проходит → rollback всей транзакции.
        """
        # Атомарный claim
        order = await self._orders.atomic_claim(order_id, operator_id)
        if order is None:
            # Заказ уже забрали или не в пуле
            raise OrderAlreadyClaimedError(
                f"Order {order_id} is not available for claiming"
            )

        # Атомарное уменьшение инвентаря
        decremented = await self._inventory.atomic_decrement(
            operator_id=operator_id,
            product_id=product_id,
        )
        if not decremented:
            # Инвентарь кончился между проверкой пула и claim
            # Rollback произойдёт автоматически на уровне session
            raise InsufficientInventoryError(
                f"Operator {operator_id} has no inventory for product {product_id}"
            )

        await self._audit.log(
            action="order.claimed",
            entity_type="order",
            entity_id=order.id,
            actor_id=operator_id,
            after_data={
                "operator_id": str(operator_id),
                "claimed_at": order.claimed_at.isoformat() if order.claimed_at else None,
            },
        )

        logger.info(
            "order_claimed",
            order_id=str(order.id),
            operator_id=str(operator_id),
        )
        return order

    async def complete_order(
        self,
        order_id: uuid.UUID,
        operator_id: uuid.UUID,
    ) -> Order:
        """
        Шаг 4: оператор подтверждает выполнение.
        Снимает резервацию инвентаря.
        Начисляет reward оператору.
        """
        order = await self._orders.atomic_complete(order_id, operator_id)
        if order is None:
            raise OrderNotFoundError(
                f"Order {order_id} cannot be completed by operator {operator_id}"
            )

        # Снимаем резерв инвентаря (quantity_available уже уменьшен при claim)
        await self._inventory.atomic_release_reserved(
            operator_id=operator_id,
            product_id=order.product_id,
        )

        # Начисляем reward оператору
        from core.repositories.operator_repository import OperatorRepository
        op_repo = OperatorRepository(self._orders._session)
        await op_repo.increment_earnings(
            operator_id=operator_id,
            amount=order.product.reward_amount if order.product else Decimal("0"),
        )

        await self._audit.log(
            action="order.completed",
            entity_type="order",
            entity_id=order.id,
            actor_id=operator_id,
            after_data={
                "completed_at": order.completed_at.isoformat() if order.completed_at else None,
            },
        )

        logger.info(
            "order_completed",
            order_id=str(order.id),
            operator_id=str(operator_id),
        )
        return order

    async def get_pool_for_operator(
        self,
        operator_id: uuid.UUID,
    ) -> list[Order]:
        return await self._orders.get_pool_for_operator(operator_id)

    async def cancel_expired_orders(self) -> int:
        """Called by Celery Beat task."""
        count = await self._orders.cancel_expired_orders()
        if count > 0:
            logger.info("expired_orders_cancelled", count=count)
        return count
