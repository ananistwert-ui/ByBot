import hashlib
import hmac
import json
from decimal import Decimal
from typing import Any

import httpx
import structlog

from config.settings import settings

logger = structlog.get_logger(__name__)


class CryptoBotError(Exception):
    pass


class WebhookSignatureError(Exception):
    pass


class CryptoBotService:
    """
    Клиент CryptoBot Pay API.
    Документация: https://help.crypt.bot/crypto-pay-api
    """

    def __init__(self) -> None:
        self._base_url = settings.CRYPTOBOT_API_URL
        self._token = settings.CRYPTOBOT_TOKEN
        self._webhook_secret = settings.CRYPTOBOT_WEBHOOK_SECRET
        self._client = httpx.AsyncClient(
            base_url=self._base_url,
            headers={
                "Crypto-Pay-API-Token": self._token,
                "Content-Type": "application/json",
            },
            timeout=httpx.Timeout(10.0, connect=5.0),
        )

    async def create_invoice(
        self,
        amount: Decimal,
        currency: str,
        description: str,
        payload: str,  # internal idempotency key
    ) -> dict[str, Any]:
        """
        Создаёт invoice в CryptoBot.
        Returns dict с invoice_id и bot_invoice_url.
        """
        body = {
            "asset": currency,
            "amount": str(amount),
            "description": description,
            "payload": payload,
            "allow_comments": False,
            "allow_anonymous": True,
        }
        try:
            response = await self._client.post("/createInvoice", json=body)
            response.raise_for_status()
            data = response.json()
        except httpx.HTTPStatusError as e:
            logger.error(
                "cryptobot_create_invoice_error",
                status=e.response.status_code,
                body=e.response.text,
            )
            raise CryptoBotError(f"CryptoBot API error: {e.response.status_code}") from e
        except httpx.RequestError as e:
            logger.error("cryptobot_network_error", error=str(e))
            raise CryptoBotError(f"Network error: {e}") from e

        if not data.get("ok"):
            raise CryptoBotError(f"CryptoBot returned not ok: {data}")

        result = data["result"]
        return {
            "invoice_id": result["invoice_id"],
            "bot_invoice_url": result["bot_invoice_url"],
            "status": result["status"],
        }

    async def get_invoice(self, invoice_id: int) -> dict[str, Any]:
        """Проверяет статус invoice (для polling / ручной проверки)."""
        try:
            response = await self._client.get(
                "/getInvoices",
                params={"invoice_ids": str(invoice_id)},
            )
            response.raise_for_status()
            data = response.json()
        except (httpx.HTTPStatusError, httpx.RequestError) as e:
            raise CryptoBotError(str(e)) from e

        if not data.get("ok") or not data["result"]["items"]:
            raise CryptoBotError(f"Invoice {invoice_id} not found")

        return data["result"]["items"][0]

    def validate_webhook_signature(
        self,
        body: bytes,
        signature: str,
    ) -> None:
        """
        Проверяет подпись webhook от CryptoBot.
        Алгоритм: HMAC-SHA256(body, token_sha256)

        Вызывает WebhookSignatureError если подпись невалидна.
        Это критично для защиты от поддельных webhook.
        """
        # CryptoBot использует SHA256 от токена как ключ HMAC
        token_bytes = self._token.encode()
        secret_key = hashlib.sha256(token_bytes).digest()

        expected = hmac.new(
            secret_key,
            body,
            hashlib.sha256,
        ).hexdigest()

        # Constant-time comparison — защита от timing attack
        if not hmac.compare_digest(expected, signature):
            logger.warning(
                "webhook_signature_invalid",
                expected=expected[:8] + "...",
                received=signature[:8] + "...",
            )
            raise WebhookSignatureError("Invalid webhook signature")

    def parse_webhook_body(self, body: bytes) -> dict[str, Any]:
        """Парсит тело webhook и возвращает структурированные данные."""
        try:
            data = json.loads(body)
        except json.JSONDecodeError as e:
            raise CryptoBotError(f"Invalid JSON in webhook: {e}") from e

        update_type = data.get("update_type")
        if update_type != "invoice_paid":
            logger.info("webhook_unknown_type", update_type=update_type)
            return {}

        payload = data.get("payload", {})
        return {
            "invoice_id": str(payload.get("invoice_id", "")),
            "check_id": str(payload.get("hash", "")),
            "status": payload.get("status", ""),
            "asset": payload.get("asset", ""),
            "amount": payload.get("amount", "0"),
            "raw": data,
        }

    async def aclose(self) -> None:
        await self._client.aclose()
