import uuid
from typing import Any

from sqlalchemy.ext.asyncio import AsyncSession

from models.models import AuditLog


class AuditService:
    """
    Сервис аудита. Только INSERT, никогда UPDATE/DELETE.
    Используется из всех сервисов для трассируемости.
    """

    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def log(
        self,
        action: str,
        entity_type: str,
        entity_id: uuid.UUID | None = None,
        actor_id: uuid.UUID | None = None,
        actor_type: str = "user",
        before_data: dict[str, Any] | None = None,
        after_data: dict[str, Any] | None = None,
        ip_address: str | None = None,
        meta: dict[str, Any] | None = None,
    ) -> AuditLog:
        """
        Записывает событие в audit_log.
        Все данные сериализуются в JSONB.
        """
        log_entry = AuditLog(
            actor_id=actor_id,
            actor_type=actor_type,
            action=action,
            entity_type=entity_type,
            entity_id=entity_id,
            before_data=_serialize(before_data),
            after_data=_serialize(after_data),
            ip_address=ip_address,
            meta=_serialize(meta),
        )
        self._session.add(log_entry)
        await self._session.flush()
        return log_entry

    async def log_system(
        self,
        action: str,
        entity_type: str,
        entity_id: uuid.UUID | None = None,
        meta: dict[str, Any] | None = None,
    ) -> AuditLog:
        """Для системных событий (Celery tasks, webhooks)."""
        return await self.log(
            action=action,
            entity_type=entity_type,
            entity_id=entity_id,
            actor_type="system",
            meta=meta,
        )


def _serialize(data: dict[str, Any] | None) -> dict[str, Any] | None:
    """Конвертирует UUID и datetime в строки для JSONB."""
    if data is None:
        return None
    result = {}
    for k, v in data.items():
        if isinstance(v, uuid.UUID):
            result[k] = str(v)
        elif hasattr(v, "isoformat"):
            result[k] = v.isoformat()
        else:
            result[k] = v
    return result
