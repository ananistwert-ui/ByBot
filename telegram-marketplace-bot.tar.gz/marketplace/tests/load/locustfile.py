"""
Load test для проверки поведения системы под нагрузкой.

Запуск:
    locust -f tests/load/locustfile.py --host=http://localhost:8000

Сценарии:
1. Множество customers создают заказы одновременно
2. Множество operators пытаются claim заказы из общего пула
   (проверка деградации под высокой конкуренцией за claim)
"""
import random
import uuid

from locust import HttpUser, between, task


class CustomerLoadUser(HttpUser):
    """Симулирует клиентов, просматривающих каталог и создающих заказы."""
    wait_time = between(1, 3)
    weight = 3  # клиентов больше, чем операторов

    def on_start(self):
        self.token = self._authenticate()

    def _authenticate(self) -> str:
        # В реальном тесте — настоящая авторизация через тестовый init_data
        # Здесь — placeholder для структуры теста
        return "test-customer-token"

    @task(5)
    def view_catalog(self):
        self.client.get("/api/products/catalog")

    @task(1)
    def create_order(self):
        # product_id должен существовать в seed data перед запуском теста
        product_id = self._get_random_product_id()
        with self.client.post(
            "/api/orders",
            json={"product_id": product_id},
            headers={"Authorization": f"Bearer {self.token}"},
            catch_response=True,
        ) as response:
            if response.status_code == 201:
                response.success()
            elif response.status_code == 404:
                # Продукт может быть деактивирован во время теста — ожидаемо
                response.success()
            else:
                response.failure(f"Unexpected status: {response.status_code}")

    def _get_random_product_id(self) -> str:
        # Заполняется из seed script перед запуском нагрузочного теста
        return str(uuid.uuid4())


class OperatorClaimStormUser(HttpUser):
    """
    Симулирует множество операторов, борющихся за один и тот же
    ограниченный пул заказов — главный сценарий для проверки
    race condition protection под реальной нагрузкой.
    """
    wait_time = between(0.1, 0.5)  # агрессивный polling пула
    weight = 1

    def on_start(self):
        self.token = self._authenticate()

    def _authenticate(self) -> str:
        return "test-operator-token"

    @task(3)
    def check_pool(self):
        with self.client.get(
            "/api/operators/orders/pool",
            headers={"Authorization": f"Bearer {self.token}"},
            catch_response=True,
        ) as response:
            if response.status_code == 200:
                response.success()
                orders = response.json()
                if orders:
                    self._try_claim(orders[0]["id"])

    def _try_claim(self, order_id: str) -> None:
        with self.client.post(
            "/api/operators/orders/claim",
            json={"order_id": order_id},
            headers={"Authorization": f"Bearer {self.token}"},
            catch_response=True,
        ) as response:
            # 409 — ОЖИДАЕМЫЙ результат при конкуренции, не ошибка нагрузочного теста
            if response.status_code in (200, 409):
                response.success()
            else:
                response.failure(f"Unexpected claim status: {response.status_code}")

    @task(1)
    def toggle_shift(self):
        endpoint = random.choice(["start", "stop"])
        self.client.post(
            f"/api/operators/shift/{endpoint}",
            headers={"Authorization": f"Bearer {self.token}"},
        )
