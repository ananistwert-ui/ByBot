import uuid
from decimal import Decimal

import pytest
from httpx import ASGITransport, AsyncClient

from core.security.auth import create_access_token, hash_token
from models.models import Session, User, UserRole

pytestmark = pytest.mark.asyncio


async def _make_auth_headers(db_session, user: User) -> dict:
    token, _ = create_access_token(user.id, user.role)
    db_session.add(Session(
        user_id=user.id,
        token_hash=hash_token(token),
        expires_at=__import__("datetime").datetime.now(
            __import__("datetime").timezone.utc
        ) + __import__("datetime").timedelta(hours=1),
    ))
    await db_session.flush()
    return {"Authorization": f"Bearer {token}"}


@pytest.fixture
async def app_client(db_session, monkeypatch):
    """
    Тестовый ASGI клиент с переопределённой DB dependency,
    использующей тестовую транзакционную сессию.
    """
    from api.app import create_app
    from api.dependencies.auth import get_db_session

    app = create_app()

    async def override_get_db():
        yield db_session

    app.dependency_overrides[get_db_session] = override_get_db

    # Redis mock для rate limiting middleware
    class _FakeRedis:
        async def incr(self, key): return 1
        async def expire(self, key, ttl): return True
        async def ping(self): return True

    app.state.redis = _FakeRedis()

    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        yield client


class TestProductsAPI:

    async def test_get_catalog_returns_active_products(
        self, app_client, db_session, product
    ):
        response = await app_client.get("/api/products/catalog")
        assert response.status_code == 200
        data = response.json()
        assert any(p["id"] == str(product.id) for p in data)

    async def test_admin_can_create_product(
        self, app_client, db_session
    ):
        admin_user = User(telegram_id=999001, role=UserRole.superadmin)
        db_session.add(admin_user)
        await db_session.flush()
        headers = await _make_auth_headers(db_session, admin_user)

        response = await app_client.post(
            "/api/products",
            json={
                "title": "Disney+ Premium",
                "price": "7.99",
                "currency": "USDT",
                "reward_amount": "1.00",
            },
            headers=headers,
        )

        assert response.status_code == 201
        data = response.json()
        assert data["title"] == "Disney+ Premium"

    async def test_customer_cannot_create_product(
        self, app_client, db_session, customer_user
    ):
        """КРИТИЧНО по ТЗ: только SuperAdmin создаёт товары."""
        headers = await _make_auth_headers(db_session, customer_user)

        response = await app_client.post(
            "/api/products",
            json={"title": "Hacked Product", "price": "1.00"},
            headers=headers,
        )

        assert response.status_code == 403

    async def test_operator_cannot_create_product(
        self, app_client, db_session, operator_user
    ):
        """КРИТИЧНО по ТЗ: оператор НЕ может создавать товар."""
        headers = await _make_auth_headers(db_session, operator_user)

        response = await app_client.post(
            "/api/products",
            json={"title": "Operator Product", "price": "1.00"},
            headers=headers,
        )

        assert response.status_code == 403

    async def test_unauthenticated_request_rejected(self, app_client):
        response = await app_client.post(
            "/api/products",
            json={"title": "No Auth", "price": "1.00"},
        )
        assert response.status_code == 401


class TestOrdersAPI:

    async def test_customer_creates_order(
        self, app_client, db_session, customer_user, product, monkeypatch
    ):
        async def fake_create_invoice(self, **kwargs):
            return {
                "invoice_id": 555,
                "bot_invoice_url": "https://t.me/fake_invoice",
                "status": "active",
            }

        monkeypatch.setattr(
            "core.services.payment_service.CryptoBotService.create_invoice",
            fake_create_invoice,
        )

        headers = await _make_auth_headers(db_session, customer_user)

        response = await app_client.post(
            "/api/orders",
            json={"product_id": str(product.id)},
            headers=headers,
        )

        assert response.status_code == 201
        data = response.json()
        assert data["pay_url"] == "https://t.me/fake_invoice"
        assert Decimal(data["amount"]) == product.price

    async def test_customer_cannot_view_others_order(
        self, app_client, db_session, customer_user, product
    ):
        other_user = User(telegram_id=888001, role=UserRole.customer)
        db_session.add(other_user)
        await db_session.flush()

        from datetime import datetime, timedelta, timezone
        from models.models import Order, OrderStatus

        other_order = Order(
            customer_id=other_user.id,
            product_id=product.id,
            status=OrderStatus.pending_payment,
            amount=product.price,
            currency="USDT",
            expires_at=datetime.now(timezone.utc) + timedelta(minutes=30),
        )
        db_session.add(other_order)
        await db_session.flush()

        headers = await _make_auth_headers(db_session, customer_user)

        response = await app_client.get(
            f"/api/orders/{other_order.id}", headers=headers
        )
        assert response.status_code == 403

    async def test_create_order_for_inactive_product_fails(
        self, app_client, db_session, customer_user, product
    ):
        product.is_active = False
        await db_session.flush()
        headers = await _make_auth_headers(db_session, customer_user)

        response = await app_client.post(
            "/api/orders",
            json={"product_id": str(product.id)},
            headers=headers,
        )
        assert response.status_code == 404


class TestOperatorAPI:

    async def test_operator_claims_order_from_pool(
        self, app_client, db_session, operator_user, operator,
        product, inventory_with_stock, pooled_order,
    ):
        headers = await _make_auth_headers(db_session, operator_user)

        response = await app_client.post(
            "/api/operators/orders/claim",
            json={"order_id": str(pooled_order.id)},
            headers=headers,
        )

        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "claimed"

    async def test_claiming_already_claimed_order_returns_409(
        self, app_client, db_session, operator_user, operator,
        second_operator, product, inventory_with_stock, pooled_order,
    ):
        from datetime import datetime, timezone
        pooled_order.status = __import__(
            "models.models", fromlist=["OrderStatus"]
        ).OrderStatus.claimed
        pooled_order.operator_id = second_operator.id
        pooled_order.claimed_at = datetime.now(timezone.utc)
        await db_session.flush()

        headers = await _make_auth_headers(db_session, operator_user)

        response = await app_client.post(
            "/api/operators/orders/claim",
            json={"order_id": str(pooled_order.id)},
            headers=headers,
        )

        assert response.status_code == 409
