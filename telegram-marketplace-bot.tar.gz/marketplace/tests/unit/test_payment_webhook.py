import hashlib
import hmac
import json

import pytest

from core.services.payment_service import CryptoBotService, WebhookSignatureError


@pytest.fixture
def cryptobot_service(monkeypatch):
    monkeypatch.setattr(
        "config.settings.settings.CRYPTOBOT_TOKEN", "test_token_12345"
    )
    monkeypatch.setattr(
        "config.settings.settings.CRYPTOBOT_WEBHOOK_SECRET", "test_secret"
    )
    return CryptoBotService()


def _sign(token: str, body: bytes) -> str:
    secret_key = hashlib.sha256(token.encode()).digest()
    return hmac.new(secret_key, body, hashlib.sha256).hexdigest()


class TestWebhookSignatureValidation:

    def test_valid_signature_passes(self, cryptobot_service):
        body = json.dumps({"update_type": "invoice_paid"}).encode()
        signature = _sign("test_token_12345", body)

        # Не должно бросать исключение
        cryptobot_service.validate_webhook_signature(body, signature)

    def test_invalid_signature_raises(self, cryptobot_service):
        body = json.dumps({"update_type": "invoice_paid"}).encode()
        bad_signature = "0" * 64

        with pytest.raises(WebhookSignatureError):
            cryptobot_service.validate_webhook_signature(body, bad_signature)

    def test_tampered_body_fails_signature_check(self, cryptobot_service):
        """
        Атакующий перехватил валидный webhook и изменил amount.
        Подпись для оригинального тела не должна проходить для нового.
        """
        original_body = json.dumps({"amount": "10.00"}).encode()
        signature = _sign("test_token_12345", original_body)

        tampered_body = json.dumps({"amount": "99999.00"}).encode()

        with pytest.raises(WebhookSignatureError):
            cryptobot_service.validate_webhook_signature(tampered_body, signature)

    def test_signature_from_wrong_token_fails(self, cryptobot_service):
        """Подпись, сделанная с другим токеном (не нашим), должна отвергаться."""
        body = json.dumps({"update_type": "invoice_paid"}).encode()
        signature_with_wrong_token = _sign("attacker_token", body)

        with pytest.raises(WebhookSignatureError):
            cryptobot_service.validate_webhook_signature(body, signature_with_wrong_token)


class TestWebhookParsing:

    def test_parses_invoice_paid_event(self, cryptobot_service):
        body = json.dumps({
            "update_type": "invoice_paid",
            "payload": {
                "invoice_id": 123,
                "hash": "abc123",
                "status": "paid",
                "asset": "USDT",
                "amount": "9.99",
            },
        }).encode()

        result = cryptobot_service.parse_webhook_body(body)

        assert result["invoice_id"] == "123"
        assert result["check_id"] == "abc123"
        assert result["amount"] == "9.99"

    def test_ignores_non_invoice_paid_events(self, cryptobot_service):
        body = json.dumps({"update_type": "some_other_event"}).encode()
        result = cryptobot_service.parse_webhook_body(body)
        assert result == {}

    def test_raises_on_invalid_json(self, cryptobot_service):
        from core.services.payment_service import CryptoBotError

        with pytest.raises(CryptoBotError):
            cryptobot_service.parse_webhook_body(b"not valid json {{{")
