import uuid

import pytest
from jose import jwt

from config.settings import settings
from core.security.auth import (
    create_access_token,
    decode_token,
    has_permission,
    hash_token,
    require_permission,
)
from models.models import UserRole


class TestJWT:

    def test_create_and_decode_access_token(self):
        user_id = uuid.uuid4()
        token, jti = create_access_token(user_id, UserRole.operator)

        payload = decode_token(token)

        assert payload.sub == str(user_id)
        assert payload.role == UserRole.operator
        assert payload.jti == jti

    def test_decode_rejects_tampered_token(self):
        user_id = uuid.uuid4()
        token, _ = create_access_token(user_id, UserRole.customer)

        tampered = token[:-5] + "AAAAA"

        with pytest.raises(ValueError):
            decode_token(tampered)

    def test_decode_rejects_wrong_secret(self):
        # Токен, подписанный другим секретом — имитация поддельного токена
        payload = {
            "sub": str(uuid.uuid4()),
            "role": "superadmin",
            "jti": str(uuid.uuid4()),
        }
        forged_token = jwt.encode(payload, "wrong-secret-key-1234567890123456", algorithm="HS256")

        with pytest.raises(ValueError):
            decode_token(forged_token)

    def test_decode_rejects_missing_claims(self):
        # Токен без обязательных полей (например, без role)
        incomplete_payload = {"sub": str(uuid.uuid4())}
        token = jwt.encode(
            incomplete_payload,
            settings.JWT_SECRET_KEY,
            algorithm=settings.JWT_ALGORITHM,
        )

        with pytest.raises(ValueError):
            decode_token(token)

    def test_hash_token_is_deterministic(self):
        token = "some-jwt-token-string"
        assert hash_token(token) == hash_token(token)

    def test_hash_token_differs_for_different_tokens(self):
        assert hash_token("token-a") != hash_token("token-b")


class TestRBAC:

    def test_customer_can_create_order(self):
        assert has_permission(UserRole.customer, "order:create") is True

    def test_customer_cannot_claim_order(self):
        assert has_permission(UserRole.customer, "order:claim") is False

    def test_operator_can_claim_order(self):
        assert has_permission(UserRole.operator, "order:claim") is True

    def test_operator_cannot_create_product(self):
        """КРИТИЧНО по ТЗ: 'Оператор НЕ может создавать товар.'"""
        assert has_permission(UserRole.operator, "product:create") is False

    def test_superadmin_can_create_product(self):
        assert has_permission(UserRole.superadmin, "product:create") is True

    def test_superadmin_cannot_claim_order(self):
        """Админ не должен иметь операторских прав по умолчанию."""
        assert has_permission(UserRole.superadmin, "order:claim") is False

    def test_require_permission_raises_for_missing_permission(self):
        with pytest.raises(PermissionError):
            require_permission(UserRole.operator, "product:create")

    def test_require_permission_passes_for_valid_permission(self):
        # Не должно бросать исключение
        require_permission(UserRole.operator, "order:claim")
