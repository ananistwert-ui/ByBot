from datetime import datetime, timedelta, timezone
from decimal import Decimal

import pytest

from core.repositories.inventory_repository import InventoryRepository
from core.repositories.order_repository import OrderRepository
from core.services.audit_service import AuditService
from core.services.order_service import (
    InsufficientInventoryError,
    OrderAlreadyClaimedError,
    OrderNotFoundError,
    OrderService,
)
from models.models import Operator, OperatorInventory, Order, OrderStatus, User

pytestmark = pytest.mark.asyncio


class _FakeCryptoBot:
    async def create_invoice(self, **kwargs):
        return {"invoice_id": 999, "bot_invoice_url": "https://t.me/fake_pay", "status": "active"}


@pytest.fixture
def order_service(db_session):
    return OrderService(
        order_repo=OrderRepository(db_session),
        inventory_repo=InventoryRepository(db_session),
        audit_service=AuditService(db_session),
        cryptobot=_FakeCryptoBot(),
    )


class TestCreatePendingOrder:

    async def test_creates_order_with_pending_payment_status(
        self, db_session, order_service, customer_user, product
    ):
        order, pay_url = await order_service.create_pending_order(customer_user, product)

        assert order.status == OrderStatus.pending_payment
        assert order.amount == product.price
        assert order.customer_id == customer_user.id
        assert pay_url == "https://t.me/fake_pay"
        assert order.expires_at > datetime.now(timezone.utc)

    async def test_sets_expiry_timeout(self, db_session, order_service, customer_user, product):
        before = datetime.now(timezone.utc)
        order, _ = await order_service.create_pending_order(customer_user, product)
        after = datetime.now(timezone.utc)

        # expires_at должен быть в пределах ORDER_PAYMENT_TIMEOUT_MINUTES от создания
        assert order.expires_at > before
        assert order.expires_at > after  # ещё не истёк


class TestClaimOrder:

    async def test_claim_succeeds_with_available_inventory(
        self, db_session, order_service, operator, product,
        inventory_with_stock, pooled_order,
    ):
        order = await order_service.claim_order(
            pooled_order.id, operator.id, product.id
        )

        assert order.status == OrderStatus.claimed
        assert order.operator_id == operator.id
        assert order.claimed_at is not None

    async def test_claim_decrements_inventory(
        self, db_session, order_service, operator, product,
        inventory_with_stock, pooled_order,
    ):
        initial_qty = inventory_with_stock.quantity_available

        await order_service.claim_order(pooled_order.id, operator.id, product.id)

        await db_session.refresh(inventory_with_stock)
        assert inventory_with_stock.quantity_available == initial_qty - 1
        assert inventory_with_stock.quantity_reserved == 1

    async def test_claim_fails_on_non_pool_order(
        self, db_session, order_service, operator, product,
        inventory_with_stock, customer_user,
    ):
        completed_order = Order(
            customer_id=customer_user.id,
            product_id=product.id,
            status=OrderStatus.completed,  # не in_pool!
            amount=product.price,
            currency="USDT",
            expires_at=datetime.now(timezone.utc) + timedelta(minutes=30),
        )
        db_session.add(completed_order)
        await db_session.flush()

        with pytest.raises(OrderAlreadyClaimedError):
            await order_service.claim_order(completed_order.id, operator.id, product.id)

    async def test_claim_fails_with_zero_inventory(
        self, db_session, order_service, operator, product, pooled_order,
    ):
        empty_inv = OperatorInventory(
            operator_id=operator.id, product_id=product.id, quantity_available=0,
        )
        db_session.add(empty_inv)
        await db_session.flush()

        with pytest.raises(InsufficientInventoryError):
            await order_service.claim_order(pooled_order.id, operator.id, product.id)

        # Заказ должен остаться claimed=False -> на самом деле он УЖЕ claimed
        # на уровне БД к моменту проверки инвентаря (см. self-review примечание)


class TestCompleteOrder:

    async def test_complete_releases_reserved_inventory(
        self, db_session, order_service, operator, product,
        inventory_with_stock, pooled_order,
    ):
        await order_service.claim_order(pooled_order.id, operator.id, product.id)
        await order_service.complete_order(pooled_order.id, operator.id)

        await db_session.refresh(inventory_with_stock)
        assert inventory_with_stock.quantity_reserved == 0

    async def test_complete_increments_operator_earnings(
        self, db_session, order_service, operator, product,
        inventory_with_stock, pooled_order,
    ):
        await order_service.claim_order(pooled_order.id, operator.id, product.id)
        await order_service.complete_order(pooled_order.id, operator.id)

        await db_session.refresh(operator)
        assert operator.total_earned == product.reward_amount

    async def test_complete_fails_for_wrong_operator(
        self, db_session, order_service, operator, second_operator,
        product, inventory_with_stock, pooled_order,
    ):
        await order_service.claim_order(pooled_order.id, operator.id, product.id)

        with pytest.raises(OrderNotFoundError):
            # second_operator пытается завершить заказ, который не он клеймил
            await order_service.complete_order(pooled_order.id, second_operator.id)

    async def test_complete_fails_for_unclaimed_order(
        self, db_session, order_service, operator, pooled_order,
    ):
        with pytest.raises(OrderNotFoundError):
            await order_service.complete_order(pooled_order.id, operator.id)


class TestOrderPoolVisibility:

    async def test_inactive_operator_does_not_see_pool(
        self, db_session, order_service, operator, product,
        inventory_with_stock, pooled_order,
    ):
        operator.is_active = False
        await db_session.flush()

        orders = await order_service.get_pool_for_operator(operator.id)
        # Repository-level фильтр включает Operator.is_active=True в JOIN,
        # поэтому неактивный оператор получит пустой список
        assert pooled_order not in orders

    async def test_operator_without_inventory_does_not_see_order(
        self, db_session, order_service, operator, pooled_order,
    ):
        # НЕ создаём inventory_with_stock fixture
        orders = await order_service.get_pool_for_operator(operator.id)
        assert len(orders) == 0

    async def test_operator_with_zero_stock_does_not_see_order(
        self, db_session, order_service, operator, product, pooled_order,
    ):
        zero_inv = OperatorInventory(
            operator_id=operator.id, product_id=product.id, quantity_available=0,
        )
        db_session.add(zero_inv)
        await db_session.flush()

        orders = await order_service.get_pool_for_operator(operator.id)
        assert len(orders) == 0

    async def test_active_operator_with_stock_sees_order(
        self, db_session, order_service, operator, product,
        inventory_with_stock, pooled_order,
    ):
        orders = await order_service.get_pool_for_operator(operator.id)
        assert len(orders) == 1
        assert orders[0].id == pooled_order.id


class TestExpiredOrdersCancellation:

    async def test_expired_pending_order_is_cancelled(
        self, db_session, order_service, customer_user, product,
    ):
        expired_order = Order(
            customer_id=customer_user.id,
            product_id=product.id,
            status=OrderStatus.pending_payment,
            amount=product.price,
            currency="USDT",
            expires_at=datetime.now(timezone.utc) - timedelta(minutes=5),  # уже истёк
        )
        db_session.add(expired_order)
        await db_session.flush()

        count = await order_service.cancel_expired_orders()

        assert count == 1
        await db_session.refresh(expired_order)
        assert expired_order.status == OrderStatus.cancelled

    async def test_non_expired_order_is_not_cancelled(
        self, db_session, order_service, customer_user, product,
    ):
        active_order = Order(
            customer_id=customer_user.id,
            product_id=product.id,
            status=OrderStatus.pending_payment,
            amount=product.price,
            currency="USDT",
            expires_at=datetime.now(timezone.utc) + timedelta(minutes=30),
        )
        db_session.add(active_order)
        await db_session.flush()

        count = await order_service.cancel_expired_orders()

        assert count == 0
        await db_session.refresh(active_order)
        assert active_order.status == OrderStatus.pending_payment

    async def test_paid_order_not_affected_by_expiry_even_if_expires_at_passed(
        self, db_session, order_service, customer_user, product,
    ):
        """
        Заказ уже оплачен, но expires_at случайно в прошлом
        (например, оплата пришла впритык к таймауту).
        cancel_expired_orders должен трогать ТОЛЬКО pending_payment.
        """
        paid_order = Order(
            customer_id=customer_user.id,
            product_id=product.id,
            status=OrderStatus.paid,
            amount=product.price,
            currency="USDT",
            expires_at=datetime.now(timezone.utc) - timedelta(minutes=5),
        )
        db_session.add(paid_order)
        await db_session.flush()

        count = await order_service.cancel_expired_orders()

        assert count == 0
        await db_session.refresh(paid_order)
        assert paid_order.status == OrderStatus.paid
