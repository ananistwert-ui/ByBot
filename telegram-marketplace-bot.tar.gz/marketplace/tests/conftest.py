import asyncio
import uuid
from collections.abc import AsyncGenerator
from datetime import datetime, timedelta, timezone
from decimal import Decimal

import pytest
import pytest_asyncio
from httpx import ASGITransport, AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import NullPool

from models.base import Base
from models.models import (
    Operator,
    OperatorInventory,
    Order,
    OrderStatus,
    Product,
    User,
    UserRole,
)

TEST_DATABASE_URL = "postgresql+asyncpg://test:test@localhost:5433/marketplace_test"


@pytest.fixture(scope="session")
def event_loop():
    """Один event loop на всю тестовую сессию для async fixtures."""
    loop = asyncio.new_event_loop()
    yield loop
    loop.close()


@pytest_asyncio.fixture(scope="session")
async def test_engine():
    """
    NullPool — каждый тест получает свежее соединение,
    что важно для проверки изоляции транзакций между параллельными тестами.
    """
    from sqlalchemy import text

    engine = create_async_engine(TEST_DATABASE_URL, poolclass=NullPool, echo=False)

    async with engine.begin() as conn:
        # uuid_generate_v4() используется как server_default в моделях
        await conn.execute(text('CREATE EXTENSION IF NOT EXISTS "uuid-ossp"'))
        await conn.run_sync(Base.metadata.create_all)

    yield engine

    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)
    await engine.dispose()


@pytest_asyncio.fixture
async def db_session(test_engine) -> AsyncGenerator[AsyncSession, None]:
    """
    Каждый тест выполняется в собственной транзакции,
    которая откатывается после теста — полная изоляция между тестами.
    """
    connection = await test_engine.connect()
    transaction = await connection.begin()

    session_factory = sessionmaker(
        bind=connection,
        class_=AsyncSession,
        expire_on_commit=False,
    )
    session = session_factory()

    yield session

    await session.close()
    await transaction.rollback()
    await connection.close()


# ─────────────────────────────────────────────────────────────────────────────
# Factories
# ─────────────────────────────────────────────────────────────────────────────

@pytest_asyncio.fixture
async def customer_user(db_session: AsyncSession) -> User:
    user = User(
        telegram_id=100000 + uuid.uuid4().int % 100000,
        username="test_customer",
        role=UserRole.customer,
    )
    db_session.add(user)
    await db_session.flush()
    return user


@pytest_asyncio.fixture
async def operator_user(db_session: AsyncSession) -> User:
    user = User(
        telegram_id=200000 + uuid.uuid4().int % 100000,
        username="test_operator",
        role=UserRole.operator,
    )
    db_session.add(user)
    await db_session.flush()
    return user


@pytest_asyncio.fixture
async def operator(db_session: AsyncSession, operator_user: User) -> Operator:
    op = Operator(user_id=operator_user.id, is_active=True)
    db_session.add(op)
    await db_session.flush()
    return op


@pytest_asyncio.fixture
async def second_operator(db_session: AsyncSession) -> Operator:
    user = User(
        telegram_id=300000 + uuid.uuid4().int % 100000,
        username="test_operator_2",
        role=UserRole.operator,
    )
    db_session.add(user)
    await db_session.flush()

    op = Operator(user_id=user.id, is_active=True)
    db_session.add(op)
    await db_session.flush()
    return op


@pytest_asyncio.fixture
async def product(db_session: AsyncSession) -> Product:
    p = Product(
        title="Netflix Premium",
        description="1 month subscription",
        price=Decimal("9.99"),
        currency="USDT",
        reward_amount=Decimal("1.50"),
        is_active=True,
    )
    db_session.add(p)
    await db_session.flush()
    return p


@pytest_asyncio.fixture
async def inventory_with_stock(
    db_session: AsyncSession, operator: Operator, product: Product
) -> OperatorInventory:
    inv = OperatorInventory(
        operator_id=operator.id,
        product_id=product.id,
        quantity_available=5,
        quantity_reserved=0,
    )
    db_session.add(inv)
    await db_session.flush()
    return inv


@pytest_asyncio.fixture
async def pooled_order(
    db_session: AsyncSession, customer_user: User, product: Product
) -> Order:
    """Заказ в статусе in_pool, готовый для claim."""
    order = Order(
        customer_id=customer_user.id,
        product_id=product.id,
        status=OrderStatus.in_pool,
        amount=product.price,
        currency=product.currency,
        expires_at=datetime.now(timezone.utc) + timedelta(minutes=30),
    )
    db_session.add(order)
    await db_session.flush()
    return order
