"""
КРИТИЧНЫЕ тесты защиты от race condition.

Главное требование ТЗ:
"Нельзя допустить: 2 оператора получили один заказ."

Эти тесты используют РЕАЛЬНЫЕ параллельные соединения к БД
(не mock), чтобы достоверно проверить atomic UPDATE.
"""
import asyncio
import uuid
from datetime import datetime, timedelta, timezone
from decimal import Decimal

import pytest
import pytest_asyncio
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import NullPool

from core.repositories.inventory_repository import InventoryRepository
from core.repositories.order_repository import OrderRepository
from core.services.audit_service import AuditService
from core.services.order_service import OrderAlreadyClaimedError, OrderService
from models.models import (
    Operator,
    OperatorInventory,
    Order,
    OrderStatus,
    Product,
    User,
    UserRole,
)
from tests.conftest import TEST_DATABASE_URL

pytestmark = pytest.mark.asyncio


class _FakeCryptoBot:
    """Mock CryptoBot — race condition тесты не должны зависеть от внешнего API."""
    async def create_invoice(self, **kwargs):
        return {"invoice_id": 1, "bot_invoice_url": "https://t.me/fake", "status": "active"}


async def _claim_with_own_session(
    engine,
    order_id: uuid.UUID,
    operator_id: uuid.UUID,
    product_id: uuid.UUID,
) -> tuple[bool, str | None]:
    """
    Каждый "оператор" выполняет claim в СВОЕЙ собственной транзакции
    и СВОЁМ собственном соединении — это симулирует два параллельных
    HTTP-запроса от двух разных операторов в реальной системе.
    """
    session_factory = sessionmaker(
        bind=engine, class_=AsyncSession, expire_on_commit=False
    )
    async with session_factory() as session:
        order_repo = OrderRepository(session)
        inv_repo = InventoryRepository(session)
        audit = AuditService(session)
        service = OrderService(order_repo, inv_repo, audit, _FakeCryptoBot())

        try:
            await service.claim_order(order_id, operator_id, product_id)
            await session.commit()
            return True, None
        except OrderAlreadyClaimedError:
            await session.rollback()
            return False, "already_claimed"
        except Exception as e:
            await session.rollback()
            return False, str(e)


@pytest_asyncio.fixture
async def race_test_engine(test_engine):
    """
    Race condition тесты требуют отдельного engine с пулом соединений
    (не NullPool с одним коннектом), чтобы по-настоящему параллелить запросы.
    """
    engine = create_async_engine(
        TEST_DATABASE_URL, pool_size=10, max_overflow=5, echo=False
    )
    yield engine
    await engine.dispose()


@pytest.mark.asyncio
class TestClaimRaceCondition:

    async def test_two_operators_claim_same_order_only_one_succeeds(
        self, db_session: AsyncSession, race_test_engine
    ):
        """
        ГЛАВНЫЙ ТЕСТ: 2 оператора одновременно жмут "Take order"
        на ОДИН и тот же заказ.

        Ожидаемый результат:
        - Ровно ОДИН claim успешен
        - Второй получает OrderAlreadyClaimedError
        - В БД у заказа ровно один operator_id
        """
        # ── Setup: создаём данные в основной тестовой сессии и коммитим,
        # чтобы они были видны из параллельных соединений ──────────────────
        customer = User(telegram_id=111111, role=UserRole.customer)
        op_user_a = User(telegram_id=222222, role=UserRole.operator)
        op_user_b = User(telegram_id=333333, role=UserRole.operator)
        db_session.add_all([customer, op_user_a, op_user_b])
        await db_session.flush()

        operator_a = Operator(user_id=op_user_a.id, is_active=True)
        operator_b = Operator(user_id=op_user_b.id, is_active=True)
        db_session.add_all([operator_a, operator_b])
        await db_session.flush()

        product = Product(
            title="Netflix Premium",
            price=Decimal("9.99"),
            reward_amount=Decimal("1.50"),
        )
        db_session.add(product)
        await db_session.flush()

        # У ОБОИХ операторов есть инвентарь — иначе тест не проверяет
        # именно order-level race condition
        inv_a = OperatorInventory(
            operator_id=operator_a.id, product_id=product.id,
            quantity_available=10,
        )
        inv_b = OperatorInventory(
            operator_id=operator_b.id, product_id=product.id,
            quantity_available=10,
        )
        db_session.add_all([inv_a, inv_b])
        await db_session.flush()

        order = Order(
            customer_id=customer.id,
            product_id=product.id,
            status=OrderStatus.in_pool,
            amount=product.price,
            currency="USDT",
            expires_at=datetime.now(timezone.utc) + timedelta(minutes=30),
        )
        db_session.add(order)
        await db_session.flush()
        await db_session.commit()  # КРИТИЧНО: commit, чтобы видно из других сессий

        order_id = order.id
        product_id = product.id

        # ── Act: запускаем оба claim ПАРАЛЛЕЛЬНО через asyncio.gather ───────
        results = await asyncio.gather(
            _claim_with_own_session(race_test_engine, order_id, operator_a.id, product_id),
            _claim_with_own_session(race_test_engine, order_id, operator_b.id, product_id),
        )

        # ── Assert ───────────────────────────────────────────────────────────
        successes = [r for r in results if r[0] is True]
        failures = [r for r in results if r[0] is False]

        assert len(successes) == 1, (
            f"Expected exactly 1 successful claim, got {len(successes)}. "
            f"Results: {results}"
        )
        assert len(failures) == 1, f"Expected exactly 1 failure, got {len(failures)}"
        assert failures[0][1] == "already_claimed"

        # Проверяем финальное состояние в БД
        await db_session.refresh(order)
        assert order.status == OrderStatus.claimed
        assert order.operator_id in (operator_a.id, operator_b.id)
        assert order.claimed_at is not None

    async def test_ten_operators_claim_same_order_only_one_succeeds(
        self, db_session: AsyncSession, race_test_engine
    ):
        """
        Стресс-версия: 10 параллельных операторов на 1 заказ.
        Проверяет, что атомарность держится не только на 2,
        но и при большей конкуренции (где race condition более вероятен).
        """
        customer = User(telegram_id=400000, role=UserRole.customer)
        db_session.add(customer)
        await db_session.flush()

        product = Product(title="Spotify Premium", price=Decimal("4.99"))
        db_session.add(product)
        await db_session.flush()

        operators = []
        for i in range(10):
            user = User(telegram_id=500000 + i, role=UserRole.operator)
            db_session.add(user)
            await db_session.flush()
            op = Operator(user_id=user.id, is_active=True)
            db_session.add(op)
            await db_session.flush()
            inv = OperatorInventory(
                operator_id=op.id, product_id=product.id, quantity_available=5
            )
            db_session.add(inv)
            operators.append(op)
        await db_session.flush()

        order = Order(
            customer_id=customer.id,
            product_id=product.id,
            status=OrderStatus.in_pool,
            amount=product.price,
            currency="USDT",
            expires_at=datetime.now(timezone.utc) + timedelta(minutes=30),
        )
        db_session.add(order)
        await db_session.flush()
        await db_session.commit()

        results = await asyncio.gather(*[
            _claim_with_own_session(race_test_engine, order.id, op.id, product.id)
            for op in operators
        ])

        successes = [r for r in results if r[0] is True]
        assert len(successes) == 1, (
            f"Expected exactly 1 success out of 10 concurrent claims, "
            f"got {len(successes)}"
        )

    async def test_claim_already_claimed_order_fails_immediately(
        self, db_session: AsyncSession, customer_user, operator,
        second_operator, product, inventory_with_stock,
    ):
        """Заказ уже claimed другим оператором ДО начала теста."""
        order = Order(
            customer_id=customer_user.id,
            product_id=product.id,
            status=OrderStatus.claimed,
            operator_id=second_operator.id,
            claimed_at=datetime.now(timezone.utc),
            amount=product.price,
            currency="USDT",
            expires_at=datetime.now(timezone.utc) + timedelta(minutes=30),
        )
        db_session.add(order)
        await db_session.flush()

        order_repo = OrderRepository(db_session)
        inv_repo = InventoryRepository(db_session)
        audit = AuditService(db_session)
        service = OrderService(order_repo, inv_repo, audit, _FakeCryptoBot())

        with pytest.raises(OrderAlreadyClaimedError):
            await service.claim_order(order.id, operator.id, product.id)


@pytest.mark.asyncio
class TestInventoryRaceCondition:

    async def test_inventory_cannot_go_negative_under_concurrent_claims(
        self, db_session: AsyncSession, race_test_engine
    ):
        """
        Один оператор имеет inventory=1.
        Два параллельных заказа пытаются claim товар у этого оператора.
        Ровно один должен пройти, второй должен упасть с
        InsufficientInventoryError (т.к. inventory обнулится после первого).
        """
        customer = User(telegram_id=600000, role=UserRole.customer)
        op_user = User(telegram_id=600001, role=UserRole.operator)
        db_session.add_all([customer, op_user])
        await db_session.flush()

        operator = Operator(user_id=op_user.id, is_active=True)
        db_session.add(operator)
        await db_session.flush()

        product = Product(title="YouTube Premium", price=Decimal("5.00"))
        db_session.add(product)
        await db_session.flush()

        # ВАЖНО: только 1 единица товара
        inv = OperatorInventory(
            operator_id=operator.id, product_id=product.id, quantity_available=1,
        )
        db_session.add(inv)
        await db_session.flush()

        order_1 = Order(
            customer_id=customer.id, product_id=product.id,
            status=OrderStatus.in_pool, amount=product.price, currency="USDT",
            expires_at=datetime.now(timezone.utc) + timedelta(minutes=30),
        )
        order_2 = Order(
            customer_id=customer.id, product_id=product.id,
            status=OrderStatus.in_pool, amount=product.price, currency="USDT",
            expires_at=datetime.now(timezone.utc) + timedelta(minutes=30),
        )
        db_session.add_all([order_1, order_2])
        await db_session.flush()
        await db_session.commit()

        results = await asyncio.gather(
            _claim_with_own_session(race_test_engine, order_1.id, operator.id, product.id),
            _claim_with_own_session(race_test_engine, order_2.id, operator.id, product.id),
        )

        successes = [r for r in results if r[0] is True]
        assert len(successes) == 1, (
            f"With inventory=1, exactly 1 of 2 concurrent claims should "
            f"succeed, got {len(successes)}"
        )

        # Финальная проверка: inventory не ушёл в минус (DB constraint + assert)
        await db_session.refresh(inv)
        assert inv.quantity_available == 0
        assert inv.quantity_reserved == 1


@pytest.mark.asyncio
class TestPaymentWebhookIdempotency:

    async def test_duplicate_webhook_does_not_double_process(
        self, db_session: AsyncSession, customer_user, product,
    ):
        """
        CryptoBot присылает один и тот же webhook дважды (network retry).
        Заказ должен перейти in_pool только один раз, без ошибок при втором вызове.
        """
        from core.repositories.payment_repository import PaymentRepository
        from models.models import Payment, PaymentStatus

        order = Order(
            customer_id=customer_user.id,
            product_id=product.id,
            status=OrderStatus.paid,
            amount=product.price,
            currency="USDT",
            expires_at=datetime.now(timezone.utc) + timedelta(minutes=30),
        )
        db_session.add(order)
        await db_session.flush()

        payment = Payment(
            order_id=order.id,
            external_invoice_id="invoice_12345",
            amount=product.price,
            currency="USDT",
            status=PaymentStatus.pending,
        )
        db_session.add(payment)
        await db_session.flush()

        order_repo = OrderRepository(db_session)
        inv_repo = InventoryRepository(db_session)
        audit = AuditService(db_session)
        service = OrderService(order_repo, inv_repo, audit, _FakeCryptoBot())

        # Первый webhook
        result_1 = await service.handle_payment_webhook(
            invoice_id="invoice_12345", check_id="check_1", payload={"test": True}
        )
        assert result_1.status == OrderStatus.in_pool

        # Второй (дублирующий) webhook — не должен снова менять статус
        # или вызывать ошибку
        result_2 = await service.handle_payment_webhook(
            invoice_id="invoice_12345", check_id="check_1", payload={"test": True}
        )
        assert result_2.id == result_1.id
        assert result_2.status == OrderStatus.in_pool  # не изменился повторно
