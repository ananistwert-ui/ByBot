# Деплой на сервер: от чистого VPS до работающего бота

Пошаговый гайд под твою ситуацию: есть VPS и домен, нужна настройка. Рассчитан на средний уровень владения SSH/bash — команды объясняются там, где есть нюанс, и даются без объяснений там, где это база.

---

## Содержание

1. [Доменная схема — что выбрать](#1-доменная-схема--что-выбрать)
2. [Подготовка сервера с нуля](#2-подготовка-сервера-с-нуля)
3. [DNS-настройка](#3-dns-настройка)
4. [Загрузка проекта на сервер](#4-загрузка-проекта-на-сервер)
5. [Получение токенов и генерация секретов](#5-получение-токенов-и-генерация-секретов)
6. [Заполнение .env](#6-заполнение-env)
7. [Получение SSL до старта контейнеров](#7-получение-ssl-до-старта-контейнеров)
8. [Адаптация nginx-конфига под твой домен](#8-адаптация-nginx-конфига-под-твой-домен)
9. [Первый запуск](#9-первый-запуск)
10. [Применение миграций](#10-применение-миграций)
11. [Проверка, что всё живое](#11-проверка-что-всё-живое)
12. [Назначение первого SuperAdmin](#12-назначение-первого-superadmin)
13. [Автозапуск после реболута сервера](#13-автозапуск-после-реболута-сервера)
14. [Автопродление SSL](#14-автопродление-ssl)
15. [Что проверить перед тем, как звать реальных людей](#15-что-проверить-перед-тем-как-звать-реальных-людей)
16. [Как обновлять код в будущем](#16-как-обновлять-код-в-будущем)

---

## 1. Доменная схема — что выбрать

Тебе нужны **2 поддомена** одного домена. Не два разных домена — именно поддомены, это упрощает SSL и DNS.

Если твой домен `example.com`, схема такая:

| Поддомен | Назначение | Кто туда стучится |
|---|---|---|
| `api.example.com` | REST API + webhook от CryptoBot | Клиенты твоей админки, CryptoBot |
| `bot.example.com` | Webhook от Telegram | Только сервера Telegram |

**Почему не один домен на оба сервиса?** Технически можно (через разные `location /` в одном server-блоке), но разделение поддоменами:
- проще для SSL (один сертификат на оба поддомена через `-d api.example.com -d bot.example.com`, либо два раздельных)
- проще читать логи nginx (сразу видно, какой трафик откуда)
- если в будущем понадобится разнести API и бота на разные сервера — DNS просто перенаправляется, конфиг не трогается

Используй ровно эти два имени дальше во всех конфигах — либо замени `example.com` на свой реальный домен везде одинаково.

---

## 2. Подготовка сервера с нуля

Подключаемся:

```bash
ssh root@ВАШ_IP_СЕРВЕРА
```

### 2.1 Базовое обновление и непривилегированный пользователь

Работать от `root` постоянно — плохая практика. Создаём рабочего пользователя:

```bash
apt update && apt upgrade -y

adduser deploy
usermod -aG sudo deploy

# Скопируй свой SSH-ключ новому пользователю, чтобы не вводить пароль каждый раз
rsync --archive --chown=deploy:deploy ~/.ssh /home/deploy

# Дальше работаем под deploy
su - deploy
```

### 2.2 Базовый firewall

Открываем только то, что нужно: SSH, HTTP, HTTPS.

```bash
sudo apt install -y ufw
sudo ufw allow OpenSSH
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw enable
sudo ufw status
```

> Порты Postgres (5432), Redis (6379), Prometheus (9090), Grafana (3000) **не открываем наружу** — они и не должны быть доступны из интернета. В docker-compose они объявлены как `expose`, не `ports`, то есть видны только внутри Docker-сети. Это уже заложено в проекте — firewall тут вторая линия защиты.

### 2.3 Установка Docker

```bash
curl -fsSL https://get.docker.com | sh
sudo usermod -aG docker deploy

# Применить новую группу без перелогина
newgrp docker

# Проверка
docker --version
docker compose version
```

### 2.4 Fail2ban (защита SSH от брутфорса)

Не обязательно, но настоятельно рекомендую для публичного сервера:

```bash
sudo apt install -y fail2ban
sudo systemctl enable --now fail2ban
```

---

## 3. DNS-настройка

В панели управления твоим доменом (Cloudflare, Namecheap, Reg.ru — где угодно) создай **две A-записи**:

| Тип | Имя | Значение | TTL |
|---|---|---|---|
| A | `api` | IP твоего сервера | Auto / 3600 |
| A | `bot` | IP твоего сервера | Auto / 3600 |

Если используешь Cloudflare — **на старте отключи проксирование** (серое облако, не оранжевое) для обоих поддоменов. Включишь обратно после того, как SSL и webhook заработают — иначе certbot не сможет провалидировать домен через HTTP-01 challenge, и Telegram может конфликтовать с Cloudflare proxy на нестандартных портах вебхуков.

Проверка, что DNS разошёлся (может занять от 1 минуты до пары часов):

```bash
dig +short api.example.com
dig +short bot.example.com
# Оба должны вернуть IP твоего сервера
```

Не идём дальше, пока оба домена не резолвятся в правильный IP.

---

## 4. Загрузка проекта на сервер

Если проект у тебя в git-репозитории:

```bash
mkdir -p ~/app && cd ~/app
git clone <твой_репозиторий_url> marketplace
cd marketplace
```

Если у тебя архив (как тот, что я сгенерировал) — закидываем через `scp` с локальной машины:

```bash
# Выполняется на ТВОЁМ компьютере, не на сервере
scp telegram-marketplace-bot.tar.gz deploy@ВАШ_IP:~/

# Дальше снова на сервере
ssh deploy@ВАШ_IP
mkdir -p ~/app && cd ~/app
tar -xzf ~/telegram-marketplace-bot.tar.gz
cd marketplace
```

Дальше все команды выполняются из `~/app/marketplace`, если не указано иное.

---

## 5. Получение токенов и генерация секретов

### 5.1 Telegram Bot Token

В Telegram, диалог с [@BotFather](https://t.me/BotFather):

```
/newbot
```

Следуй инструкциям, сохрани токен вида `123456789:AAAbbbCCCdddEEEfffGGGhhh`.

### 5.2 CryptoBot Token

Для начала — **тестовая сеть**, чтобы не рисковать реальными деньгами при первом запуске:

1. Открой [@CryptoTestnetBot](https://t.me/CryptoTestnetBot)
2. `Crypto Pay` → `My Apps` → `Create App`
3. Сохрани `API Token`

Когда всё протестируешь и будешь готов к реальным платежам — повторишь этот же шаг в [@CryptoBot](https://t.me/CryptoBot) (без Testnet) и просто заменишь токен в `.env`.

### 5.3 Генерация секретов

Прямо на сервере:

```bash
echo "APP_SECRET_KEY=$(python3 -c 'import secrets; print(secrets.token_hex(32))')"
echo "JWT_SECRET_KEY=$(python3 -c 'import secrets; print(secrets.token_hex(32))')"
echo "BOT_WEBHOOK_SECRET=$(python3 -c 'import secrets; print(secrets.token_hex(32))')"
echo "CRYPTOBOT_WEBHOOK_SECRET=$(python3 -c 'import secrets; print(secrets.token_hex(32))')"
```

Сохрани вывод этих четырёх команд — они пойдут в `.env` на следующем шаге. У каждой переменной должно быть **своё** уникальное значение, не копируй одно и то же.

### 5.4 Пароли для Postgres / Redis / Grafana

```bash
mkdir -p docker/secrets

python3 -c "import secrets; print(secrets.token_urlsafe(24))" | tr -d '\n' > docker/secrets/postgres_password.txt
python3 -c "import secrets; print(secrets.token_urlsafe(24))" | tr -d '\n' > docker/secrets/redis_password.txt
python3 -c "import secrets; print(secrets.token_urlsafe(24))" | tr -d '\n' > docker/secrets/grafana_password.txt

chmod 600 docker/secrets/*.txt

# Посмотреть, что сгенерировалось — понадобится для .env
cat docker/secrets/postgres_password.txt
cat docker/secrets/redis_password.txt
```

> `tr -d '\n'` убирает перевод строки — иначе пароль внутри файла будет с лишним символом на конце, что приведёт к ошибке аутентификации, которую очень неприятно дебажить.

---

## 6. Заполнение .env

```bash
cp .env.example .env
nano .env
```

Подставь значения, полученные на шаге 5. Вот заполненный пример с реальной структурой (домен заменён на `example.com` — подставь свой):

```bash
APP_ENV=production
APP_DEBUG=false
APP_SECRET_KEY=<значение из шага 5.3>
APP_HOST=0.0.0.0
APP_PORT=8000

DATABASE_URL=postgresql+asyncpg://marketplace_user:<пароль_из_5.4>@postgres:5432/marketplace
DATABASE_POOL_SIZE=20
DATABASE_MAX_OVERFLOW=10
DATABASE_ECHO=false

REDIS_URL=redis://:<пароль_redis_из_5.4>@redis:6379/0

CELERY_BROKER_URL=redis://:<пароль_redis_из_5.4>@redis:6379/1
CELERY_RESULT_BACKEND=redis://:<пароль_redis_из_5.4>@redis:6379/2

BOT_TOKEN=<токен из шага 5.1>
BOT_WEBHOOK_URL=https://bot.example.com/webhook/bot
BOT_WEBHOOK_SECRET=<значение из шага 5.3>

CRYPTOBOT_TOKEN=<токен из шага 5.2>
CRYPTOBOT_API_URL=https://pay.crypt.bot/api
CRYPTOBOT_WEBHOOK_SECRET=<значение из шага 5.3>

JWT_SECRET_KEY=<другое значение из шага 5.3 — НЕ то же, что APP_SECRET_KEY>
JWT_ALGORITHM=HS256
JWT_ACCESS_TOKEN_EXPIRE_MINUTES=60
JWT_REFRESH_TOKEN_EXPIRE_DAYS=30

RATE_LIMIT_PER_MINUTE=60
RATE_LIMIT_BOT_PER_SECOND=3
ALLOWED_ORIGINS=["https://api.example.com"]

ORDER_PAYMENT_TIMEOUT_MINUTES=30
ORDER_POOL_VISIBILITY_LIMIT=50

SENTRY_DSN=
LOG_LEVEL=INFO
LOG_FORMAT=json
```

Два важных момента:

- **`DATABASE_URL` и `REDIS_URL` пароли** должны **дословно совпадать** с тем, что лежит в `docker/secrets/postgres_password.txt` и `redis_password.txt`. Это самая частая ошибка при первом деплое — расхождение в один символ ломает подключение.
- **`SENTRY_DSN` можно временно оставить пустым** для первого запуска — но тогда придётся снять валидацию в `config/settings.py` (там стоит `raise ValueError` если `APP_ENV=production` и `SENTRY_DSN` не задан). Либо заведи бесплатный аккаунт на sentry.io за 2 минуты, либо для первого теста временно поставь `APP_ENV=development` (но тогда не используй это в реальном проде с деньгами).

---

## 7. Получение SSL до старта контейнеров

Самый частый затык в деплое — курица-яйцо: nginx в контейнере не может выпустить сертификат, потому что сам ещё не запущен, а сертификат нужен, чтобы nginx стартовал с TLS. Решение — выпускаем сертификат **standalone**-методом до старта compose.

```bash
sudo apt install -y certbot

# Освободи порт 80 на время выпуска — на этом этапе ничего не должно его слушать
sudo lsof -i :80   # должно быть пусто

sudo certbot certonly --standalone \
  -d api.example.com \
  -d bot.example.com \
  --email твой-email@example.com \
  --agree-tos \
  --non-interactive
```

Если всё прошло успешно, сертификаты появятся здесь:

```bash
sudo ls -la /etc/letsencrypt/live/api.example.com/
# fullchain.pem, privkey.pem
```

> Certbot выпустит **один** сертификат, валидный для обоих доменов сразу (multi-domain через `-d ... -d ...`), но физически файлы сохранятся в папку первого указанного домена (`api.example.com`). Это нормально — оба server-блока в nginx могут ссылаться на одну и ту же папку, либо используй её путь для обоих `server_name` в конфиге.

---

## 8. Адаптация nginx-конфига под твой домен

```bash
nano docker/nginx/conf.d/marketplace.conf
```

Замени каждое упоминание `yourdomain.com` на `example.com` (твой реальный домен). В файле это встречается в **трёх местах**:

1. `server_name api.yourdomain.com;` → `server_name api.example.com;`
2. `server_name bot.yourdomain.com;` → `server_name bot.example.com;`
3. Пути сертификатов:
   ```nginx
   ssl_certificate     /etc/letsencrypt/live/api.yourdomain.com/fullchain.pem;
   ssl_certificate_key /etc/letsencrypt/live/api.yourdomain.com/privkey.pem;
   ```
   → замени на `api.example.com` в обоих server-блоках (так как сертификат физически лежит в папке первого домена — см. примечание выше, путь будет `api.example.com` даже для блока `bot.example.com`).

Быстрая замена через `sed` (если уверен, что других совпадений `yourdomain.com` в файле нет):

```bash
sed -i 's/yourdomain\.com/example.com/g' docker/nginx/conf.d/marketplace.conf
```

Проверь, что заменилось верно:

```bash
grep -n "example.com" docker/nginx/conf.d/marketplace.conf
```

### 8.1 Подключение реальных сертификатов в docker-compose

В `docker/docker-compose.yml` сервис `nginx` ссылается на volume `certbot_certs`, который по умолчанию — пустой Docker volume, а не твои только что выпущенные сертификаты на хосте. Нужно перенаправить на реальный путь:

```bash
nano docker/docker-compose.yml
```

Найди в сервисе `nginx`:

```yaml
volumes:
  - ./nginx/nginx.conf:/etc/nginx/nginx.conf:ro
  - ./nginx/conf.d:/etc/nginx/conf.d:ro
  - nginx_cache:/var/cache/nginx
  - certbot_certs:/etc/letsencrypt:ro
```

Замени последнюю строку на:

```yaml
  - /etc/letsencrypt:/etc/letsencrypt:ro
```

Это монтирует реальную папку сертификатов с хоста внутрь контейнера nginx.

---

## 9. Первый запуск

```bash
cd ~/app/marketplace/docker
docker compose up -d --build
```

Сборка первого образа займёт пару минут (компиляция зависимостей). Следи за логами:

```bash
docker compose logs -f
```

Дождись, чтобы хотя бы `postgres` и `redis` показали `healthy`:

```bash
docker compose ps
```

Ожидаемый вывод — статусы `running` у всех, `(healthy)` у postgres и redis.

---

## 10. Применение миграций

Только после того как `postgres` поднялся:

```bash
docker compose run --rm api alembic upgrade head
```

Проверка, что таблицы создались:

```bash
docker compose exec postgres psql -U marketplace_user -d marketplace -c "\dt"
```

Должен появиться список из 9+ таблиц: `users`, `operators`, `products`, `operator_inventory`, `orders`, `payments`, `payouts`, `audit_logs`, `sessions`.

---

## 11. Проверка, что всё живое

### 11.1 API отвечает

```bash
curl https://api.example.com/health
# Ожидаем: {"status":"ok"}

curl https://api.example.com/health/ready
# Ожидаем: {"status":"ok","database":"ok","redis":"ok"}
```

Если `curl` зависает или возвращает ошибку SSL — проверь:
- DNS действительно разрешился (`dig +short api.example.com`)
- nginx контейнер запущен (`docker compose ps nginx`)
- порты 80/443 открыты в firewall (`sudo ufw status`)

### 11.2 Бот ответил на webhook

```bash
curl "https://api.telegram.org/bot<ТВОЙ_BOT_TOKEN>/getWebhookInfo"
```

В ответе `"url"` должен быть `https://bot.example.com/webhook/bot`, а `"pending_update_count": 0`.

Если `url` пустой — посмотри логи бота:

```bash
docker compose logs bot --tail=50
```

### 11.3 Реальная проверка через Telegram

Открой своего бота в Telegram, отправь `/start`. Должен прийти ответ с приветствием. Если тишина — это самый надёжный индикатор, что где-то на цепочке DNS → nginx → bot контейнер есть разрыв.

---

## 12. Назначение первого SuperAdmin

После того как `/start` сработал, у тебя в БД уже создан пользователь с ролью `customer`. Узнай свой `telegram_id` (любой бот типа [@userinfobot](https://t.me/userinfobot) покажет его), затем:

```bash
docker compose exec postgres psql -U marketplace_user -d marketplace
```

```sql
UPDATE users SET role = 'superadmin' WHERE telegram_id = ТВОЙ_TELEGRAM_ID;
\q
```

Отправь боту `/admin` — должна открыться панель администратора. Дальше всё управление (товары, операторы, выплаты) идёт через интерфейс бота, без новых SQL-команд.

---

## 13. Автозапуск после реболута сервера

Контейнеры с `restart: unless-stopped` (это уже прописано в `docker-compose.yml`) сами поднимутся после `docker` сервиса. Но проверь, что сам Docker запускается при старте системы:

```bash
sudo systemctl enable docker
sudo systemctl is-enabled docker   # должно вывести "enabled"
```

Тест без реального ребута сервера:

```bash
sudo systemctl restart docker
sleep 10
docker compose ps   # все контейнеры должны быть running
```

---

## 14. Автопродление SSL

Сертификат Let's Encrypt живёт 90 дней. Настрой автопродление через cron, с остановкой nginx на момент продления (нужно освободить порт 80):

```bash
sudo crontab -e
```

Добавь строку (подставь свой полный путь к проекту):

```cron
0 3 * * * docker compose -f /home/deploy/app/marketplace/docker/docker-compose.yml stop nginx && certbot renew --quiet && docker compose -f /home/deploy/app/marketplace/docker/docker-compose.yml start nginx
```

Это проверяет необходимость продления каждый день в 3:00 ночи (certbot продлит только если до истечения осталось <30 дней, в остальные дни просто ничего не делает).

Тест без ожидания реального истечения сертификата:

```bash
sudo certbot renew --dry-run
```

---

## 15. Что проверить перед тем, как звать реальных людей

- [ ] `curl https://api.example.com/health/ready` → `{"status":"ok",...}`
- [ ] Бот отвечает на `/start` в Telegram
- [ ] `/admin` открывается для твоего telegram_id
- [ ] Создан хотя бы один товар через `/admin → Товары → Новый товар`
- [ ] Создан тестовый оператор (через API, см. SETUP_GUIDE.md раздел 10.3), оператор может зайти в `/work`
- [ ] Тестовая покупка через `@CryptoTestnetBot` проходит весь путь: оплата → webhook → пул → claim → complete
- [ ] `curl https://api.example.com/metrics` → возвращает **403** (не должен быть публично доступен)
- [ ] `docker compose ps celery-beat` → **ровно одна** запущенная реплика
- [ ] CryptoBot токен переключён с Testnet на основной (см. шаг 5.2), если планируешь реальные платежи
- [ ] Сделан тестовый backup и проверено восстановление (см. SETUP_GUIDE.md раздел 15)

---

## 16. Как обновлять код в будущем

Когда внесёшь изменения в код (локально или через git):

```bash
cd ~/app/marketplace
git pull   # если используешь git

cd docker
docker compose up -d --build api bot celery-worker celery-beat
```

Это пересоберёт и перезапустит только сервисы приложения, не трогая `postgres`/`redis`/`nginx` (если их конфиги не менялись).

Если менялись модели БД — не забудь применить новую миграцию **до** перезапуска сервисов:

```bash
docker compose run --rm api alembic upgrade head
docker compose up -d --build api bot celery-worker celery-beat
```

---

## Если что-то не работает

Самые частые проблемы именно на этапе первого деплоя — в разделе **Troubleshooting** основного `SETUP_GUIDE.md` (раздел 16): не резолвится домен, не совпадают пароли в `.env` и `docker/secrets/`, webhook не приходит, заказ зависает. Начни оттуда — там разобраны конкретные команды диагностики для каждого случая.
