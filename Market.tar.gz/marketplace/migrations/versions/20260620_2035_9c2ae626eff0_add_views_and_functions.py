"""add views and functions

Revision ID: 9c2ae626eff0
Revises: 9e0078c9322a
Create Date: 2026-06-20 20:35:24.993198

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = '9c2ae626eff0'
down_revision: Union[str, None] = '9e0078c9322a'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # Функция: суммарный сток товара по всем активным операторам.
    # Используется в /api/products/catalog и в боте (_show_catalog).
    op.execute("""
        CREATE OR REPLACE FUNCTION get_product_total_stock(p_product_id UUID)
        RETURNS INTEGER AS $$
            SELECT COALESCE(SUM(oi.quantity_available), 0)::INTEGER
            FROM operator_inventory oi
            JOIN operators op ON op.id = oi.operator_id
            WHERE oi.product_id = p_product_id
              AND op.is_active = TRUE
              AND oi.quantity_available > 0;
        $$ LANGUAGE sql STABLE;
    """)

    # View: публичный каталог клиента (products_router.get_catalog,
    # bot/handlers/customer_handlers._show_catalog).
    op.execute("""
        CREATE OR REPLACE VIEW v_product_catalog AS
        SELECT
            p.id,
            p.title,
            p.description,
            p.price,
            p.currency,
            get_product_total_stock(p.id) AS total_stock,
            p.sort_order,
            p.created_at
        FROM products p
        WHERE p.is_active = TRUE
          AND p.is_archived = FALSE
        ORDER BY p.sort_order, p.title;
    """)

    # View: статистика операторов (stats_router.operator_stats,
    # bot/handlers/admin_handlers.cb_admin_stats).
    op.execute("""
        CREATE OR REPLACE VIEW v_operator_stats AS
        SELECT
            op.id AS operator_id,
            u.username,
            u.first_name,
            op.is_active,
            op.total_earned,
            COUNT(o.id) FILTER (WHERE o.status = 'completed')  AS completed_orders,
            COUNT(o.id) FILTER (WHERE o.status = 'claimed')    AS active_orders,
            AVG(
                EXTRACT(EPOCH FROM (o.completed_at - o.claimed_at))
            ) FILTER (WHERE o.status = 'completed') AS avg_completion_seconds,
            MAX(op.last_seen) AS last_seen
        FROM operators op
        JOIN users u ON u.id = op.user_id
        LEFT JOIN orders o ON o.operator_id = op.id
        GROUP BY op.id, u.username, u.first_name, op.is_active, op.total_earned;
    """)

    # Триггер автообновления updated_at — упомянут в архитектуре PART 2,
    # отсутствовал в ORM-моделях (там updated_at обновляется на стороне
    # SQLAlchemy через onupdate=func.now(), но прямые UPDATE ... RETURNING
    # в репозиториях (atomic_claim, atomic_complete и т.д.) идут через
    # текстовый/Core SQL и не проходят через ORM event hooks — без
    # триггера updated_at в этих случаях не обновлялся бы.
    op.execute("""
        CREATE OR REPLACE FUNCTION update_updated_at()
        RETURNS TRIGGER AS $$
        BEGIN
            NEW.updated_at = NOW();
            RETURN NEW;
        END;
        $$ LANGUAGE plpgsql;
    """)

    for table in (
        "users", "operators", "products",
        "orders", "payments", "payouts",
    ):
        op.execute(f"DROP TRIGGER IF EXISTS trg_{table}_updated_at ON {table};")
        op.execute(f"""
            CREATE TRIGGER trg_{table}_updated_at
            BEFORE UPDATE ON {table}
            FOR EACH ROW EXECUTE FUNCTION update_updated_at();
        """)


def downgrade() -> None:
    for table in (
        "users", "operators", "products",
        "orders", "payments", "payouts",
    ):
        op.execute(f"DROP TRIGGER IF EXISTS trg_{table}_updated_at ON {table};")

    op.execute("DROP FUNCTION IF EXISTS update_updated_at();")
    op.execute("DROP VIEW IF EXISTS v_operator_stats;")
    op.execute("DROP VIEW IF EXISTS v_product_catalog;")
    op.execute("DROP FUNCTION IF EXISTS get_product_total_stock(UUID);")
