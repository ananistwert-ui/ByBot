"""
Прямая сквозная проверка бизнес-логики против РЕАЛЬНОГО Postgres.
Без pytest, без mock — чтобы исключить любые баги, которые могла бы
маскировать тестовая инфраструктура.
"""
import asyncio
import os
import sys
import uuid
from datetime import datetime, timedelta, timezone
from decimal import Decimal

os.environ.setdefault("DATABASE_URL", "postgresql+asyncpg://marketplace_user:test_password_123@localhost:5432/marketplace")
os.environ.setdefault("REDIS_URL", "redis://localhost:6379/0")
os.environ.setdefault("CELERY_BROKER_URL", "redis://localhost:6379/1")
os.environ.setdefault("CELERY_RESULT_BACKEND", "redis://localhost:6379/2")
os.environ.setdefault("BOT_TOKEN", "000:test")
os.environ.setdefault("BOT_WEBHOOK_URL", "https://example.com/webhook/bot")
os.environ.setdefault("BOT_WEBHOOK_SECRET", "test_secret_32_characters_minimum_xx")
os.environ.setdefault("CRYPTOBOT_TOKEN", "test")
os.environ.setdefault("CRYPTOBOT_WEBHOOK_SECRET", "test_secret_32_characters_minimum_xx")
os.environ.setdefault("APP_SECRET_KEY", "test_secret_32_characters_minimum_xxxxx")
os.environ.setdefault("JWT_SECRET_KEY", "test_jwt_secret_32_characters_minimum_x")
os.environ.setdefault("SENTRY_DSN", "https://test@sentry.io/1")

from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker

from core.repositories.inventory_repository import InventoryRepository
from core.repositories.order_repository import OrderRepository
from core.services.audit_service import AuditService
from core.services.order_service import OrderAlreadyClaimedError, OrderService
from models.models import (
    Operator, OperatorInventory, Order, OrderStatus, Product, User, UserRole,
)

DATABASE_URL = os.environ["DATABASE_URL"]


class _FakeCryptoBot:
    async def create_invoice(self, **kwargs):
        return {"invoice_id": 1, "bot_invoice_url": "https://t.me/fake", "status": "active"}


async def main():
    engine = create_async_engine(DATABASE_URL, echo=False)
    session_factory = sessionmaker(bind=engine, class_=AsyncSession, expire_on_commit=False)

    failures = []

    # ── TEST 1: базовый happy-path заказа ────────────────────────────────────
    print("TEST 1: create -> pay -> claim -> complete ...", end=" ")
    async with session_factory() as session:
        customer = User(telegram_id=900001, role=UserRole.customer)
        op_user = User(telegram_id=900002, role=UserRole.operator)
        session.add_all([customer, op_user])
        await session.flush()

        operator = Operator(user_id=op_user.id, is_active=True)
        session.add(operator)
        await session.flush()

        product = Product(title="Netflix Premium", price=Decimal("9.99"), reward_amount=Decimal("1.50"))
        session.add(product)
        await session.flush()

        inv = OperatorInventory(operator_id=operator.id, product_id=product.id, quantity_available=5)
        session.add(inv)
        await session.flush()

        order = Order(
            customer_id=customer.id, product_id=product.id,
            status=OrderStatus.in_pool, amount=product.price, currency="USDT",
            expires_at=datetime.now(timezone.utc) + timedelta(minutes=30),
        )
        session.add(order)
        await session.flush()
        await session.commit()

        order_repo = OrderRepository(session)
        inv_repo = InventoryRepository(session)
        audit = AuditService(session)
        service = OrderService(order_repo, inv_repo, audit, _FakeCryptoBot())

        try:
            claimed = await service.claim_order(order.id, operator.id, product.id)
            assert claimed.status == OrderStatus.claimed
            assert claimed.operator_id == operator.id

            completed = await service.complete_order(order.id, operator.id)
            assert completed.status == OrderStatus.completed
            await session.commit()

            await session.refresh(inv)
            await session.refresh(operator)
            assert inv.quantity_available == 4, f"expected 4, got {inv.quantity_available}"
            assert inv.quantity_reserved == 0, f"expected 0, got {inv.quantity_reserved}"
            assert operator.total_earned == Decimal("1.50"), f"expected 1.50, got {operator.total_earned}"
            print("PASS")
        except Exception as e:
            print(f"FAIL: {e}")
            failures.append(("happy_path", str(e)))
            await session.rollback()

    # ── TEST 2: REAL race condition с двумя настоящими engine/session ───────
    print("TEST 2: real concurrent claim race (2 separate connections) ...", end=" ")

    async with session_factory() as setup_session:
        customer2 = User(telegram_id=900003, role=UserRole.customer)
        op_user_a = User(telegram_id=900004, role=UserRole.operator)
        op_user_b = User(telegram_id=900005, role=UserRole.operator)
        setup_session.add_all([customer2, op_user_a, op_user_b])
        await setup_session.flush()

        operator_a = Operator(user_id=op_user_a.id, is_active=True)
        operator_b = Operator(user_id=op_user_b.id, is_active=True)
        setup_session.add_all([operator_a, operator_b])
        await setup_session.flush()

        product2 = Product(title="Spotify Premium", price=Decimal("4.99"))
        setup_session.add(product2)
        await setup_session.flush()

        inv_a = OperatorInventory(operator_id=operator_a.id, product_id=product2.id, quantity_available=10)
        inv_b = OperatorInventory(operator_id=operator_b.id, product_id=product2.id, quantity_available=10)
        setup_session.add_all([inv_a, inv_b])
        await setup_session.flush()

        race_order = Order(
            customer_id=customer2.id, product_id=product2.id,
            status=OrderStatus.in_pool, amount=product2.price, currency="USDT",
            expires_at=datetime.now(timezone.utc) + timedelta(minutes=30),
        )
        setup_session.add(race_order)
        await setup_session.flush()
        await setup_session.commit()

        order_id, product_id = race_order.id, product2.id
        op_a_id, op_b_id = operator_a.id, operator_b.id

    async def _claim_attempt(operator_id):
        async with session_factory() as s:
            o_repo = OrderRepository(s)
            i_repo = InventoryRepository(s)
            a_svc = AuditService(s)
            svc = OrderService(o_repo, i_repo, a_svc, _FakeCryptoBot())
            try:
                await svc.claim_order(order_id, operator_id, product_id)
                await s.commit()
                return True
            except OrderAlreadyClaimedError:
                await s.rollback()
                return False
            except Exception as e:
                await s.rollback()
                raise

    try:
        results = await asyncio.gather(
            _claim_attempt(op_a_id),
            _claim_attempt(op_b_id),
        )
        successes = sum(1 for r in results if r is True)
        assert successes == 1, f"expected exactly 1 success, got {successes} (results={results})"
        print(f"PASS (results={results})")
    except Exception as e:
        print(f"FAIL: {e}")
        failures.append(("race_condition", str(e)))

    # ── TEST 3: webhook idempotency на реальной БД ───────────────────────────
    print("TEST 3: duplicate webhook idempotency ...", end=" ")
    async with session_factory() as session:
        from core.repositories.payment_repository import PaymentRepository
        from models.models import Payment, PaymentStatus

        customer3 = User(telegram_id=900006, role=UserRole.customer)
        session.add(customer3)
        await session.flush()

        product3 = Product(title="YouTube Premium", price=Decimal("5.00"))
        session.add(product3)
        await session.flush()

        order3 = Order(
            customer_id=customer3.id, product_id=product3.id,
            status=OrderStatus.paid, amount=product3.price, currency="USDT",
            expires_at=datetime.now(timezone.utc) + timedelta(minutes=30),
        )
        session.add(order3)
        await session.flush()

        payment = Payment(
            order_id=order3.id, external_invoice_id="real_test_invoice_001",
            amount=product3.price, currency="USDT", status=PaymentStatus.pending,
        )
        session.add(payment)
        await session.flush()
        await session.commit()

        order_repo = OrderRepository(session)
        inv_repo = InventoryRepository(session)
        audit = AuditService(session)
        service = OrderService(order_repo, inv_repo, audit, _FakeCryptoBot())

        try:
            r1 = await service.handle_payment_webhook("real_test_invoice_001", "c1", {"x": 1})
            await session.commit()
            r2 = await service.handle_payment_webhook("real_test_invoice_001", "c1", {"x": 1})
            await session.commit()
            assert r1.id == r2.id
            assert r2.status == OrderStatus.in_pool
            print("PASS")
        except Exception as e:
            print(f"FAIL: {e}")
            failures.append(("webhook_idempotency", str(e)))
            await session.rollback()

    await engine.dispose()

    print()
    if failures:
        print(f"=== {len(failures)} FAILURE(S) ===")
        for name, err in failures:
            print(f"  - {name}: {err}")
        sys.exit(1)
    else:
        print("=== ALL REAL DB TESTS PASSED ===")


if __name__ == "__main__":
    asyncio.run(main())
