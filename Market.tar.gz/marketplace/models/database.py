from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager

from sqlalchemy.ext.asyncio import (
    AsyncEngine,
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)

from config.settings import settings


def create_engine() -> AsyncEngine:
    """
    Создаёт async engine с production настройками пула.
    NullPool используется в worker-процессах (Celery).
    """
    return create_async_engine(
        settings.database_url_str,
        pool_size=settings.DATABASE_POOL_SIZE,
        max_overflow=settings.DATABASE_MAX_OVERFLOW,
        pool_timeout=settings.DATABASE_POOL_TIMEOUT,
        pool_pre_ping=True,     # проверяет соединение перед использованием
        pool_recycle=3600,      # переподключение раз в час
        echo=settings.DATABASE_ECHO,
        # JSON сериализация через orjson для скорости
        json_serializer=_orjson_serializer,
        json_deserializer=_orjson_deserializer,
    )


def _orjson_serializer(obj: object) -> str:
    import orjson
    return orjson.dumps(obj).decode()


def _orjson_deserializer(s: str) -> object:
    import orjson
    return orjson.loads(s)


engine: AsyncEngine = create_engine()

AsyncSessionFactory: async_sessionmaker[AsyncSession] = async_sessionmaker(
    engine,
    class_=AsyncSession,
    expire_on_commit=False,  # Важно для async: объекты живут после commit
    autoflush=False,         # Ручной контроль flush
    autocommit=False,
)


async def get_db_session() -> AsyncGenerator[AsyncSession, None]:
    """
    FastAPI dependency для получения сессии БД.
    Автоматически откатывает транзакцию при исключении.
    """
    async with AsyncSessionFactory() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()


@asynccontextmanager
async def get_db_session_context() -> AsyncGenerator[AsyncSession, None]:
    """
    Context manager для использования вне FastAPI (например, в Celery tasks).

    КРИТИЧНО: НЕ использует глобальный module-level `engine`/`AsyncSessionFactory`.

    Причина: Celery (prefork/solo) выполняет каждую задачу через
    `_run_async()` (см. workers/tasks.py), который создаёт НОВЫЙ
    event loop на каждый вызов задачи. asyncpg-соединения в пуле
    AsyncEngine привязаны к тому event loop, в котором были созданы.
    Если переиспользовать один и тот же module-level `engine` между
    задачами, выполняющимися в разных event loop, вторая и все
    последующие задачи падают с:
        RuntimeError: Task ... got Future ... attached to a different loop

    Поэтому здесь создаётся отдельный engine с NullPool (без
    персистентного пула соединений) на каждый вызов context manager —
    он живёт ровно в рамках текущего event loop и корректно
    закрывается в конце. Для FastAPI (см. get_db_session выше)
    эта проблема не актуальна, так как там один процесс = один
    постоянный event loop на всё время жизни приложения.
    """
    from sqlalchemy.pool import NullPool

    task_engine = create_async_engine(
        settings.database_url_str,
        poolclass=NullPool,
        echo=settings.DATABASE_ECHO,
        json_serializer=_orjson_serializer,
        json_deserializer=_orjson_deserializer,
    )
    task_session_factory = async_sessionmaker(
        task_engine,
        class_=AsyncSession,
        expire_on_commit=False,
        autoflush=False,
        autocommit=False,
    )

    session = task_session_factory()
    try:
        yield session
        await session.commit()
    except Exception:
        await session.rollback()
        raise
    finally:
        await session.close()
        await task_engine.dispose()
