from contextlib import asynccontextmanager

import sentry_sdk
import structlog
from fastapi import FastAPI, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import ORJSONResponse
from prometheus_client import make_asgi_app
from redis.asyncio import Redis
from sentry_sdk.integrations.fastapi import FastApiIntegration
from sentry_sdk.integrations.sqlalchemy import SqlalchemyIntegration

from config.logging import configure_logging
from config.settings import settings
from api.routers import (
    auth_router,
    products_router,
    orders_router,
    payments_router,
    operators_router,
    admin_router,
    stats_router,
    payouts_router,
    health_router,
)
from api.middleware import (
    RateLimitMiddleware,
    RequestIDMiddleware,
    StructlogMiddleware,
)

logger = structlog.get_logger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Startup / shutdown lifecycle.

    КРИТИЧНО: app.state.redis должен быть установлен здесь — это
    единственное место, где Redis-клиент создаётся для всего приложения.
    Без этого RateLimitMiddleware, /webhook/cryptobot (distributed lock)
    и /health/ready падают на AttributeError при первом обращении к
    request.app.state.redis.
    """
    configure_logging()

    if settings.SENTRY_DSN:
        sentry_sdk.init(
            dsn=settings.SENTRY_DSN,
            integrations=[
                FastApiIntegration(transaction_style="url"),
                SqlalchemyIntegration(),
            ],
            environment=settings.APP_ENV,
            traces_sample_rate=0.1,
            profiles_sample_rate=0.1,
        )

    redis_client = Redis.from_url(
        settings.redis_url_str,
        decode_responses=True,
        max_connections=settings.REDIS_POOL_SIZE,
    )
    # Проверяем соединение сразу при старте — если Redis недоступен,
    # лучше упасть на старте контейнера, чем тихо деградировать в runtime.
    await redis_client.ping()
    app.state.redis = redis_client

    logger.info(
        "application_startup",
        env=settings.APP_ENV,
        debug=settings.APP_DEBUG,
    )

    yield

    await redis_client.aclose()
    logger.info("application_shutdown")


def create_app() -> FastAPI:
    app = FastAPI(
        title="Telegram Marketplace API",
        version="1.0.0",
        docs_url="/docs" if not settings.is_production else None,
        redoc_url="/redoc" if not settings.is_production else None,
        openapi_url="/openapi.json" if not settings.is_production else None,
        default_response_class=ORJSONResponse,
        lifespan=lifespan,
    )

    # ── Middleware (порядок важен: выполняется снаружи внутрь) ───────────────
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.ALLOWED_ORIGINS,
        allow_credentials=True,
        allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE"],
        allow_headers=["*"],
    )
    app.add_middleware(RateLimitMiddleware)
    app.add_middleware(RequestIDMiddleware)
    app.add_middleware(StructlogMiddleware)

    # ── Routers ──────────────────────────────────────────────────────────────
    app.include_router(health_router,    prefix="/health",    tags=["health"])
    app.include_router(auth_router,      prefix="/api/auth",  tags=["auth"])
    app.include_router(products_router,  prefix="/api/products", tags=["products"])
    app.include_router(orders_router,    prefix="/api/orders",   tags=["orders"])
    app.include_router(payments_router,  prefix="/api/payments", tags=["payments"])
    app.include_router(operators_router, prefix="/api/operators", tags=["operators"])
    app.include_router(admin_router,     prefix="/api/admin",  tags=["admin"])
    app.include_router(stats_router,     prefix="/api/stats",  tags=["stats"])
    app.include_router(payouts_router,   prefix="/api/payouts", tags=["payouts"])

    # ── Prometheus metrics endpoint ──────────────────────────────────────────
    metrics_app = make_asgi_app()
    app.mount("/metrics", metrics_app)

    # ── Exception handlers ───────────────────────────────────────────────────
    @app.exception_handler(PermissionError)
    async def permission_error_handler(
        request: Request, exc: PermissionError
    ) -> ORJSONResponse:
        return ORJSONResponse(
            status_code=status.HTTP_403_FORBIDDEN,
            content={"detail": str(exc)},
        )

    @app.exception_handler(ValueError)
    async def value_error_handler(
        request: Request, exc: ValueError
    ) -> ORJSONResponse:
        return ORJSONResponse(
            status_code=status.HTTP_400_BAD_REQUEST,
            content={"detail": str(exc)},
        )

    return app


app = create_app()
